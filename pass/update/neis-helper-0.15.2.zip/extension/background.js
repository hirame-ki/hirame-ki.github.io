// 쌤패스 - 백그라운드
//
// 잠금 모델
// · 인증서 비밀번호는 확장 안의 금고(vault.js)에 PIN으로 암호화해 둔다. 0.15.0부터 도우미 프로그램(NeisHelper.exe)은 쓰지 않는다
//   (학교에서 일괄 관리하는 V3가 실행할 때마다 확인 창을 띄워서, 10-15).
// · PIN으로 잠금을 풀면 비밀번호를 chrome.storage.session(메모리 전용, 디스크에 안 씀)에만 둔다.
//   storage.session은 기본값이 TRUSTED_CONTEXTS라 나이스 페이지 쪽 스크립트는 읽을 수 없다. 이 기본값을 바꾸지 말 것.
// · 잠기는 경우: PC 미사용(idle) / 화면 잠금(locked) / 최대 유지 시간 초과 / 직접 잠금 / 브라우저 종료
// · 잠금 방식(lockMode)
//     'timer'  : 위 전부 (기본)
//     'session': PC 화면 잠금(Win+L)·로그아웃·브라우저 종료·직접 잠금 때만. 미사용·최대 유지 시간으로는 잠그지 않는다.
//                사용자가 "자리를 비울 때 Win+L"에 동의해야 켜진다.

import { PORTAL_LOGIN, PORTAL_MAIN, NEIS_COMMON, NEIS_DRAFT, NEIS_OVERTIME, NEIS_LEAVE, NEIS_SUBJECT_REMARKS, LEAVE_TYPES } from './sites.js';
import { requestInPage, toastInPage } from './neis-request.js';
import { readRosterInPage, writeRowsInPage, openRemarksMenuInPage } from './remarks-neis.js';
import { errorText } from './common.js';
import * as vault from './vault.js';

const DEFAULTS = { idleMinutes: 10, maxUnlockMinutes: 120, lockMode: 'timer' };
const LOCK_MODES = ['timer', 'session'];
const MAX_ALARM = 'max-unlock';
const EXT_ORIGIN = chrome.runtime.getURL('');

async function getSettings() {
  return { ...DEFAULTS, ...(await chrome.storage.local.get(DEFAULTS)) };
}

// ── 잠금 ──

async function isUnlocked() {
  const { password } = await chrome.storage.session.get('password');
  return typeof password === 'string';
}

async function lock(reason) {
  // 비밀은 password 하나뿐. 자동 로그인용 탭 기록(tabTrail) 등 나머지는 남겨 둔다.
  await chrome.storage.session.remove(['password', 'unlockedAt']);
  await chrome.storage.session.set({ lastLock: { reason, at: Date.now() } });
  await chrome.alarms.clear(MAX_ALARM);
  await refreshBadge(false);
}

async function unlock(pin, skipAutoLogin = false) {
  const res = await vault.unlock(pin);
  if (!res.ok) return res;
  const { maxUnlockMinutes, lockMode } = await getSettings();
  await chrome.storage.session.set({ password: res.password, unlockedAt: Date.now() });
  if (lockMode !== 'session') await chrome.alarms.create(MAX_ALARM, { delayInMinutes: maxUnlockMinutes });
  await refreshBadge(true);
  // 로그인 화면을 띄워 둔 채 잠금을 풀었다면 바로 로그인 (자동 로그인을 켠 경우)
  // 바로가기 실행 화면에서 푼 경우는 루틴이 로그인을 맡으므로 건너뛴다
  if (!skipAutoLogin) maybeAutoLoginAfterUnlock();
  return { ok: true };
}

async function applyIdleInterval() {
  const { idleMinutes } = await getSettings();
  chrome.idle.setDetectionInterval(Math.max(15, Math.round(idleMinutes * 60)));
}

// 리스너는 서비스 워커가 깨어날 때마다 최상위에서 다시 등록돼야 한다
chrome.idle.onStateChanged.addListener(async (state) => {
  if (state === 'active' || !(await isUnlocked())) return;
  // 'locked'(화면 잠금)은 어느 방식이든 잠근다. 'idle'(미사용)은 시간 방식일 때만.
  const { lockMode } = await getSettings();
  if (state === 'locked' || lockMode !== 'session') await lock(state);
});

async function setLockMode(mode, agreed) {
  if (!LOCK_MODES.includes(mode)) return { ok: false, error: 'invalid_settings' };
  if (mode === 'session' && agreed !== true) return { ok: false, error: 'consent_required' };
  await chrome.storage.local.set({ lockMode: mode, lockModeAgreedAt: mode === 'session' ? Date.now() : null });
  // 열려 있는 동안 바꾼 경우: 최대 유지 시간 알람을 끄거나, 남은 시간만큼 다시 건다
  if (mode === 'session') await chrome.alarms.clear(MAX_ALARM);
  else if (await isUnlocked()) {
    const { unlockedAt } = await chrome.storage.session.get('unlockedAt');
    const { maxUnlockMinutes } = await getSettings();
    const left = maxUnlockMinutes - (Date.now() - (unlockedAt || Date.now())) / 60000;
    await chrome.alarms.create(MAX_ALARM, { delayInMinutes: Math.max(1, left) });
  }
  return { ok: true };
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === MAX_ALARM) await lock('max');
  if (alarm.name === UPDATE_ALARM) await checkForUpdate();
  if (alarm.name === FILES_ALARM) await reloadIfFilesChanged();
});

chrome.runtime.onStartup.addListener(async () => {
  await lock('startup');
  checkForUpdate();
});
chrome.runtime.onInstalled.addListener(async () => {
  await lock('installed');
  checkForUpdate();
});

// 버전이 바뀌었는지는 마지막으로 실행한 버전(lastVersion)과 비교한다 (onInstalled의 이유 값에 기대지 않음).
// 0.14.x까지는 lastVersion을 남기지 않았으므로, 기록 없이 다른 설정이 있으면 0.14.x에서 올라온 것으로 본다.
async function noteVersion() {
  const to = chrome.runtime.getManifest().version;
  const all = await chrome.storage.local.get(null);
  if (all.lastVersion === to) return;
  const from = all.lastVersion || (Object.keys(all).length ? '0.14' : null);
  await chrome.storage.local.set({ lastVersion: to });
  if (!from) return; // 처음 설치
  await chrome.storage.local.set({ justUpdated: { from, to, at: Date.now() } });
  // 0.14.x까지는 비밀번호를 도우미 프로그램이 보관했다. 확장은 그 금고를 열 수 없으니 한 번 다시 저장해야 한다
  if (isNewer('0.15.0', from) && !all.vault) await chrome.storage.local.set({ vaultMoved: true });
}
noteVersion();

applyIdleInterval();
refreshBadge();

// ── 비밀번호 칸 채우기 (1단계 시험용: 포커스된 password 칸에만 넣는다) ──

// 업무포털(지역마다 goe/sen/… 등 하위 주소가 다름)과 나이스. manifest host_permissions와 맞출 것.
const ALLOWED_DOMAINS = ['eduptl.kr', 'neis.go.kr'];

function isAllowedUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'https:' && ALLOWED_DOMAINS.some((d) => u.hostname === d || u.hostname.endsWith('.' + d));
  } catch { return false; }
}

// 프레임 안에서 실행: 포커스된 요소 정보와 진단용 요약 (값은 읽지 않는다)
function probeFrame() {
  let el = document.activeElement;
  while (el?.shadowRoot?.activeElement) el = el.shadowRoot.activeElement; // 열린 shadow DOM 안쪽까지
  const iframeOrigins = [...document.querySelectorAll('iframe, frame')].map((f) => {
    try { return new URL(f.src, location.href).origin; } catch { return '(없음)'; }
  });
  return {
    focused: el instanceof HTMLInputElement && el.type === 'password',
    host: location.host,
    active: el ? `${el.tagName}${el.type ? `(${el.type})` : ''}` : '-',
    pwCount: document.querySelectorAll('input[type=password]').length,
    iframeOrigins,
  };
}

function diagText(frames) {
  return frames.map((f) => {
    const sub = f.iframeOrigins.length ? ` · 하위프레임 ${[...new Set(f.iframeOrigins)].join(', ')}` : '';
    return `[${f.host}] 포커스 ${f.active} · 비밀번호칸 ${f.pwCount}개${sub}`;
  }).join('\n');
}

async function fillPassword() {
  const { password } = await chrome.storage.session.get('password');
  if (typeof password !== 'string') return { ok: false, error: 'locked' };

  // 인증서 창이 별도 브라우저 창(팝업)일 수 있어 허용 도메인의 모든 탭을 본다. 현재 탭 우선.
  const [current] = await chrome.tabs.query({ active: true, currentWindow: true });
  const tabs = (await chrome.tabs.query({})).filter((t) => isAllowedUrl(t.url));
  if (!tabs.length) return { ok: false, error: 'not_neis' };
  tabs.sort((a, b) => (b.id === current?.id) - (a.id === current?.id) || b.active - a.active);

  // 1차: 비밀번호 없이 어느 프레임에 포커스된 password 칸이 있는지만 찾는다
  const seen = [];
  let hit = null;
  for (const tab of tabs) {
    const probe = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: probeFrame })
      .catch(() => []);
    for (const r of probe) {
      if (!r.result) continue;
      seen.push(r.result);
      if (!hit && r.result.focused) hit = { tabId: tab.id, frameId: r.frameId };
    }
    if (hit) break;
  }
  if (!hit) return { ok: false, error: 'no_focused_password', detail: diagText(seen) };

  // 2차: 그 프레임에만 비밀번호를 보낸다
  const [res] = await chrome.scripting.executeScript({
    target: { tabId: hit.tabId, frameIds: [hit.frameId] },
    args: [password],
    func: (pw) => {
      let el = document.activeElement;
      while (el?.shadowRoot?.activeElement) el = el.shadowRoot.activeElement;
      if (!(el instanceof HTMLInputElement) || el.type !== 'password') return false;
      // 프레임워크가 값 변경을 알아채도록 네이티브 setter + 이벤트
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, pw);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    },
  });
  return res?.result === true ? { ok: true } : { ok: false, error: 'no_focused_password' };
}

// ── 업무포털 자동 로그인 ──
// 1단계(비밀번호 없이): 인증서 창 열기 → 목록 대기 → 인증서 선택
// 2단계: 그 탭에만 비밀번호를 보내 입력 → 확인 클릭
// 비밀번호가 틀려도 절대 재시도하지 않는다 (인증서 비밀번호는 연속 오류 시 잠김).

async function findPortalTab() {
  const [current] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (current && isAllowedUrl(current.url) && new URL(current.url).hostname.endsWith('eduptl.kr')) return current;
  const tabs = (await chrome.tabs.query({})).filter((t) => isAllowedUrl(t.url) && new URL(t.url).hostname.endsWith('eduptl.kr'));
  return tabs.find((t) => t.active) || tabs[0] || null;
}

async function portalLogin(tabId = null) {
  const { password } = await chrome.storage.session.get('password');
  if (typeof password !== 'string') return { ok: false, error: 'locked' };
  const tab = tabId ? await chrome.tabs.get(tabId).catch(() => null) : await findPortalTab();
  if (!tab) return { ok: false, error: 'no_portal_tab' };
  const { certHint = '' } = await chrome.storage.local.get('certHint');

  const [prep] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    args: [PORTAL_LOGIN, certHint],
    func: async (cfg, hint) => {
      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
      const vis = (e) => !!e && !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
      const dialogOpen = () => vis(document.querySelector(cfg.dialog));
      let opened = false;
      if (!dialogOpen()) {
        const btn = document.querySelector(cfg.openButton);
        if (!vis(btn)) return { ok: false, error: 'no_login_button' };
        // 화면이 막 뜬 직후에는 인증서 프로그램이 준비되지 않아 클릭이 무시될 수 있다.
        // 인증서 창이 안 뜨면 조금 기다렸다 다시 누른다 (창을 여는 버튼일 뿐이라 비밀번호와 무관, 최대 3번)
        for (let i = 0; i < 3 && !dialogOpen(); i++) {
          btn.click();
          opened = true;
          const until = Date.now() + 4000;
          while (!dialogOpen() && Date.now() < until) await sleep(150);
        }
      }
      let rows = null;
      const end = Date.now() + cfg.timeoutMs;
      while (!rows && Date.now() < end) {
        const r = [...document.querySelectorAll(cfg.certRows)].filter(vis);
        if (dialogOpen() && r.length) rows = r;
        else await sleep(150);
      }
      if (!rows) return { ok: false, error: 'no_cert_list' };

      const userOf = (r) => r.cells[cfg.userColumn]?.innerText.trim() || '';
      let row = rows.length === 1 ? rows[0] : null;
      if (!row && hint) row = rows.find((r) => userOf(r) === hint);
      // 창이 이미 열려 있었다면 사용자가 고른 행을 따른다
      if (!row && !opened) row = rows.find((r) => r.classList.contains(cfg.selectedRowClass));
      if (!row) return { ok: false, error: 'choose_cert', count: rows.length };
      if (!row.classList.contains(cfg.selectedRowClass)) {
        (row.cells[0] || row).click();
        await sleep(200);
      }
      return { ok: true, user: userOf(row), multiple: rows.length > 1 };
    },
  }).catch((e) => [{ result: { ok: false, error: 'script_failed', detail: String(e?.message || e) } }]);

  const p = prep?.result;
  if (!p?.ok) return p || { ok: false, error: 'script_failed' };
  if (p.multiple && p.user) await chrome.storage.local.set({ certHint: p.user });

  const [sub] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    args: [PORTAL_LOGIN, password],
    func: (cfg, pw) => {
      const input = document.querySelector(cfg.passwordInput);
      const btn = document.querySelector(cfg.confirmButton);
      if (!input || !btn) return false;
      input.focus();
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(input, pw);
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      btn.click();
      return true;
    },
  });
  return sub?.result === true ? { ok: true, tabId: tab.id } : { ok: false, error: 'submit_failed', tabId: tab.id };
}

// ── 화면 구조 복사 (나이스 화면 분석·고장 진단용) ──
// 열려 있는 eXbuilder 화면들의 컨트롤 id·종류·버튼 글자·표 칼럼명만 모은다. 입력값과 표 내용은 읽지 않는다.

async function dumpStructure() {
  const tabs = (await chrome.tabs.query({})).filter((t) => isAllowedUrl(t.url) && new URL(t.url).hostname.endsWith('neis.go.kr'));
  if (!tabs.length) return { ok: false, error: 'no_neis_tab' };
  const [current] = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs.find((t) => t.id === current?.id) || tabs.find((t) => t.active) || tabs[0];

  const [res] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: 'MAIN', // 페이지 전역(cpr)에 접근해야 한다
    func: (sel) => {
      if (!window.cpr?.core?.Platform) return null;
      // 값 가리기: 한글→가, 영문→A, 숫자→9. 긴 글은 글자 수만. 학생 이름·내용·번호가 그대로 나가지 않게 한다.
      const mask = (v) => {
        const s = v == null ? '' : String(v);
        if (s.length > 20) return `(글 ${s.length}자)`;
        return s.replace(/[가-힣]/g, '가').replace(/[A-Za-z]/g, 'A').replace(/[0-9]/g, '9');
      };
      // 바이트 수·코드처럼 개인정보가 아닌 짧은 값만 그대로 둔다
      // (orderflag는 번호라서 가린다. othSemInputLen01처럼 숫자가 붙은 바이트 열은 그대로)
      const rawOk = (col, v) => /(Len\d*|Length|Yn|ScCd|Gb|Cnt|Grade|grd|sem|ayr)$/i.test(col) && String(v ?? '').length <= 10;
      const SKIP = /^(app\/com\/main\/Index|udc\/)/;
      const KEEP = ['button', 'combobox', 'dateinput', 'inputbox', 'textarea', 'checkbox', 'radiobutton', 'grid', 'maskeditor', 'numbereditor', 'tabfolder'];
      const lines = [`# ${location.host}${location.pathname} ${new Date().toISOString()}`];
      for (const a of cpr.core.Platform.INSTANCE.getAllRunningAppInstances()) {
        if (SKIP.test(a.app.id)) continue;
        lines.push(`\n[app] ${a.app.id}`);
        const filled = [];
        for (const c of a.getContainer().getAllRecursiveChildren()) {
          if (!KEEP.includes(c.type)) continue;
          if (c.type === 'grid' && c.dataSet && c.dataSet.getRowCount() > 0) filled.push(c);
          let extra = '';
          if (c.type === 'button') extra = c.text || '';
          else if ((c.type === 'radiobutton' || c.type === 'combobox') && c.getItems) extra = c.getItems().map((i) => `${i.value}=${i.label}`).join(', ');
          else if (c.type === 'grid' && c.dataSet) extra = `ds=${c.dataSet.id} rows=${c.dataSet.getRowCount()} cols=${c.dataSet.getColumnNames().join(',')}`;
          const flags = [c.visible === false && 'hidden', c.enabled === false && 'disabled'].filter(Boolean).join(' ');
          lines.push(`${c.type}\t${c.id}\t${extra}${flags ? `\t(${flags})` : ''}`);
        }
        // 조회된 표(과세특·행특·창체 등)는 앞의 5행만 값의 "형식"을 가려서 보여 준다 (입력 기능을 만들기 위한 확인용)
        // 첫 화면(대시보드)의 공지 표는 빼고
        if (/^app\/com\/main\//.test(a.app.id)) continue;
        for (const grid of filled) {
          const ds = grid.dataSet;
          lines.push(`\n[표 형식 ${grid.id}] 전체 ${ds.getRowCount()}행 (값은 가림: 한글→가, 숫자→9, 긴 글→글자 수)`);
          for (let i = 0; i < Math.min(5, ds.getRowCount()); i++) {
            lines.push(`행${i}: ` + ds.getColumnNames().map((col) => {
              const v = ds.getValue(i, col);
              return `${col}=${rawOk(col, v) ? v : mask(v)}`;
            }).join(' | '));
          }
        }
      }
      // 화면에 보이는 "0 / 177 Byte" 같은 글(숫자만)과 2차 인증 남은 시간 표시 위치
      const texts = [];
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      while (walker.nextNode() && texts.length < 14) {
        const t = walker.currentNode.textContent.trim();
        if (/^\d+\s*\/\s*\d+\s*Byte$/i.test(t) || /2차\s*인증/.test(t)) {
          const el = walker.currentNode.parentElement;
          texts.push(`${t.replace(/[가-힣]+/g, (w) => (/2차|인증|분|초/.test(w) ? w : '가'))}\t<${el.tagName.toLowerCase()} id="${el.id}" class="${el.className}">`);
        }
      }
      if (texts.length) lines.push('\n[화면 글자]', ...texts);
      // 왼쪽 메뉴(보이는 것만, 메뉴 이름뿐): 과세특 등으로 가는 메뉴 경로를 맞추기 위해 (10-16)
      const menu = [...document.querySelectorAll(sel.menuItem)].filter((a) => a.offsetWidth || a.offsetHeight).slice(0, 80)
        .map((a) => `${a.textContent.trim().replace(/\s+/g, ' ')}${a.classList.contains(sel.collapsed) ? ' (접힘)' : ''}`);
      if (menu.length) lines.push('\n[왼쪽 메뉴]', ...menu);
      // 과세특 메뉴 경로의 각 이름이 화면 어디에 있는지 (요소 종류·class만. 다른 글자는 적지 않는다)
      const norm = (s) => s.replace(/\s*\d+단계( 메뉴항목)?\s*$/, '').replace(/[\s·및]/g, '');
      const desc = (e) => `${e.tagName.toLowerCase()}${e.id ? '#' + e.id.slice(0, 30) : ''}.${String(e.className).trim().split(/\s+/).slice(0, 4).join('.')}${e.getAttribute('role') ? `[role=${e.getAttribute('role')}]` : ''}`;
      const where = [];
      for (const label of sel.path) {
        const hits = [...document.querySelectorAll('*')].filter((e) => (e.offsetWidth || e.offsetHeight) && norm(e.textContent) === norm(label));
        const inner = hits.filter((e) => !hits.some((o) => o !== e && e.contains(o))).slice(0, 3);
        where.push(`${label}: ${inner.length ? '' : '화면에 안 보임'}`);
        for (const e of inner) {
          const chain = [];
          for (let x = e, k = 0; x && k < 5; x = x.parentElement, k++) chain.push(desc(x));
          where.push(`  ${chain.join(' ← ')}`);
        }
      }
      lines.push('\n[과세특 메뉴 위치]', ...where);
      return lines.join('\n');
    },
    args: [{ menuItem: NEIS_COMMON.menuItem, collapsed: NEIS_COMMON.collapsedClass, path: NEIS_SUBJECT_REMARKS.menu.path }],
  });
  if (!res?.result) return { ok: false, error: 'not_exbuilder' };
  return { ok: true, text: res.result };
}

// ── 복무 신청 (시간외근무 · 조퇴 등 근무상황) ──
// 설정의 버튼(route)마다 기본값과 나이스 개인결재선 이름을 저장한다.
//   kind 'overtime': 종별, 휴일, 시작·종료, 하여야 할 일
//   kind 'leave'   : 근무상황(조퇴·외출·지각·병조퇴…), 연가종류, 시작·종료(5분 단위), 사유, 연락처, 비공개
// 기본은 결재선 지정까지 하고 멈춘다. [상신] 자동 클릭은 사용자가 경고에 동의하고 켠 경우에만.

const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
const MAX_ROUTES = 6;
let routeRunning = false;

const toMin = (t) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3));

function validRoute(r) {
  if (!(r && typeof r.id === 'string'
    && typeof r.name === 'string' && r.name.trim().length >= 1 && r.name.length <= 20
    && TIME_RE.test(r.start) && TIME_RE.test(r.end) && r.start !== r.end
    && typeof r.reason === 'string' && r.reason.trim().length >= 1
    && typeof r.lineName === 'string' && r.lineName.length <= 50)) return false;
  if (r.kind === 'leave') {
    return Object.hasOwn(LEAVE_TYPES, r.sclf) && ['1', '2', '3'].includes(r.avKind)
      && toMin(r.start) < toMin(r.end) && toMin(r.start) % 5 === 0 && toMin(r.end) % 5 === 0
      && r.reason.length <= 400 && /^\d{0,11}$/.test(r.contact || '');
  }
  return (r.kind ?? 'overtime') === 'overtime' && ['1', '2', '3'].includes(r.type) && r.reason.length <= 300;
}

async function findNeisMainTab() {
  const tabs = (await chrome.tabs.query({})).filter((t) => {
    if (!isAllowedUrl(t.url)) return false;
    const u = new URL(t.url);
    return u.hostname.endsWith('neis.go.kr') && u.pathname.startsWith('/jsp/main.jsp');
  });
  return tabs.find((t) => t.active) || tabs[0] || null;
}

function runResultText(route, res) {
  const head = `[${route.name}]`;
  if (!res.ok) {
    let t = `${head} ${res.step || ''}에서 멈췄습니다.\n${errorText(res)}`;
    if (['결재선 불러오기', '상신'].includes(res.step)) {
      t += '\n상신 창은 열어 두었습니다. 직접 마무리하거나 [취소]하세요. (목록에 임시저장 행이 남을 수 있습니다)';
    }
    return t;
  }
  const i = res.info;
  const what = route.kind === 'leave' ? `${LEAVE_TYPES[route.sclf]} ${i.sum}` : `인정 ${i.sum}`;
  const when = `${i.date.slice(4, 6)}/${i.date.slice(6)} ${i.start}~${i.end} (${what})`;
  if (res.stage === 'ready') return `${head} ${when}\n결재선 "${i.line}"까지 넣었습니다. 내용을 확인한 뒤 [상신]을 직접 누르세요.`;
  if (res.stage === 'submitted') return `${head} ${when}\n결재선 "${i.line}"(으)로 상신했습니다.`;
  return `${head} ${when}\n[상신]을 눌렀습니다. 나이스에 뜬 창을 확인하세요.${res.detail ? `\n${res.detail}` : ''}`;
}

// times: 팝업에서 이번 한 번만 바꾼 시각 { start, end } (비우면 버튼 기본값)
// opts.manualSubmit: 루틴에서 부를 때. 자동 상신 설정과 상관없이 [상신] 앞에서 멈춘다.
async function runRoute(routeId, date, times = {}, opts = {}) {
  if (!(await isUnlocked())) return { ok: false, error: 'locked' };
  if (routeRunning) return { ok: false, error: 'running' };
  const { routes = [], autoSubmit = false } = await chrome.storage.local.get(['routes', 'autoSubmit']);
  const route = routes.find((r) => r.id === routeId);
  if (!validRoute(route)) return { ok: false, error: 'no_route' };
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date || '')) return { ok: false, error: 'invalid_date' };
  const run = { ...route, start: times.start || route.start, end: times.end || route.end };
  if (!validRoute(run)) return { ok: false, error: 'invalid_times' };
  const tab = await findNeisMainTab();
  if (!tab) return { ok: false, error: 'no_neis_main' };

  routeRunning = true;
  try {
    // 진행 과정이 보이도록 나이스 탭을 앞으로 (팝업은 이때 닫힌다 → 결과는 나이스 화면 안내로 보여줌)
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
    const isLeave = run.kind === 'leave';
    const job = {
      kind: isLeave ? 'leave' : 'overtime',
      date: date.replaceAll('-', ''), start: run.start, end: run.end,
      reason: run.reason.trim(), lineName: run.lineName.trim(), autoSubmit: autoSubmit === true && opts.manualSubmit !== true,
      ...(isLeave
        ? { lclf: run.sclf.slice(0, 3), sclf: run.sclf, avKind: run.avKind, contact: run.contact || '',
            hidePeriod: !!run.hidePeriod, hideReason: !!run.hideReason }
        : { type: run.type, holiday: !!run.holiday }),
    };
    const common = { ...NEIS_COMMON, menuLabelSuffix: NEIS_COMMON.menuLabelSuffix.source };
    const [r] = await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: 'MAIN', func: requestInPage,
      args: [common, NEIS_DRAFT, isLeave ? NEIS_LEAVE : NEIS_OVERTIME, job],
    }).catch((e) => [{ result: { ok: false, error: 'script_failed', detail: String(e?.message || e) } }]);
    const res = r?.result || { ok: false, error: 'script_failed' };
    const text = runResultText(run, res);
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: toastInPage, args: [text, !res.ok] }).catch(() => {});
    await chrome.storage.session.set({ lastRun: { at: Date.now(), ok: res.ok, text } });
    return { ...res, text };
  } finally {
    routeRunning = false;
  }
}

async function saveRoutes(routes) {
  if (!Array.isArray(routes) || routes.length > MAX_ROUTES || !routes.every(validRoute)) return { ok: false, error: 'invalid_routes' };
  const clean = routes.map((r) => {
    const base = { id: r.id, kind: r.kind === 'leave' ? 'leave' : 'overtime', name: r.name.trim(), start: r.start, end: r.end,
      reason: r.reason.trim(), lineName: r.lineName.trim() };
    return base.kind === 'leave'
      ? { ...base, sclf: r.sclf, avKind: r.avKind, contact: r.contact || '', hidePeriod: !!r.hidePeriod, hideReason: !!r.hideReason }
      : { ...base, type: r.type, holiday: !!r.holiday };
  });
  await chrome.storage.local.set({ routes: clean });
  return { ok: true };
}

async function setAutoSubmit(enabled, agreed) {
  if (enabled && agreed !== true) return { ok: false, error: 'consent_required' };
  await chrome.storage.local.set(enabled
    ? { autoSubmit: true, autoSubmitAgreedAt: Date.now() }
    : { autoSubmit: false, autoSubmitAgreedAt: null });
  return { ok: true };
}

// ── 업무포털 상단 메뉴 열기 (K-에듀파인 등) ──
// 상단 메뉴 링크(a.menuBtn)는 id에 SSO 주소를 담고 있다(나이스에서 확인). 확장이 대신 누르면 팝업 차단에 걸릴 수 있어
// 그 주소를 새 탭으로 직접 연다. 주소가 없으면 링크를 누르는 것으로 대신한다.

async function openPortalMenu(label) {
  if (!(await isUnlocked())) return { ok: false, error: 'locked' };
  const tabs = (await chrome.tabs.query({})).filter((t) => isPortalUrl(t.url) && isLoggedInPage(t.url));
  const tab = tabs.find((t) => t.active) || tabs[0];
  if (!tab) return { ok: false, error: 'no_portal_main' };

  const [r] = await chrome.scripting.executeScript({
    target: { tabId: tab.id }, args: [PORTAL_MAIN.menuLink, label],
    func: (sel, text) => {
      const a = [...document.querySelectorAll(sel)].find((e) => e.innerText.trim() === text && (e.offsetWidth || e.offsetHeight));
      if (!a) return { found: false };
      let url = '';
      try { const u = new URL(a.id); if (u.protocol === 'https:') url = u.href; } catch { /* id가 주소가 아님 */ }
      if (!url) a.click();
      return { found: true, url };
    },
  }).catch(() => []);
  const res = r?.result;
  if (!res?.found) return { ok: false, error: 'menu_link_not_found', detail: label };
  if (res.url) {
    const created = await chrome.tabs.create({ url: res.url, windowId: tab.windowId, index: tab.index + 1 });
    return { ok: true, tabId: created.id };
  }
  return { ok: true };
}

// ── 안내 띄우기 ──

async function notify(tabId, text, isError) {
  let id = tabId;
  if (!id) {
    const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
    id = t && isAllowedUrl(t.url) ? t.id : null;
  }
  if (id) await chrome.scripting.executeScript({ target: { tabId: id }, func: toastInPage, args: [text, isError] }).catch(() => {});
}

// ── 로그인 자동 실행 (설정에서 켠 경우, 잠금이 풀려 있을 때만) ──
// 다른 곳에서 업무포털로 들어왔을 때만 실행한다. 업무포털 안에서 로그인 화면으로 바뀐 경우(= 로그아웃)는 건드리지 않는다.
// 자동 시도 후 로그인된 화면(업무포털 메인·나이스)을 한 번도 못 본 채 다음 자동 시도가 오면
// 실패로 보고 자동 실행을 멈춘다 (인증서 비밀번호 연속 오류 → 인증서 잠김 방지).

function isPortalUrl(url) {
  return isAllowedUrl(url) && new URL(url).hostname.endsWith('eduptl.kr');
}

// 로그인 뒤에만 보이는 화면: 업무포털의 로그인 화면이 아닌 페이지, 또는 나이스
function isLoggedInPage(url) {
  if (!isAllowedUrl(url)) return false;
  const u = new URL(url);
  if (u.hostname.endsWith('neis.go.kr')) return true;
  return u.hostname.endsWith('eduptl.kr') && u.pathname !== '/' && !u.pathname.includes(PORTAL_LOGIN.loginPathPart);
}

async function tryAutoLogin(tabId) {
  const { autoLogin = false, autoLoginBlocked = false } = await chrome.storage.local.get(['autoLogin', 'autoLoginBlocked']);
  if (!autoLogin || autoLoginBlocked || flowRunning || !(await isUnlocked())) return;

  // 로그인 버튼이 있는 화면인지 먼저 확인 (메인 화면 등에서는 조용히 넘어감)
  const [probe] = await chrome.scripting.executeScript({
    target: { tabId }, args: [PORTAL_LOGIN.openButton],
    func: (sel) => { const b = document.querySelector(sel); return !!b && !!(b.offsetWidth || b.offsetHeight); },
  }).catch(() => []);
  if (probe?.result !== true) return;

  const { autoPending = false } = await chrome.storage.session.get('autoPending');
  if (autoPending) {
    await chrome.storage.local.set({ autoLoginBlocked: true });
    await notify(tabId, '지난 자동 로그인이 끝나지 않은 것 같아 자동 실행을 멈췄습니다.\n인증서 비밀번호를 확인한 뒤 설정에서 자동 로그인을 다시 켜세요.', true);
    return;
  }
  await chrome.storage.session.set({ autoPending: true });
  const res = await portalLogin(tabId);
  if (!res.ok) {
    await chrome.storage.session.set({ autoPending: false }); // 비밀번호를 넣기 전에 멈춘 경우는 실패로 치지 않음
    await notify(tabId, `자동 로그인: ${errorText(res)}`, true);
  }
}

chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status !== 'complete') return;
  if (isLoggedInPage(tab.url)) await chrome.storage.session.set({ autoPending: false });
  const { tabTrail = {} } = await chrome.storage.session.get('tabTrail');
  const prev = tabTrail[tabId] || null;
  const now = isPortalUrl(tab.url) ? new URL(tab.url).pathname : null; // 권한 없는 사이트는 url이 안 보임 → null
  await chrome.storage.session.set({ tabTrail: { ...tabTrail, [tabId]: now } });
  if (now && !prev) tryAutoLogin(tabId);
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const { tabTrail = {} } = await chrome.storage.session.get('tabTrail');
  delete tabTrail[tabId];
  await chrome.storage.session.set({ tabTrail });
});

// 잠긴 채로 로그인 화면을 열어 두고 PIN을 넣은 경우
async function maybeAutoLoginAfterUnlock() {
  const tab = await findPortalTab();
  if (tab) tryAutoLogin(tab.id);
}

// ── 루틴 (여러 단계를 이어서 실행) ──
// 단계는 정해진 순서로만 잇는다: 업무포털 로그인 → (K-에듀파인 | 나이스) → 복무 신청.
//   target 'login'  : 로그인까지
//   target 'edufine': 로그인 → K-에듀파인 열기
//   target 'neis'   : 로그인 → 나이스 열기
//   target 'route'  : 로그인 → 나이스 → 복무 신청 버튼(routeId) 실행, 결재선까지 넣고 [상신] 앞에서 멈춤
// 루틴은 자동 상신 설정과 상관없이 항상 [상신] 앞에서 멈춘다 (사람이 내용을 보고 누르도록).
// 이미 로그인돼 있거나 나이스가 열려 있으면 그 단계는 건너뛴다.

const FLOW_TARGETS = ['login', 'edufine', 'neis', 'route'];
const MAX_FLOWS = 6;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
let flowRunning = false;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// check()가 값을 돌려줄 때까지 기다린다. 매번 확장 API를 부르므로 그동안 서비스 워커가 잠들지 않는다.
async function waitFor(check, timeoutMs, interval = 500) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    const v = await check();
    if (v) return v;
    await sleep(interval);
  }
  return null;
}

function validFlow(f, routes) {
  if (!(f && typeof f.id === 'string' && UUID_RE.test(f.id)
    && typeof f.name === 'string' && f.name.trim().length >= 1 && f.name.length <= 20
    && FLOW_TARGETS.includes(f.target))) return false;
  return f.target !== 'route' || routes.some((r) => r.id === f.routeId);
}

async function saveFlows(flows) {
  const { routes = [] } = await chrome.storage.local.get('routes');
  if (!Array.isArray(flows) || flows.length > MAX_FLOWS || !flows.every((f) => validFlow(f, routes))) return { ok: false, error: 'invalid_flows' };
  const clean = flows.map((f) => ({ id: f.id, name: f.name.trim(), target: f.target, ...(f.target === 'route' ? { routeId: f.routeId } : {}) }));
  await chrome.storage.local.set({ flows: clean });
  return { ok: true };
}

async function setPortalUrl(url) {
  let u;
  try { u = new URL(String(url || '').trim()); } catch { return { ok: false, error: 'invalid_portal_url' }; }
  if (u.protocol !== 'https:' || !u.hostname.endsWith('.eduptl.kr')) return { ok: false, error: 'invalid_portal_url' };
  await chrome.storage.local.set({ portalUrl: `${u.origin}/` });
  return { ok: true, url: `${u.origin}/` };
}

async function setFlowStatus(flow, text, state = 'run') {
  await chrome.storage.session.set({ flowStatus: { id: flow.id, name: flow.name, text, state, at: Date.now() } });
}

// 업무포털 탭이 실제로 어떤 화면인지 화면 요소로 판단한다: 'login'(로그인 버튼 보임) | 'main'(상단 메뉴 보임) | null
// 주소만 보면 업무포털이 로그인 화면으로 넘어가기 전에 거치는 주소를 '로그인됨'으로 착각할 수 있다 (10-15 학교에서 겪음)
async function portalScreen(tabId) {
  const [r] = await chrome.scripting.executeScript({
    target: { tabId }, args: [PORTAL_LOGIN.openButton, PORTAL_MAIN.menuLink],
    func: (btnSel, menuSel) => {
      const vis = (e) => !!e && !!(e.offsetWidth || e.offsetHeight);
      if (vis(document.querySelector(btnSel))) return 'login';
      if ([...document.querySelectorAll(menuSel)].some(vis)) return 'main';
      return null;
    },
  }).catch(() => []);
  return r?.result || null;
}

// 로그인된 업무포털 메인 화면(상단 메뉴가 보이는 탭)
async function findPortalMainTab() {
  const tabs = (await chrome.tabs.query({})).filter((t) => t.status === 'complete' && isPortalUrl(t.url) && isLoggedInPage(t.url));
  tabs.sort((a, b) => b.active - a.active);
  for (const t of tabs) if ((await portalScreen(t.id)) === 'main') return t;
  return null;
}

// 로그인 자동 실행과 같은 안전장치: 지난 자동 로그인이 로그인된 화면까지 갔는지 확인되지 않았으면 다시 시도하지 않는다
// (인증서 비밀번호가 틀린 채 반복하면 인증서가 잠긴다)
async function guardedLogin(tabId) {
  const { autoPending = false } = await chrome.storage.session.get('autoPending');
  if (autoPending) return { ok: false, error: 'login_unconfirmed' };
  await chrome.storage.session.set({ autoPending: true });
  const res = await portalLogin(tabId);
  if (!res.ok) await chrome.storage.session.set({ autoPending: false });
  return res;
}

async function ensurePortalLogin(flow) {
  if (await findPortalMainTab()) return { ok: true };

  let tab = (await chrome.tabs.query({})).find((t) => isPortalUrl(t.url));
  if (tab) {
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
  } else {
    const { portalUrl = PORTAL_MAIN.defaultUrl } = await chrome.storage.local.get('portalUrl');
    await setFlowStatus(flow, '업무포털을 여는 중…');
    tab = await chrome.tabs.create({ url: portalUrl, active: true });
  }

  // 로그인 버튼이 보이거나(로그인 필요), 상단 메뉴가 보일 때(이미 로그인됨)까지. 중간에 거치는 주소는 기다린다.
  await setFlowStatus(flow, '업무포털 화면을 기다리는 중…');
  const state = await waitFor(async () => {
    const t = await chrome.tabs.get(tab.id).catch(() => null);
    if (!t) return 'gone';
    if (t.status !== 'complete' || !isPortalUrl(t.url)) return null;
    return portalScreen(t.id);
  }, 30000);
  if (!state) return { ok: false, error: 'portal_not_loaded' };
  if (state === 'gone') return { ok: false, error: 'tab_closed' };

  if (state === 'login') {
    // 화면이 막 뜬 직후에는 인증서 프로그램이 아직 준비되지 않아 클릭이 무시될 수 있다
    await sleep(1000);
    await setFlowStatus(flow, '인증서로 로그인하는 중…');
    const res = await guardedLogin(tab.id);
    if (!res.ok) return { ...res, tabId: tab.id };
  }
  await setFlowStatus(flow, '로그인 완료를 기다리는 중…');
  return (await waitFor(findPortalMainTab, 40000)) ? { ok: true } : { ok: false, error: 'login_timeout', tabId: tab.id };
}

// 팝업 [업무포털 로그인]·단축키
// · 로그인 화면이 이미 열려 있으면 그 화면에서 바로 로그인 (사용자가 직접 누른 것이므로 예전처럼 바로 실행)
// · 없으면 설정의 업무포털 주소를 열고, 화면이 뜨기를 기다려 로그인 (루틴과 같은 안전장치)
async function loginFromButton() {
  if (!(await isUnlocked())) return { ok: false, error: 'locked' };
  if (flowRunning || routeRunning) return { ok: false, error: 'running' };
  const portalTabs = (await chrome.tabs.query({})).filter((t) => isPortalUrl(t.url) && !isLoggedInPage(t.url));
  const loginTab = portalTabs.find((t) => t.active) || portalTabs[0];
  if (loginTab) {
    const res = await portalLogin(loginTab.id);
    if (res.ok || res.error !== 'no_login_button') return res;
    // 아직 화면을 불러오는 중이면 아래에서 기다린다
  } else if (await findPortalMainTab()) {
    return { ok: false, error: 'already_logged_in' };
  }
  flowRunning = true; // 로그인 자동 실행이 같은 탭에 끼어들지 않게
  try {
    const res = await ensurePortalLogin({ id: 'login', name: '업무포털 로그인' });
    if (!res.ok) {
      // 팝업은 새 탭이 열리면서 닫히므로, 다음에 팝업을 열었을 때 "최근 실행"으로 볼 수 있게 남긴다
      const text = `업무포털 로그인: ${errorText(res)}`;
      await chrome.storage.session.set({ lastRun: { at: Date.now(), ok: false, text } });
      await notify(res.tabId || null, text, true);
    }
    return res;
  } finally {
    flowRunning = false;
  }
}

async function neisReadyTab() {
  const t = await findNeisMainTab();
  if (!t || t.status !== 'complete') return null;
  const [r] = await chrome.scripting.executeScript({
    target: { tabId: t.id }, world: 'MAIN', args: [NEIS_COMMON.menuItem],
    func: (sel) => !!window.cpr?.core?.Platform && !!document.querySelector(sel),
  }).catch(() => []);
  return r?.result === true ? t : null;
}

// 업무포털 상단 메뉴가 그려질 때까지 기다렸다가 연다 (찾지 못하면 아무것도 누르지 않으므로 반복해도 안전)
async function openMenuWhenReady(label) {
  const res = await waitFor(async () => {
    const r = await openPortalMenu(label);
    return r.ok || r.error === 'locked' ? r : null;
  }, 20000, 700);
  return res || { ok: false, error: 'menu_link_not_found', detail: label };
}

async function runFlowSteps(flow) {
  const login = await ensurePortalLogin(flow);
  if (!login.ok) return { ...login, step: '업무포털 로그인' };
  if (flow.target === 'login') return { ok: true, text: '업무포털에 로그인했습니다.' };

  if (flow.target === 'edufine') {
    await setFlowStatus(flow, 'K-에듀파인을 여는 중…');
    const r = await openMenuWhenReady(PORTAL_MAIN.edufineLabel);
    return r.ok ? { ok: true, text: 'K-에듀파인을 열었습니다.' } : { ...r, step: 'K-에듀파인 열기' };
  }

  if (!(await neisReadyTab())) {
    await setFlowStatus(flow, '나이스를 여는 중…');
    if (!(await findNeisMainTab())) {
      const r = await openMenuWhenReady(PORTAL_MAIN.neisLabel);
      if (!r.ok) return { ...r, step: '나이스 열기' };
    }
    await setFlowStatus(flow, '나이스 화면을 기다리는 중…');
    const t = await waitFor(neisReadyTab, 60000, 800);
    if (!t) return { ok: false, error: 'neis_timeout', step: '나이스 열기' };
    await sleep(1500); // 첫 화면 스크립트가 자리 잡을 시간
  }
  if (flow.target === 'neis') {
    const t = await findNeisMainTab();
    if (t) {
      await chrome.tabs.update(t.id, { active: true });
      await chrome.windows.update(t.windowId, { focused: true });
    }
    return { ok: true, text: '나이스를 열었습니다.' };
  }

  await setFlowStatus(flow, '복무 신청을 입력하는 중…');
  const res = await runRoute(flow.routeId, todayIso(), {}, { manualSubmit: true });
  // 나이스 안에서 멈춘 경우(step 있음)는 runRoute가 이미 나이스 화면에 안내를 띄움
  return res.ok ? { ok: true, text: res.text } : { ...res, step: res.step || '복무 신청', shown: !!res.step };
}

async function runFlow(flowId) {
  if (!(await isUnlocked())) return { ok: false, error: 'locked' };
  if (flowRunning || routeRunning) return { ok: false, error: 'running' };
  const { flows = [], routes = [] } = await chrome.storage.local.get(['flows', 'routes']);
  const flow = flows.find((f) => f.id === flowId);
  if (!validFlow(flow, routes)) return { ok: false, error: 'no_flow' };

  flowRunning = true;
  try {
    await setFlowStatus(flow, '시작합니다…');
    const res = await runFlowSteps(flow);
    const text = res.ok ? `[${flow.name}] ${res.text}` : `[${flow.name}] ${res.step}에서 멈췄습니다.\n${errorText(res)}`;
    await setFlowStatus(flow, text, res.ok ? 'done' : 'error');
    if (!res.ok && !res.shown) await notify(res.tabId || null, text, true);
    return { ...res, text };
  } finally {
    flowRunning = false;
  }
}

// ── 과세특 입력 (remarks.html에서 부름) ──
// 명단 읽기와 일반 칸 값 넣기만 한다. [저장]은 사용자가 나이스 화면에서 직접 누른다.
// 학생 이름·내용은 remarks 화면으로만 오가고 storage에 남기지 않는다.

async function inNeis(func, args) {
  const tab = await findNeisMainTab();
  if (!tab) return { ok: false, error: 'no_neis_main' };
  const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func, args })
    .catch((e) => [{ result: { ok: false, error: 'script_failed', detail: String(e?.message || e) } }]);
  return { ...(r?.result || { ok: false, error: 'script_failed' }), tabId: tab.id, windowId: tab.windowId };
}

async function remarksRoster() {
  return inNeis(readRosterInPage, [NEIS_SUBJECT_REMARKS]);
}

// 과세특 입력을 누르면: 업무포털 로그인 → 나이스 → 교과담임 › 성적처리 › 과목별세부능력및특기사항 → OTP 창까지.
// 이미 된 단계는 건너뛴다(루틴과 같은 runFlowSteps). OTP는 사용자가 직접 입력한다.
async function remarksGo() {
  if (!(await isUnlocked())) return { ok: false, error: 'locked' };
  if (flowRunning || routeRunning) return { ok: false, error: 'running' };
  const C = { ...NEIS_COMMON, menuLabelSuffix: NEIS_COMMON.menuLabelSuffix.source };
  // 과세특 화면이 이미 열려 있으면 다른 탭으로 옮기지 않는다
  if (await neisReadyTab()) {
    const cur = await inNeis((cfg) => ({ ok: true, open: !!window.cpr?.core?.Platform?.INSTANCE.getAllRunningAppInstances().some((a) => a.app.id === cfg.app) }), [NEIS_SUBJECT_REMARKS]);
    if (cur.open === true) return { ok: true, stage: 'open' };
  }
  const flow = { id: 'remarks', name: '과세특 입력', target: 'neis' };
  flowRunning = true;
  try {
    const nav = await runFlowSteps(flow);
    if (!nav.ok) {
      const text = `[과세특 입력] ${nav.step}에서 멈췄습니다.\n${errorText(nav)}`;
      await setFlowStatus(flow, text, 'error');
      return { ...nav, text };
    }
    await setFlowStatus(flow, '과세특 메뉴를 여는 중…');
    const res = await inNeis(openRemarksMenuInPage, [C, NEIS_SUBJECT_REMARKS]);
    if (!res.ok) {
      const text = `[과세특 입력] 과세특 메뉴 열기에서 멈췄습니다.\n${errorText(res)}`;
      await setFlowStatus(flow, text, 'error');
      if (res.tabId) await chrome.scripting.executeScript({ target: { tabId: res.tabId }, func: toastInPage, args: [text, true] }).catch(() => {});
      return { ...res, step: '과세특 메뉴 열기', text };
    }
    const text = res.stage === 'open'
      ? '[과세특 입력] 과세특 화면을 열었습니다. 학기·과목·강의실을 고르고 [조회]하세요.'
      : '[과세특 입력] OTP(2차 인증)를 직접 입력하세요.\n그다음 학기·과목·강의실을 고르고 [조회]하면 쌤패스 과세특 탭이 명단을 읽습니다.';
    await setFlowStatus(flow, text, 'done');
    await chrome.tabs.update(res.tabId, { active: true }).catch(() => {});
    await chrome.windows.update(res.windowId, { focused: true }).catch(() => {});
    await chrome.scripting.executeScript({ target: { tabId: res.tabId }, func: toastInPage, args: [text, false] }).catch(() => {});
    return { ok: true, stage: res.stage, text };
  } finally {
    flowRunning = false;
  }
}

async function remarksWrite(items) {
  const valid = Array.isArray(items) && items.length <= 200 && items.every((it) => it
    && Number.isInteger(it.i) && it.i >= 0 && typeof it.classNo === 'string' && typeof it.name === 'string'
    && typeof it.text === 'string' && it.text.length > 0 && it.text.length <= 3000);
  if (!valid) return { ok: false, error: 'invalid_items' };
  const res = await inNeis(writeRowsInPage, [NEIS_SUBJECT_REMARKS, items]);
  // 넣은 내용을 확인하고 [저장]할 수 있게 나이스 탭을 앞으로
  if (res.ok) {
    await chrome.tabs.update(res.tabId, { active: true }).catch(() => {});
    await chrome.windows.update(res.windowId, { focused: true }).catch(() => {});
  }
  return res;
}

// ── 업데이트 알림 ──
// 0.15.0부터 확장이 스스로 파일을 바꾸지 않는다(도우미 프로그램 없음). 소개 페이지의 latest.json에서 새 버전이 있는지만 보고
// 툴바 배지(NEW)·팝업·설정 화면으로 알린다. [받으러 가기]는 설치 안내 페이지를 연다.
// 선생님이 새 설치 파일을 실행하면 같은 폴더의 파일이 바뀌고, 쌤패스가 그걸 알아채 스스로 다시 시작한다(reloadIfFilesChanged).
// latest.json의 서명은 0.14.x의 도우미 프로그램용이다. 여기서는 버전·설명만 읽고, 받는 곳은 아래 고정 주소만 연다.
const LATEST_URL = 'https://hirame-ki.github.io/pass/update/latest.json';
const DOWNLOAD_PAGE = 'https://hirame-ki.github.io/pass/install.html#update';
const UPDATE_ALARM = 'update-check';
const FILES_ALARM = 'files-check';
chrome.alarms.get(UPDATE_ALARM).then((a) => {
  if (!a) chrome.alarms.create(UPDATE_ALARM, { delayInMinutes: 1, periodInMinutes: 360 });
});

function isNewer(a, b) {
  const pa = a.split('.').map(Number), pb = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  return false;
}

async function checkForUpdate() {
  const current = chrome.runtime.getManifest().version;
  const { update: prev } = await chrome.storage.local.get('update');
  let update;
  try {
    const r = await fetch(`${LATEST_URL}?t=${Date.now()}`, { cache: 'no-store', credentials: 'omit' });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const info = await r.json();
    if (typeof info.version !== 'string' || !/^\d+\.\d+\.\d+$/.test(info.version)) throw new Error('bad version');
    const available = isNewer(info.version, current);
    update = { checkedAt: Date.now(), ok: true, error: null, available, version: info.version,
      notes: available && typeof info.notes === 'string' ? info.notes.slice(0, 500) : '' };
  } catch {
    // 인터넷이 안 될 때는 지난번에 알게 된 새 버전 안내를 그대로 둔다
    const keep = prev?.available && prev.version && isNewer(prev.version, current);
    update = { checkedAt: Date.now(), ok: false, error: 'update_check_failed',
      available: !!keep, version: keep ? prev.version : null, notes: keep ? prev.notes || '' : '' };
  }
  await chrome.storage.local.set({ update });
  await refreshBadge();
  // 새 버전을 기다리는 동안은 1분마다 '설치 파일을 실행했는지'(파일이 바뀌었는지) 본다
  if (update.available) await chrome.alarms.create(FILES_ALARM, { delayInMinutes: 1, periodInMinutes: 1 });
  else await chrome.alarms.clear(FILES_ALARM);
  return update.ok ? { ok: true, ...update } : { ...update, ok: false };
}

// 설치 파일로 새 버전을 덮어쓰면 디스크의 manifest.json이 바뀐다. 실행 중인 버전과 다르면 다시 시작한다.
// 루틴·복무 신청이 도는 중이거나 과세특 입력 화면이 열려 있으면 기다린다(다시 시작하면 그 화면이 닫힘).
async function reloadIfFilesChanged() {
  let disk;
  try {
    disk = await (await fetch(chrome.runtime.getURL('manifest.json'), { cache: 'no-store' })).json();
  } catch { return false; }
  if (!disk?.version || disk.version === chrome.runtime.getManifest().version) return false;
  if (flowRunning || routeRunning) return false;
  const pages = await chrome.runtime.getContexts({ contextTypes: ['TAB'], documentUrls: [chrome.runtime.getURL('remarks.html')] });
  if (pages.length) return false;
  setTimeout(() => chrome.runtime.reload(), 100);
  return true;
}

function openUpdatePage() {
  return chrome.tabs.create({ url: DOWNLOAD_PAGE }).then(() => ({ ok: true }));
}

// 툴바 아이콘 배지: 잠금이 풀려 있으면 ON(초록), 잠겨 있고 새 버전이 있으면 NEW(주황)
async function refreshBadge(unlocked) {
  if (unlocked === undefined) unlocked = await isUnlocked();
  const { update } = await chrome.storage.local.get('update');
  const fresh = update?.available === true;
  await chrome.action.setBadgeBackgroundColor({ color: unlocked ? '#1f9d55' : '#f76707' });
  await chrome.action.setBadgeText({ text: unlocked ? 'ON' : fresh ? 'NEW' : '' });
  await chrome.action.setTitle({ title: fresh ? `쌤패스 · 새 버전 ${update.version}이 나왔어요` : '쌤패스' });
}

// ── 단축키 (chrome://extensions/shortcuts 에서 바꿀 수 있음) ──

function todayIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

chrome.commands.onCommand.addListener(async (command) => {
  if (!(await isUnlocked())) {
    // 잠겨 있으면 PIN을 넣을 수 있게 팝업을 연다 (지원하지 않는 크롬이면 안내만)
    try { await chrome.action.openPopup(); } catch { await notify(null, '쌤패스가 잠겨 있습니다. 툴바 아이콘에서 PIN으로 잠금을 푸세요.', true); }
    return;
  }
  if (command === 'open-edufine') {
    const res = await openPortalMenu(PORTAL_MAIN.edufineLabel);
    if (!res.ok) await notify(null, errorText(res), true);
    return;
  }
  if (command === 'portal-login') {
    const res = await loginFromButton();
    if (!res.ok) await notify(res.tabId, errorText(res), true);
    return;
  }
  const m = /^route-(\d)$/.exec(command);
  if (m) {
    const { routes = [] } = await chrome.storage.local.get('routes');
    const route = routes[Number(m[1]) - 1];
    if (!route) return notify(null, `복무 신청 ${m[1]}번 버튼이 설정에 없습니다.`, true);
    const res = await runRoute(route.id, todayIso());
    if (!res.ok && !res.step) await notify(null, errorText(res), true); // 나이스 안에서 멈춘 경우는 runRoute가 이미 안내함
  }
});

// ── 팝업/설정 화면과의 메시지 ──

async function getState() {
  if (await reloadIfFilesChanged()) return { ok: false, error: 'reloading' };
  const [status, settings, session] = await Promise.all([
    vault.status(),
    getSettings(),
    chrome.storage.session.get(['password', 'unlockedAt', 'lastLock']),
  ]);
  return {
    ok: true,
    configured: status.configured === true,
    lockedUntil: status.lockedUntil || 0,
    unlocked: typeof session.password === 'string',
    unlockedAt: session.unlockedAt || null,
    lastLock: session.lastLock || null,
    lastRun: (await chrome.storage.session.get('lastRun')).lastRun || null,
    settings,
    flowStatus: (await chrome.storage.session.get('flowStatus')).flowStatus || null,
    version: chrome.runtime.getManifest().version,
    ...(await chrome.storage.local.get({ update: null, justUpdated: null, vaultMoved: false })),
    ...(await chrome.storage.local.get({ routes: [], flows: [], portalUrl: PORTAL_MAIN.defaultUrl, autoSubmit: false, autoSubmitAgreedAt: null, autoLogin: false, autoLoginBlocked: false })),
  };
}

async function handle(msg) {
  switch (msg?.cmd) {
    case 'getState': return getState();
    case 'unlock': return unlock(msg.pin, msg.skipAutoLogin === true);
    case 'lock': await lock('manual'); return { ok: true };
    case 'fillPassword': return fillPassword();
    case 'portalLogin': return loginFromButton();
    case 'setLockMode': return setLockMode(msg.mode, msg.agreed);
    case 'checkUpdate': return checkForUpdate();
    case 'openUpdatePage': return openUpdatePage();
    case 'clearJustUpdated': await chrome.storage.local.remove('justUpdated'); return { ok: true };
    case 'openEdufine': return openPortalMenu(PORTAL_MAIN.edufineLabel);
    case 'dumpStructure': return dumpStructure();
    case 'runRoute': return runRoute(msg.routeId, msg.date, { start: msg.start || '', end: msg.end || '' });
    case 'saveRoutes': return saveRoutes(msg.routes);
    case 'setAutoSubmit': return setAutoSubmit(msg.enabled === true, msg.agreed);
    case 'runFlow': return runFlow(msg.flowId);
    case 'saveFlows': return saveFlows(msg.flows);
    case 'setPortalUrl': return setPortalUrl(msg.url);
    case 'remarksRoster': return remarksRoster();
    case 'remarksGo': return remarksGo();
    case 'remarksWrite': return remarksWrite(msg.items);
    case 'setAutoLogin':
      // 켤 때 이전의 '실패로 멈춤' 상태도 풀어 준다
      await chrome.storage.local.set({ autoLogin: msg.enabled === true, autoLoginBlocked: false });
      await chrome.storage.session.set({ autoPending: false });
      return { ok: true };
    case 'setup': {
      const res = await vault.setup(msg.password, msg.pin);
      if (res.ok) await chrome.storage.local.remove('vaultMoved');
      return res;
    }
    case 'changePin': return vault.changePin(msg.pin, msg.newPin);
    case 'updatePassword': {
      const res = await vault.updatePassword(msg.pin, msg.password);
      if (res.ok) await lock('password_changed'); // 메모리에 남은 옛 비밀번호 제거
      return res;
    }
    case 'reset': {
      await lock('reset');
      return vault.reset();
    }
    case 'saveSettings': {
      const idle = Number(msg.idleMinutes), max = Number(msg.maxUnlockMinutes);
      if (!(idle >= 1 && idle <= 60 && max >= 5 && max <= 480)) return { ok: false, error: 'invalid_settings' };
      await chrome.storage.local.set({ idleMinutes: idle, maxUnlockMinutes: max });
      await applyIdleInterval();
      return { ok: true };
    }
    default: return { ok: false, error: 'unknown_command' };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // 확장 자체 화면(팝업·설정)에서 온 요청만 받는다. 나이스 페이지에 들어간 스크립트는 거부.
  if (sender.id !== chrome.runtime.id || !sender.url?.startsWith(EXT_ORIGIN)) {
    sendResponse({ ok: false, error: 'forbidden' });
    return false;
  }
  handle(msg).then(sendResponse, (e) => sendResponse({ ok: false, error: 'internal', detail: String(e) }));
  return true;
});
