// 과세특 입력 화면 — 1단계: 엑셀을 읽어 열을 알아보고, 사람이 확인·수정한다.
// 학생 정보는 이 화면의 메모리에만 있다. storage에 저장하지 않고, 화면을 닫으면 사라진다. (저장하는 것은 열 배치 기억뿐: 머리글 해시와 열 역할)
import { readSpreadsheet } from './xlsx-read.js';
import { analyzeSheet, buildRecords, neisBytes, ROLES, NEIS_MAX_BYTES } from './excel-map.js';
import { matchRoster, STATUS } from './remarks-match.js';
import { send, errorText, showMsg, busy, $ } from './common.js';

const READ_ERRORS = {
  xls_unsupported: '옛 엑셀 형식(.xls)입니다. 엑셀에서 [다른 이름으로 저장] → "Excel 통합 문서(*.xlsx)"로 저장한 뒤 다시 고르세요.',
  xlsx_encrypted: '암호가 걸린 파일입니다. 엑셀에서 암호를 해제하고 저장한 뒤 다시 고르세요.',
  not_spreadsheet: '엑셀(.xlsx)이나 CSV 파일이 아닌 것 같습니다.',
};

let sheets = []; // [{ analysis, roles, records }]

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}

function colName(i) {
  let s = '';
  for (let n = i + 1; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + ((n - 1) % 26)) + s;
  return s;
}

function setStep(step) {
  const order = ['file', 'check', 'neis', 'input'];
  for (const li of $('stepper').children) {
    const i = order.indexOf(li.dataset.step), cur = order.indexOf(step);
    li.className = i < cur ? 'done' : i === cur ? 'on' : '';
  }
}

// ── 파일 읽기 ──

async function load(file) {
  showMsg($('fileMsg'), `${file.name} 읽는 중…`, 'pending');
  try {
    const wb = await readSpreadsheet(file.name, await file.arrayBuffer());
    sheets = wb.sheets.map((s) => {
      const analysis = analyzeSheet(s);
      return { analysis, roles: { ...analysis.roles }, records: buildRecords(analysis) };
    }).filter((s) => s.records.length || s.analysis.rows.length > 1);
    await applyRememberedLayouts();
    if (!sheets.some((s) => s.records.length)) {
      showMsg($('fileMsg'), '학생 목록을 찾지 못했습니다. 이름·번호가 있는 엑셀인지 확인하세요.\n아래 [파일 구조 복사]를 눌러 붙여 주시면 원인을 찾을 수 있습니다. (이름·내용은 가려집니다)');
      return offerStructure(file.name, wb);
    }
    showMsg($('fileMsg'), '');
    $('fileCard').classList.add('hidden');
    $('checkCard').classList.remove('hidden');
    setStep('check');
    render();
  } catch (e) {
    showMsg($('fileMsg'), READ_ERRORS[e.code] || `파일을 읽지 못했습니다. (${e.message})`);
  }
}

// ── 열 배치 기억하기 ──
// 사람이 열 역할을 고치면 그 양식(머리글 줄)을 기억해 두었다가 같은 양식이면 다음부터 자동으로 적용한다.
// 저장하는 것: 머리글 줄의 해시(글자 자체는 저장 안 함)와 열 번호→역할. 학생 정보는 저장하지 않는다.

const LAYOUT_KEY = 'excelLayouts';
const MAX_LAYOUTS = 30;

async function layoutKey(analysis) {
  if (analysis.headerRow < 0) return null; // 머리글 없는 양식은 알아볼 근거가 약해 기억하지 않는다
  const sig = `${analysis.columns.length}|${analysis.columns.map((c) => c.header.replace(/\s+/g, '')).join('\u0001')}`;
  const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(sig));
  return [...new Uint8Array(hash)].slice(0, 12).map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function loadLayouts() {
  return (await chrome.storage.local.get(LAYOUT_KEY))[LAYOUT_KEY] || {};
}

async function applyRememberedLayouts() {
  const layouts = await loadLayouts();
  for (const s of sheets) {
    s.key = await layoutKey(s.analysis);
    const saved = s.key && layouts[s.key];
    if (!saved) continue;
    const roles = { ...s.analysis.roles };
    for (const [c, role] of Object.entries(saved.roles)) if (c in roles && role in ROLES) roles[c] = role;
    s.roles = roles;
    s.records = buildRecords(s.analysis, roles);
    s.remembered = true;
  }
}

const sameRoles = (a, b) => Object.keys(a).every((k) => a[k] === b[k]);

// 다음 단계로 갈 때: 자동 인식과 다르게 고친 시트만 기억, 자동 인식과 같아졌으면 기억을 지움
async function saveLayouts() {
  const layouts = await loadLayouts();
  for (const s of sheets) {
    if (!s.key) continue;
    if (sameRoles(s.roles, s.analysis.roles)) delete layouts[s.key];
    else layouts[s.key] = { roles: s.roles, savedAt: Date.now() };
  }
  const keys = Object.keys(layouts).sort((a, b) => layouts[b].savedAt - layouts[a].savedAt);
  for (const k of keys.slice(MAX_LAYOUTS)) delete layouts[k];
  await chrome.storage.local.set({ [LAYOUT_KEY]: layouts });
}

async function forgetLayout(s) {
  const layouts = await loadLayouts();
  delete layouts[s.key];
  await chrome.storage.local.set({ [LAYOUT_KEY]: layouts });
  s.roles = { ...s.analysis.roles };
  s.records = buildRecords(s.analysis, s.roles);
  s.remembered = false;
  render();
}

// 인식 실패 진단: 파일 안 구성과 앞쪽 행의 "모양"만 복사한다 (한글→가, 숫자→9, 긴 글→글자 수)
function offerStructure(fileName, wb) {
  const mask = (v) => (v.length > 20 ? `(글 ${v.length}자)` : v.replace(/[가-힣]/g, '가').replace(/[A-Za-z]/g, 'A').replace(/[0-9]/g, '9'));
  const lines = [`# 파일 구조 (${fileName.replace(/^.*\./, '*.')})`, `시트 ${wb.sheets.length}개${wb.skipped?.length ? ` · 건너뜀: ${wb.skipped.map(mask).join(', ')}` : ''}`];
  if (wb.parts) lines.push(`구성: ${wb.parts.join(', ')}`);
  for (const s of wb.sheets) {
    lines.push(`\n[시트 ${mask(s.name)}] ${s.rows.length}행 × ${s.rows[0]?.length || 0}열 · 병합 ${s.merges.length} · 숨긴 열 ${[...s.hiddenCols].join(',') || '없음'}`);
    s.rows.slice(0, 6).forEach((r, i) => lines.push(`${i + 1}행: ${r.map((v) => mask(String(v)) || '·').join(' | ')}`));
  }
  const btn = el('button', 'block gap', '파일 구조 복사');
  btn.addEventListener('click', async () => {
    await navigator.clipboard.writeText(lines.join('\n'));
    btn.textContent = '복사했습니다 — 대화창에 붙여 주세요';
  });
  $('fileMsg').after(btn);
}

$('fileInput').addEventListener('change', () => { const f = $('fileInput').files[0]; if (f) load(f); });
for (const ev of ['dragenter', 'dragover']) $('drop').addEventListener(ev, (e) => { e.preventDefault(); $('drop').classList.add('over'); });
for (const ev of ['dragleave', 'drop']) $('drop').addEventListener(ev, () => $('drop').classList.remove('over'));
$('drop').addEventListener('drop', (e) => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) load(f); });
$('resetBtn').addEventListener('click', () => {
  stopPolling();
  sheets = [];
  $('fileInput').value = '';
  $('checkCard').classList.add('hidden');
  $('fileCard').classList.remove('hidden');
  setStep('file');
});

// ── 확인 화면 ──

function render() {
  renderSummary();
  $('sheetList').replaceChildren(...sheets.map(sheetCard));
}

function renderSummary() {
  const all = sheets.flatMap((s) => s.records);
  const bad = all.filter((r) => r.issues.some((x) => x.level === 'error')).length;
  const warn = all.filter((r) => !r.issues.some((x) => x.level === 'error') && r.issues.length).length;
  const box = $('summary');
  box.replaceChildren(
    el('h2', '', `학생 ${all.length}명을 찾았어요`),
    el('p', 'muted', `시트 ${sheets.filter((s) => s.records.length).length}개 · 바이트는 과목 한도 ${NEIS_MAX_BYTES} 기준으로 먼저 봅니다. 학생별 남은 바이트(1학기 사용분 제외)는 나이스 조회 뒤 다시 검사합니다.`),
  );
  const chips = el('div', 'chips');
  chips.append(el('span', 'pill on', `문제 없음 ${all.length - bad - warn}명`));
  if (warn) chips.append(el('span', 'pill warn', `확인 필요 ${warn}명`));
  if (bad) chips.append(el('span', 'pill off', `입력 불가 ${bad}명`));
  box.append(chips);
}

function contextChips(ctx) {
  const box = el('div', 'chips');
  const items = [['학년', ctx.grade], ['반', ctx.class], ['과목', ctx.subject], ['강의실', ctx.room]].filter(([, v]) => v);
  if (!items.length) box.append(el('span', 'muted', '제목 줄·시트 이름에서 읽은 정보 없음'));
  for (const [k, v] of items) box.append(el('span', 'pill', `${k} ${v}`));
  return box;
}

function sheetCard(s) {
  const card = el('section', 'card sheet');
  const head = el('div', 'sheet-head');
  head.append(el('h2', '', `시트 "${s.analysis.name}"`), el('span', 'muted', `${s.records.length}명`));
  card.append(head, contextChips(s.analysis.context));
  if (s.remembered) {
    const mem = el('p', 'note ok');
    mem.append(el('span', '', '지난번에 고친 열 배치를 이 양식에 적용했어요. '));
    const undo = el('button', 'ghost', '자동 인식으로 되돌리기');
    undo.addEventListener('click', () => forgetLayout(s));
    mem.append(undo);
    card.append(mem);
  }

  // 열 역할: 틀리면 고른다
  card.append(el('h3', 'gap-lg', '이렇게 이해했어요 — 틀리면 바꿔 주세요'));
  const roleTable = el('div', 'role-grid');
  for (const col of s.analysis.columns) {
    if (!col.header && !col.sample) continue;
    const item = el('label', `role-item${s.roles[col.index] === 'ignore' ? ' off' : ''}`);
    const top = el('span', 'role-col', `${colName(col.index)}열${col.header ? ` · ${col.header}` : ''}${col.hidden ? ' (숨김)' : ''}`);
    const sel = el('select');
    for (const [v, t] of Object.entries(ROLES)) sel.append(new Option(t, v, false, v === s.roles[col.index]));
    sel.addEventListener('change', () => {
      s.roles[col.index] = sel.value;
      item.classList.toggle('off', sel.value === 'ignore');
      s.records = buildRecords(s.analysis, s.roles);
      renderSummary();
      card.querySelector('.rec-wrap').replaceWith(recordTable(s));
      head.lastChild.textContent = `${s.records.length}명`;
    });
    item.append(top, sel, el('small', 'role-sample', col.sample.replace(/\s+/g, ' ').slice(0, 40) || '(빈 칸)'));
    roleTable.append(item);
  }
  card.append(roleTable, recordTable(s));
  return card;
}

function recordTable(s) {
  const wrap = el('div', 'rec-wrap');
  const table = el('table', 'rec');
  const thead = el('thead');
  const hr = el('tr');
  for (const h of ['행', '학년', '반', '번호', '이름', '바이트', '내용', '상태']) hr.append(el('th', '', h));
  thead.append(hr);
  const tbody = el('tbody');
  for (const r of s.records) {
    const tr = el('tr');
    const level = r.issues.some((x) => x.level === 'error') ? 'error' : r.issues.length ? 'warn' : '';
    if (level) tr.className = level;
    const bytes = neisBytes(r.content);
    tr.append(el('td', 'num', String(r.row)), el('td', 'num', String(r.grade || '')), el('td', 'num', String(r.class || '')),
      el('td', 'num', String(r.number || '')), el('td', 'name', r.name), el('td', `num${bytes > NEIS_MAX_BYTES ? ' bad' : ''}`, String(bytes)));
    const c = el('td', 'content', r.content.length > 60 ? `${r.content.slice(0, 60)}…` : r.content);
    c.title = r.content;
    tr.append(c);
    const st = el('td', 'state');
    if (!r.issues.length) st.append(el('span', 'pill on', '좋음'));
    for (const x of r.issues) st.append(el('span', `pill ${x.level === 'error' ? 'off' : 'warn'}`, x.text));
    tr.append(st);
    tbody.append(tr);
  }
  table.append(thead, tbody);
  wrap.append(table);
  return wrap;
}

// ════════ 3·4단계: 나이스 명단 맞추기 → 입력 → 저장 기다리기 ════════
// 나이스 화면을 2.5초마다 읽어(명단·내용·저장 여부만) 화면을 갱신한다. 값을 넣는 것은 [입력 시작]을 눌렀을 때 한 번뿐.

let pollTimer = null;
let rosterSig = '';
let roster = null;
let match = null;
let written = [];            // 마지막으로 넣은 것 [{ i, classNo, name, text }]
let writtenKeys = [];        // 그 엑셀 학생들
let waitingNextRoom = '';    // 저장을 마친 강의실 — 다른 강의실이 조회될 때까지 기다림
const overwrite = new Set(); // 덮어쓰기 체크한 나이스 행
const doneKeys = new Set();  // 저장까지 확인된 엑셀 학생

const recKey = (rec) => `${rec.sheet}|${rec.row}`;
const roomKey = (res) => `${res.subject}|${res.rows.map((r) => r.classNo).join(',')}`;

function allRecords() {
  return sheets.flatMap((s) => s.records.map((r) => Object.assign(r, { sheet: s.analysis.name })));
}
function remainingCount() {
  return allRecords().filter((r) => r.name && r.number && r.content && !doneKeys.has(recKey(r))).length;
}

function showSection(id) {
  for (const s of ['fileCard', 'checkCard', 'neisCard', 'doneCard']) $(s).classList.toggle('hidden', s !== id);
}
function stopPolling() { clearInterval(pollTimer); pollTimer = null; }
function startPolling(fn) { stopPolling(); fn(); pollTimer = setInterval(fn, 2500); }
function note(elm, text, kind = '') { elm.textContent = text; elm.className = `note${kind ? ` ${kind}` : ''}`; }

function enterNeis(message) {
  rosterSig = '';
  showSection('neisCard');
  setStep('neis');
  $('waitCard').classList.remove('hidden');
  $('matchCard').classList.add('hidden');
  note($('rosterState'), message || '나이스 조회를 기다리는 중…');
  startPolling(pollRoster);
}

// ── 나이스 과세특 화면까지 자동으로 (팝업 [과세특 입력] → remarks.html?go=1) ──
// 업무포털 로그인 → 나이스 → 교과담임 › 성적처리 › 과목별세부능력및특기사항 → OTP 창. 이미 된 단계는 건너뛴다.
// OTP는 선생님이 직접 입력한다. 그동안 이 탭에서 엑셀을 골라 두면 된다.
async function goToNeis() {
  showMsg($('goMsg'), '업무포털 로그인 → 나이스 → 과세특 메뉴로 가는 중…', 'pending');
  const res = await busy($('goBtn'), () => send('remarksGo'));
  if (!res.ok) {
    return showMsg($('goMsg'), `${errorText(res)}\n나이스에서 직접 교과담임 › 성적처리 › 과목별세부능력및특기사항을 열어도 됩니다.`);
  }
  const text = {
    otp: '나이스 탭에서 OTP(2차 인증)를 입력하세요. 그동안 여기서 엑셀 파일을 골라 두면 됩니다.',
    open: '나이스 과세특 화면이 열려 있어요. 엑셀 파일을 고르세요.',
    clicked: '나이스 과세특 메뉴를 눌렀어요. OTP 창이 보이면 입력하세요.',
  }[res.stage] || '';
  showMsg($('goMsg'), text, 'good');
}

$('goBtn').addEventListener('click', goToNeis);
chrome.storage.onChanged.addListener((changes, area) => {
  const st = area === 'session' && changes.flowStatus?.newValue;
  if (st && st.id === 'remarks' && st.state === 'run') showMsg($('goMsg'), st.text, 'pending');
});
if (new URLSearchParams(location.search).get('go') === '1') {
  history.replaceState(null, '', location.pathname); // 새로 고쳐도 다시 가지 않게
  goToNeis();
}

$('nextBtn').addEventListener('click', () => {
  saveLayouts().catch(() => {}); // 고친 열 배치를 기억 (실패해도 진행에는 영향 없음)
  enterNeis();
});
$('backBtn').addEventListener('click', () => { stopPolling(); showSection('checkCard'); setStep('check'); });

async function pollRoster() {
  const res = await send('remarksRoster');
  if (!res.ok || !res.rows.length) {
    rosterSig = '';
    $('waitCard').classList.remove('hidden');
    $('matchCard').classList.add('hidden');
    if (!waitingNextRoom) note($('rosterState'), res.ok ? '조회된 학생이 없습니다. 과목·강의실을 고르고 [조회]하세요.' : errorText(res), 'warn');
    return;
  }
  if (waitingNextRoom && roomKey(res) === waitingNextRoom) return; // 아직 방금 저장한 강의실
  waitingNextRoom = '';
  updateAuth(res.authSeconds);
  const sig = `${roomKey(res)}|${res.rows.map((r) => `${r.name}:${r.current.length}`).join(',')}`;
  if (sig === rosterSig) return;
  rosterSig = sig;
  roster = res;
  overwrite.clear();
  match = matchRoster(res, allRecords());
  $('waitCard').classList.add('hidden');
  $('matchCard').classList.remove('hidden');
  showMsg($('writeMsg'), '');
  renderMatch();
}

function updateAuth(sec) {
  const pill = $('authLeft');
  pill.classList.toggle('hidden', sec == null);
  if (sec == null) return;
  pill.textContent = `2차 인증 ${Math.floor(sec / 60)}분 ${sec % 60}초 남음`;
  pill.className = `pill${sec < 300 ? ' warn' : ''}`;
}

function renderMatch() {
  $('matchTitle').textContent = `${roster.grade ? `${roster.grade}학년 ` : ''}${roster.subject || '과목'} · 나이스 명단 ${roster.rows.length}명`;
  const count = (st) => match.rows.filter((m) => m.status === st).length;
  const chips = $('matchChips');
  chips.replaceChildren();
  const bad = match.rows.filter((m) => STATUS[m.status].level === 'error').length;
  chips.append(el('span', 'pill on', `입력 예정 ${count('ready')}명`));
  if (count('has_content')) chips.append(el('span', 'pill warn', `나이스에 내용 있음 ${count('has_content')}명`));
  if (count('same')) chips.append(el('span', 'pill', `이미 같은 내용 ${count('same')}명`));
  if (bad) chips.append(el('span', 'pill off', `넣지 않음 ${bad}명`));
  if (count('no_excel') + count('empty')) chips.append(el('span', 'pill', `엑셀에 없음·빈 내용 ${count('no_excel') + count('empty')}명`));
  const others = match.leftover.filter((r) => !doneKeys.has(recKey(r))).length; // 이미 저장까지 끝낸 학생은 빼고
  if (others) chips.append(el('span', 'pill', `엑셀의 다른 강의실 학생 ${others}명`));

  const head = el('tr');
  for (const h of ['반/번호', '이름', '바이트', '엑셀', '상태', '덮어쓰기']) head.append(el('th', '', h));
  const thead = el('thead');
  thead.append(head);
  const tbody = el('tbody');
  for (const m of match.rows) {
    const lv = STATUS[m.status].level;
    const tr = el('tr', lv === 'error' ? 'error' : lv === 'warn' ? 'warn' : '');
    if (m.rec) tr.title = m.rec.content;
    tr.append(el('td', 'num', m.r.classNo), el('td', 'name', m.r.name),
      el('td', `num${m.status === 'over' ? ' bad' : ''}`, m.rec ? `${m.bytes} / ${m.r.limit}` : ''),
      el('td', 'num', m.rec ? `${m.rec.sheet} ${m.rec.row}행` : ''));
    const st = el('td', 'state');
    st.append(el('span', `pill ${lv === 'ok' ? 'on' : lv === 'error' ? 'off' : 'warn'}`, STATUS[m.status].text));
    if (m.note) st.append(el('small', 'muted', ` ${m.note}`));
    tr.append(st);
    const ow = el('td');
    if (m.status === 'has_content') {
      const box = el('input');
      box.type = 'checkbox';
      box.title = '나이스에 있는 내용을 엑셀 내용으로 바꾸기';
      box.addEventListener('change', () => { if (box.checked) overwrite.add(m.r.i); else overwrite.delete(m.r.i); updateWriteBtn(); });
      ow.append(box);
    }
    tr.append(ow);
    tbody.append(tr);
  }
  $('matchTable').replaceChildren(thead, tbody);
  $('overwriteBox').classList.add('hidden');
  updateWriteBtn();
}

function toWrite() {
  return match.rows.filter((m) => m.status === 'ready' || (m.status === 'has_content' && overwrite.has(m.r.i)));
}

function updateWriteBtn() {
  const n = toWrite().length;
  $('writeBtn').disabled = n === 0;
  $('writeBtn').textContent = n ? `입력 시작 (${n}명)` : '입력할 학생 없음';
}

$('writeBtn').addEventListener('click', () => {
  if (!overwrite.size) return doWrite();
  // 덮어쓰기는 한 번 더 확인
  $('overwriteCount').textContent = `기존 내용이 있는 ${overwrite.size}명의 내용을 엑셀 내용으로 바꿉니다.`;
  $('overwriteChk').checked = false;
  $('overwriteOkBtn').disabled = true;
  $('overwriteBox').classList.remove('hidden');
  stopPolling(); // 확인하는 동안 표가 바뀌지 않게
});
$('overwriteChk').addEventListener('change', () => { $('overwriteOkBtn').disabled = !$('overwriteChk').checked; });
$('overwriteCancelBtn').addEventListener('click', () => { $('overwriteBox').classList.add('hidden'); startPolling(pollRoster); });
$('overwriteOkBtn').addEventListener('click', () => { $('overwriteBox').classList.add('hidden'); doWrite(); });

async function doWrite() {
  const picks = toWrite();
  if (!picks.length) return;
  stopPolling();
  const items = picks.map((m) => ({ i: m.r.i, classNo: m.r.classNo, name: m.r.name, text: m.rec.content }));
  const res = await busy($('writeBtn'), () => send('remarksWrite', { items }));
  if (!res.ok) {
    showMsg($('writeMsg'), errorText(res));
    startPolling(pollRoster);
    return;
  }
  const okSet = new Set(res.results.filter((r) => r.ok).map((r) => r.i));
  written = items.filter((it) => okSet.has(it.i));
  writtenKeys = picks.filter((m) => okSet.has(m.r.i)).map((m) => recKey(m.rec));
  const failed = res.results.filter((r) => !r.ok).map((r) => ({ ...r, m: picks.find((m) => m.r.i === r.i) }));
  showDone(failed);
}

const WRITE_ERRORS = { row_changed: '나이스 명단이 바뀌어 넣지 않음', disabled: '입력할 수 없는 학생', verify_failed: '넣은 뒤 확인이 맞지 않음' };

function showDone(failed) {
  showSection('doneCard');
  setStep('input');
  $('doneTitle').textContent = `${written.length}명 입력했어요`;
  const box = $('doneProblems');
  box.replaceChildren();
  if (failed.length) {
    box.append(el('p', 'msg error', `${failed.length}명은 넣지 못했습니다.`));
    const ul = el('ul');
    for (const f of failed) ul.append(el('li', '', `${f.m.r.classNo} ${f.m.r.name} — ${WRITE_ERRORS[f.error] || f.error}`));
    box.append(ul);
  }
  if (roster.authSeconds != null && roster.authSeconds < 300) {
    box.append(el('p', 'note warn', '2차 인증 시간이 얼마 남지 않았습니다. [저장] 때 OTP를 다시 물으면 입력하세요. 내용이 사라지면 [다시 맞춰서 입력]을 누르면 됩니다.'));
  }
  note($('saveState'), '나이스에서 [저장]을 기다리는 중…');
  startPolling(pollSave);
}

async function pollSave() {
  const res = await send('remarksRoster');
  if (!res.ok) return note($('saveState'), errorText(res), 'warn');
  const byKey = new Map(res.rows.map((r) => [`${r.classNo}|${r.name}`, r]));
  let saved = 0, lost = 0, unknown = false;
  for (const it of written) {
    const r = byKey.get(`${it.classNo}|${it.name}`);
    if (!r) continue;
    if (r.current !== it.text) lost++;
    else if (r.changed === null) unknown = true;
    else if (!r.changed) saved++;
  }
  if (lost) {
    return note($('saveState'), `${lost}명의 입력 내용이 나이스 화면에서 사라졌습니다(다시 조회했거나 인증을 다시 한 경우). [다시 맞춰서 입력]을 누르세요.`, 'warn');
  }
  if (unknown) return note($('saveState'), '저장했는지 자동으로 확인할 수 없습니다. [저장]을 누른 뒤 [다음 강의실로]를 누르세요.');
  if (saved < written.length) return note($('saveState'), `나이스에서 [저장]을 기다리는 중… (${saved}/${written.length})`);

  // 저장 확인 → 다음 강의실로 이어감
  stopPolling();
  for (const k of writtenKeys) doneKeys.add(k);
  const left = remainingCount();
  if (!left) return note($('saveState'), '저장을 확인했습니다. 엑셀의 모든 학생을 마쳤어요.', 'ok');
  note($('saveState'), `저장을 확인했습니다. 다음 강의실로 넘어갑니다… (엑셀에 남은 학생 ${left}명)`, 'ok');
  waitingNextRoom = roomKey(res);
  setTimeout(goNextRoom, 1500);
}

function goNextRoom() {
  enterNeis(`나이스에서 다음 강의실을 고르고 [조회]하세요. (엑셀에 남은 학생 ${remainingCount()}명)`);
}

$('nextRoomBtn').addEventListener('click', () => {
  if (!waitingNextRoom && roster) waitingNextRoom = roomKey(roster);
  goNextRoom();
});
$('rewriteBtn').addEventListener('click', () => { waitingNextRoom = ''; enterNeis('나이스 화면을 다시 읽는 중…'); });
