// 화면 구조(셀렉터) 모음. 업무포털·나이스 화면이 바뀌면 여기만 고친다.
// 2026-10-14 경기(goe.eduptl.kr) 로그인 화면에서 확인. 인증서 창은 KSign KCase(웹 레이어, iframe 아님).

export const PORTAL_LOGIN = {
  // 로그인 화면의 "교육행정 전자서명 인증서 로그인" 버튼
  openButton: '#btnLgn',
  // 로그인 화면 주소에 들어 있는 글자 (goe.eduptl.kr/bpm_lgn_lg00_001.do). 로그인 여부 판단용
  loginPathPart: 'bpm_lgn',
  // 인증서 창
  dialog: '#kc_dialog_default',
  certRows: '#kc_cert_list table tbody tr',
  selectedRowClass: 'kc-tableview-selected-row',
  userColumn: 1, // 구분 | 사용자 | 만료일 | 발급자
  passwordInput: '#kc_dialog_default input[name=certPassword]',
  confirmButton: '#kc_dialog_default button.kc-btn-blue',
  // 인증서 목록을 불러오는 데 걸리는 최대 시간
  timeoutMs: 15000,
};

// 로그인 뒤 업무포털 메인(goe.eduptl.kr/bpm_man_mn00_001.do). 상단 메뉴: 업무협업G-ONE, 나이스, K-에듀파인, …
// 메뉴 링크 id에 SSO 주소가 들어 있음 (나이스: a#https://goe.neis.go.kr/cmc_fcm_lg01_000.do?data=… .menuBtn)
// K-에듀파인도 같은 구조로 추정 — 로그인 상태에서 재확인 필요
export const PORTAL_MAIN = {
  menuLink: 'a.menuBtn',
  edufineLabel: 'K-에듀파인',
  neisLabel: '나이스',
  // 열린 업무포털 탭이 없을 때 루틴이 여는 주소 (설정에서 바꿀 수 있음)
  defaultUrl: 'https://goe.eduptl.kr/',
};

// ── 나이스 (4세대, eXbuilder6 = 전역 `cpr`) ──
// HTML id가 매번 바뀌므로 화면(app) id + 컨트롤 id로 찾는다. 페이지 전역에 접근해야 해서 MAIN world에서 실행.
//   const app = cpr.core.Platform.INSTANCE.getAllRunningAppInstances().find(a => a.app.id === APP_ID);
//   app.lookup(CONTROL_ID).value = '...'  → 바인딩된 데이터셋과 시간 합계가 자동 갱신됨(2026-10-14 확인)
//   button.click()                        → 실제 클릭과 같이 동작 (신청 창 열기/닫기 확인)
//   grid.selectRows([i])                  → selection-change 발생. 셀 DOM에 마우스 이벤트를 쏴도 cell-click까지 발생
// 업무포털 상단 "나이스" 메뉴 → 새 탭 https://<지역>.neis.go.kr/jsp/main.jsp (SSO)

export const NEIS_COMMON = {
  // 왼쪽 메뉴 항목. 글자 뒤에 화면낭독용 " 0단계 메뉴항목"이 붙어 있어 떼고 비교한다.
  menuItem: 'a.cl-sidenavigation-item',
  menuLabelSuffix: /\s*\d+단계( 메뉴항목)?\s*$/,
  collapsedClass: 'cl-collapsed',
  // eXbuilder 컨트롤의 DOM id = 'uuid-' + control.uuid
  domIdPrefix: 'uuid-',
};

// 기안문서상신 창 ([승인요청] 뒤에 뜸). 여러 업무가 같이 쓰는 공통 결재 창.
export const NEIS_DRAFT = {
  app: 'edu/cm/wam/woa/pm/wam_woapm07_p00',
  myLine: 'btnSelectMySancr', // [개인결재선]
  approvers: 'grdSancr',      // dsSancr, 0번 행 = 기안자 본인
  submit: 'btnDrft',          // [상신]
  cancel: 'btnCancel',
  // [개인결재선] 창. 결재선은 ⚙개인설정 > 업무승인자관리 > 개인결재선관리 에서 만든다.
  lineApp: 'edu/cm/wam/woa/pm/wam_woapm07_p02',
  lineList: 'grd3',           // dsInvlSnclnList, 결재선명 칼럼 snclnNm
  lineNameCol: 'snclnNm',
  lineMembers: 'grd2',        // 행을 고르면 결재자가 채워짐
  lineApply: 'btn4',          // [지정]
  lineClose: 'btnCancel',
};

export const NEIS_OVERTIME = {
  // 기본 메뉴 > 복무 > 개인초과근무관리
  menu: { id: 'AMCMC40045', path: ['복무', '개인초과근무관리'] },
  listApp: 'edu/ga/srv/mym/mm/srv_mymmm02_m00',
  list: {
    yearMonth: 'dtiWorkYm',     // 조회 년월 (YYYYMM)
    search: 'btnSearch',
    apply: 'btnAply',           // [신청] → 신청 창 열림
    grid: 'grdMain',
  },
  formApp: 'edu/ga/srv/mym/mm/srv_mymmm02_p00', // 초과근무신청 창
  form: {
    // 여러 날 한 번에: 시작일~종료일 + [추가] (+ 휴일제외)
    rangeFrom: 'dtiMtWorkBgngYmd',
    rangeTo: 'dtiMtWorkEndYmd',
    rangeAdd: 'btnAdd',
    rangeExclHoliday: 'cbxExclHldy',
    grid: 'grdMain',            // 데이터셋 dsMain, 한 행 = 하루
    rowAdd: 'btnRowAdd',
    rowDel: 'btnRowDel',
    // 선택된 행의 상세 (창이 열리면 오늘 날짜 행 1개가 기본으로 있음)
    date: 'dtiMtWorkYmd',       // YYYYMMDD
    type: 'cmbMtWorkTypCd',     // 1=시간외 근무, 2=야간 근무, 3=휴일 근무
    holiday: 'cbxHldyYn',       // Y/N
    startH: 'ipbAplyBgngH', startM: 'ipbAplyBgngM',
    endH: 'ipbAplyEndH', endM: 'ipbAplyEndM',
    sumH: 'dtiMtWorkH', sumM: 'dtiMtWorkM',             // 자동 계산 (읽기용)
    deductH: 'dtiMtWorkItrtDdctH', deductM: 'dtiMtWorkItrtDdctM', // 방과후수업 차감시간
    reason: 'txaMtWorkRsnCn',   // 하여야 할 일 (필수)
    substituteLeave: 'cbxRplcDff', // 대체휴무 Y/N
    submit: 'btnAprvDmnd',      // [승인요청] → 임시저장 행이 생기고 기안문서상신 창(NEIS_DRAFT)이 뜸
    close: 'btnCancel',
  },
};

// 근무상황(조퇴·외출·지각 등): 기본 메뉴 > 복무 > 개인근무상황관리 > [신청] (2026-10-14 확인)
// 콤보박스는 value 대입만으로는 화면 로직(시간 계산·칸 활성화)이 안 돈다 → selectItemByValue(값, true)로 이벤트까지 발생시킬 것.
// 예) 조퇴 15:00~16:50 → 0일 1시간 50분 으로 자동 계산됨. [승인요청] 뒤는 시간외근무와 같은 기안문서상신 창(NEIS_DRAFT)으로 예상(미확인).
// 설정 화면에서 고를 수 있는 근무상황 소분류. 대분류는 앞 3글자 (W0104 → W01=연가, W0205 → W02=병가)
export const LEAVE_TYPES = { W0104: '조퇴', W0105: '외출', W0103: '지각', W0205: '병조퇴', W0206: '병외출', W0204: '병지각' };
export const AV_KINDS = { 1: '금년도연가', 2: '저축연가', 3: '연가당겨쓰기' }; // 연가(W01)일 때만

// 과목별세부능력및특기사항(과세특): 교과담임 > 성적처리 > 과목별세부능력및특기사항 (2026-10-15 [진단 정보 복사]로 확인, 아직 조작 안 해 봄)
// 조회 조건(학년도·학기·학년·과목·강의실)을 고르고 [조회]하면 표에 학생이 뜨고, 학생마다 오른쪽 칸에 바로 쓴다.
// 강의실은 이동반이라 "1C", "2F" 같은 이름이고, 한 강의실에 여러 반 학생이 섞인다 → 학생은 반/번호+이름으로 맞춘다.
// 학생마다 '일반'·'영재' 두 줄. 일반 = genDetaAbtSpablMteCn.
// 바이트 한도는 과목별로 정해져 있고(일반 1500), 화면의 "0 / 177 Byte"는 1학기에 이미 쓴 만큼을 뺀 이번 학기 남은 바이트(사용자 확인 10-15).
// othSemInputLen01 = 일반 칸 남은 바이트 그 자체(177·809·201… 화면과 일치), othSemInputLen02 = 영재 칸(1500).
// 들어가려면 2차 인증(OTP). 머리글에 "2차인증:26분 42초"처럼 남은 시간이 보인다.
// 나이스 자체 [엑셀내려받기]/[엑셀업로드]도 있다(btnExcelformDown/btnExcelformUp).
export const NEIS_SUBJECT_REMARKS = {
  app: 'edu/sw/his/scr/mc/his_scrmc50_m00',
  // 왼쪽 메뉴 경로 (사용자 안내 기준, 메뉴 DOM은 아직 확인 못 함 — 10-16). 첫 단계가 왼쪽 메뉴에 없으면 같은 이름의 탭·버튼을 눌러 본다.
  // 들어가면 2차 인증(OTP)을 묻는다 → 사용자가 직접 입력
  menu: { path: ['교과담임', '성적처리', '과목별세부능력및특기사항'] },
  search: 'btnSearch',
  hideGifted: 'cbxYjHide',        // 영재 미표시
  grid: 'grdMain',                // dsGridMain, 처음엔 rows=0 (조회 전)
  cols: {
    classNo: 'classNo',           // "반/번호" 글자 (예: 2/17) — 10-15 확인
    classOnly: 'clsNm',           // 반 (숫자 글자)
    numberOnly: 'stdntCn',        // 번호 (숫자 글자)
    remain: 'othSemInputLen01',   // 일반 칸 남은(입력 가능) 바이트 = 화면 "0 / 177 Byte"의 177 — 10-15 확인
    remainGifted: 'othSemInputLen02', // 영재 칸 남은 바이트
    subject: 'sbjtNm',
    grade: 'grd',
    name: 'stuFlnm',
    studentNo: 'stuInvlNo',
    general: 'genDetaAbtSpablMteCn',        // 세부능력 및 특기사항(일반)
    generalLen: 'genDetaAbtSpablMteCnLength',
    gifted: 'genGfcrRecMteCn',              // 영재 — 건드리지 않음
    enable: 'enableYn',
    status: 'enrScCd',                      // 학적변동 구분(재학 등)으로 추정
  },
  save: 'btnSave',                // [저장] — 사용자가 직접
  excelDown: 'btnExcelformDown',
  excelUp: 'btnExcelformUp',
};

export const NEIS_LEAVE = {
  menu: { path: ['복무', '개인근무상황관리'] },
  listApp: 'edu/ga/srv/mym/mm/srv_mymmm00_m00',
  list: { apply: 'btnAply' },
  formApp: 'edu/ga/srv/mym/mm/srv_mymmm00_p00', // 근무상황신청 창 (기본: 오늘 08:50~16:50 연가 1행)
  form: {
    grid: 'grdMain',
    lclf: 'cmbWorkSittnLclfCd',  // 대분류 W01=연가, W02=병가, …
    sclf: 'cmbWorkSittnSclfCd',  // 소분류 W0104=조퇴, W0105=외출, W0103=지각, W0205=병조퇴 …
    avKind: 'cmbAvAplyScCd',     // 연가종류 1=금년도연가, 2=저축연가, 3=연가당겨쓰기
    dateFrom: 'dtiWorkYmdFrom', startH: 'cmbBgngH', startM: 'cmbBgngM', // 분은 5분 단위
    dateTo: 'dtiWorkYmdTo', endH: 'cmbEndH', endM: 'cmbEndM',
    days: 'nbeWorkSittnDdTtl', hours: 'nbeWorkSittnHrTtl', minutes: 'nbeWorkSittnMTtl', // 자동 계산
    contact: 'mse1',             // 연락처 (000)0000-0000, 선택
    reason: 'ipbWorkSittnRsnCn', // 사유 (최대 400자)
    hidePeriod: 'cbxPrdYn',      // 비공개: 기간
    hideReason: 'cbxWorkSittnRsnCnYn', // 비공개: 사유
    submit: 'btnAprvDmnd',
    close: 'btnCancel',
  },
};
