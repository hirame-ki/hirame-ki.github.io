// 과세특 — 나이스 페이지 안(MAIN world)에서 실행되는 함수들. executeScript의 func로 넘기므로 바깥 변수를 쓰면 안 된다(인자만).
// cfg = NEIS_SUBJECT_REMARKS (sites.js)
//
// 확인된 것 (10-15, [진단 정보 복사])
//   dsGridMain 한 행 = 학생 한 명. clsNm=반, stdntCn=번호, classNo="반/번호", stuFlnm=이름
//   genDetaAbtSpablMteCn = 일반 세특, genDetaAbtSpablMteCnLength = 그 바이트
//   othSemInputLen01 = 일반 칸의 남은(입력 가능) 바이트 — 화면 "0 / 177 Byte"의 177
//   enableYn = 입력 가능 여부
// 값 넣기는 화면 안에서만 일어나고(서버 통신 없음), [저장]을 눌러야 나이스에 기록된다.

// 왼쪽 메뉴로 과세특 화면을 연다 (cfg.menu.path). 메뉴를 누르면 나이스가 2차 인증(OTP)을 묻는다.
// OTP는 사용자가 직접 넣는다 — 여기서는 그 창이 뜨는 것까지만 보고 아무것도 입력하지 않는다.
// stage: 'open'(과세특 화면이 열려 있음) | 'otp'(새 창이 뜸 = 2차 인증) | 'clicked'(메뉴는 눌렀지만 결과를 확인 못 함)
// C = NEIS_COMMON
export async function openRemarksMenuInPage(C, cfg) {
  const P = window.cpr?.core?.Platform?.INSTANCE;
  if (!P) return { ok: false, error: 'not_exbuilder' };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const vis = (e) => !!e && !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
  const running = () => P.getAllRunningAppInstances();
  const waitFor = async (fn, ms) => {
    const end = Date.now() + ms;
    for (;;) {
      let v = null;
      try { v = fn(); } catch { /* 화면이 아직 준비 안 됨 */ }
      if (v) return v;
      if (Date.now() > end) return null;
      await sleep(150);
    }
  };
  const fire = (el) => {
    for (const t of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
      el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
    }
  };
  const isOpen = () => running().some((a) => a.app.id === cfg.app);
  if (isOpen()) return { ok: true, stage: 'open' };

  const suffix = new RegExp(C.menuLabelSuffix);
  const norm = (s) => s.replace(suffix, '').replace(/\s+/g, '');
  const menuItem = (t) => [...document.querySelectorAll(C.menuItem)].find((a) => vis(a) && norm(a.textContent) === norm(t));
  // 왼쪽 메뉴 밖의, 같은 이름을 가진 탭·버튼 (업무 고르기 등). 글자가 정확히 같은 가장 안쪽 요소
  const byText = (t) => [...document.querySelectorAll('a, button, [role=tab], li, span, div')]
    .filter((e) => vis(e) && !e.closest(C.menuItem) && norm(e.textContent) === norm(t))
    .find((e, _, all) => !all.some((o) => o !== e && e.contains(o)));
  const dialogs = () => [...document.querySelectorAll('.cl-dialog')].filter(vis).length;
  const appsBefore = new Set(running().map((a) => a.app.id));
  const dialogsBefore = dialogs();

  const path = cfg.menu.path;
  let i = 0;
  if (!(await waitFor(() => menuItem(path[0]), 3000))) {
    const tab = byText(path[0]);
    if (!tab) return { ok: false, error: 'menu_not_found', detail: path[0] };
    fire(tab);
    // 그 업무의 메뉴가 왼쪽에 나온다. 첫 단계 이름이 또 있으면 그것부터, 없으면 둘째 단계부터
    const r = await waitFor(() => (menuItem(path[0]) ? 'first' : menuItem(path[1]) ? 'second' : null), 5000);
    if (!r) return { ok: false, error: 'menu_not_found', detail: path[1] };
    if (r === 'second') i = 1;
  }
  for (; i < path.length; i++) {
    const item = await waitFor(() => menuItem(path[i]), 4000);
    if (!item) return { ok: false, error: 'menu_not_found', detail: path[i] };
    // 중간 단계는 접혀 있을 때만 누른다(펼쳐진 것을 누르면 접힘). 마지막 단계는 화면 열기
    if (i === path.length - 1 || item.classList.contains(C.collapsedClass)) fire(item);
    await sleep(300);
  }

  // 새 창(2차 인증)이 뜨거나 과세특 화면이 열릴 때까지. 둘 다 보이면 인증 창이 먼저
  const otp = () => dialogs() > dialogsBefore
    || running().some((a) => !appsBefore.has(a.app.id) && a.app.id !== cfg.app && !/^(app\/com\/main\/Index|udc\/)/.test(a.app.id));
  const seen = await waitFor(() => otp() || isOpen(), 15000);
  if (!seen) return { ok: true, stage: 'clicked' };
  await sleep(800);
  return { ok: true, stage: otp() ? 'otp' : 'open' };
}

// 지금 조회된 명단과 2차 인증 남은 시간
export function readRosterInPage(cfg) {
  const P = window.cpr?.core?.Platform?.INSTANCE;
  if (!P) return { ok: false, error: 'not_exbuilder' };
  const app = P.getAllRunningAppInstances().find((a) => a.app.id === cfg.app);
  if (!app) return { ok: false, error: 'no_remarks_screen' };
  const ds = app.lookup(cfg.grid)?.dataSet;
  if (!ds) return { ok: false, error: 'no_remarks_screen' };

  // 머리글의 "(2차인증:29분 52초)"
  let authSeconds = null;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while (walker.nextNode()) {
    const m = /2차\s*인증\s*:\s*(?:(\d+)\s*분)?\s*(\d+)\s*초/.exec(walker.currentNode.textContent);
    if (m) { authSeconds = Number(m[1] || 0) * 60 + Number(m[2]); break; }
  }

  const c = cfg.cols;
  const RS = window.cpr?.data?.tabledata?.RowState;
  const rows = [];
  for (let i = 0; i < ds.getRowCount(); i++) {
    const v = (k) => ds.getValue(i, k);
    rows.push({
      i,
      cls: Number(v(c.classOnly)),
      no: Number(v(c.numberOnly)),
      classNo: String(v(c.classNo) ?? ''),
      name: String(v(c.name) ?? '').trim(),
      current: String(v(c.general) ?? ''),
      curLen: Number(v(c.generalLen) || 0),
      limit: Number(v(c.remain)),
      enable: String(v(c.enable)) !== 'false',
      changed: RS && ds.getRowState ? ds.getRowState(i) !== RS.UNCHANGED : null,
    });
  }
  return {
    ok: true,
    subject: String(ds.getRowCount() ? ds.getValue(0, c.subject) ?? '' : ''),
    grade: ds.getRowCount() ? Number(ds.getValue(0, c.grade)) : null,
    authSeconds,
    rows,
  };
}

// items: [{ i, classNo, name, text }] — 행 번호뿐 아니라 반/번호·이름이 그대로인지 확인한 뒤에만 넣는다
export function writeRowsInPage(cfg, items) {
  const P = window.cpr?.core?.Platform?.INSTANCE;
  const app = P && P.getAllRunningAppInstances().find((a) => a.app.id === cfg.app);
  const ds = app && app.lookup(cfg.grid)?.dataSet;
  if (!ds) return { ok: false, error: 'no_remarks_screen' };
  const c = cfg.cols;
  const results = [];
  for (const it of items) {
    const same = it.i < ds.getRowCount()
      && String(ds.getValue(it.i, c.classNo)) === it.classNo
      && String(ds.getValue(it.i, c.name) ?? '').trim() === it.name;
    if (!same) { results.push({ i: it.i, ok: false, error: 'row_changed' }); continue; }
    if (String(ds.getValue(it.i, c.enable)) === 'false') { results.push({ i: it.i, ok: false, error: 'disabled' }); continue; }
    ds.setValue(it.i, c.general, it.text); // 데이터셋 update 이벤트 → 화면·바이트 표시는 나이스가 갱신
    const back = String(ds.getValue(it.i, c.general) ?? '');
    results.push({ i: it.i, ok: back === it.text, error: back === it.text ? null : 'verify_failed', len: Number(ds.getValue(it.i, c.generalLen) || 0) });
  }
  return { ok: true, results };
}
