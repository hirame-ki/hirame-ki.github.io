// 과세특: 나이스 명단(조회된 강의실)과 엑셀 학생을 맞춘다.
// 반+번호가 같고 이름까지 같아야 입력한다. 하나라도 다르면 넣지 않고 이유를 보여 준다.
import { neisBytes } from './excel-map.js';

const UNSUPPORTED = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]/u;
const norm = (s) => String(s ?? '').replace(/\s+/g, '');

export const STATUS = {
  ready: { text: '입력 예정', level: 'ok' },
  same: { text: '이미 같은 내용', level: 'ok' },
  has_content: { text: '나이스에 내용 있음', level: 'warn' },
  over: { text: '바이트 초과', level: 'error' },
  char: { text: '나이스가 못 받는 글자', level: 'error' },
  empty: { text: '엑셀 내용 없음', level: 'warn' },
  no_excel: { text: '엑셀에 없음', level: 'warn' },
  name_mismatch: { text: '이름이 다름', level: 'error' },
  number_mismatch: { text: '반·번호가 다름', level: 'error' },
  ambiguous: { text: '엑셀에 여러 명', level: 'error' },
  disabled: { text: '입력할 수 없는 학생', level: 'warn' },
};

// roster: readRosterInPage 결과, records: 엑셀 학생 (buildRecords 결과를 모은 것)
export function matchRoster(roster, records) {
  const used = new Set();
  const subj = norm(roster.subject);
  const sameGrade = (rec) => !rec.grade || !roster.grade || rec.grade === roster.grade;
  const subjectFits = (rec) => !subj || !rec.subject || norm(rec.subject) === subj || subj.includes(norm(rec.subject)) || norm(rec.subject).includes(subj);

  const rows = roster.rows.map((r) => {
    let cands = records.filter((rec) => sameGrade(rec) && rec.class === r.cls && rec.number === r.no);
    if (cands.length > 1) {
      const bySubject = cands.filter(subjectFits);
      if (bySubject.length) cands = bySubject;
    }
    if (cands.length > 1) {
      const byName = cands.filter((rec) => norm(rec.name) === norm(r.name));
      if (byName.length === 1) cands = byName;
    }
    const out = { r, rec: null, status: 'no_excel', bytes: 0, note: '' };

    if (cands.length > 1) {
      out.status = 'ambiguous';
      out.note = cands.map((c) => `${c.sheet || ''} ${c.row}행`.trim()).join(', ');
      return out;
    }
    if (cands.length === 0) {
      // 반·번호는 다르지만 이름이 같은 학생이 엑셀에 한 명 있으면 알려 준다 (전학·번호 변경 등)
      const byName = records.filter((rec) => sameGrade(rec) && subjectFits(rec) && norm(rec.name) === norm(r.name));
      if (byName.length === 1) {
        out.rec = byName[0];
        out.status = 'number_mismatch';
        out.note = `엑셀은 ${byName[0].class}반 ${byName[0].number}번`;
        used.add(byName[0]);
      }
      return out;
    }

    const rec = cands[0];
    used.add(rec);
    out.rec = rec;
    out.bytes = neisBytes(rec.content);
    if (norm(rec.name) !== norm(r.name)) { out.status = 'name_mismatch'; out.note = `엑셀 이름 ${rec.name}`; return out; }
    if (!r.enable) { out.status = 'disabled'; return out; }
    if (!rec.content) { out.status = 'empty'; return out; }
    if (UNSUPPORTED.test(rec.content)) { out.status = 'char'; return out; }
    if (r.current === rec.content) { out.status = 'same'; return out; }
    if (Number.isFinite(r.limit) && out.bytes > r.limit) { out.status = 'over'; out.note = `${out.bytes - r.limit}바이트 넘음`; return out; }
    out.status = r.current.trim() ? 'has_content' : 'ready';
    return out;
  });

  const leftover = records.filter((rec) => !used.has(rec) && rec.name && rec.number);
  return { rows, leftover };
}
