// 바탕화면 바로가기로 여는 실행 화면: run.html?flow=<루틴 id>
// 잠겨 있으면 PIN을 받고, 루틴을 실행하면서 단계별 진행을 보여 준다. 성공하면 이 탭은 스스로 닫힌다.
import { send, errorText, showMsg, busy, flowSteps, $ } from './common.js';

const flowId = new URLSearchParams(location.search).get('flow') || '';
let flow = null;

function setBadge(kind) {
  $('runBadge').className = `badge${kind === 'error' ? ' bad' : ''}`;
}

async function start() {
  const st = await send('getState');
  flow = st.flows.find((f) => f.id === flowId) || null;
  if (!flow) {
    setBadge('error');
    return showMsg($('runMsg'), errorText({ error: 'no_flow' }));
  }
  document.title = `${flow.name} - 쌤패스`;
  $('flowName').textContent = flow.name;
  $('flowSteps').replaceChildren(...flowSteps(flow, st.routes).map((t) => {
    const li = document.createElement('li');
    li.textContent = t;
    return li;
  }));

  if (!st.configured) {
    setBadge('error');
    return showMsg($('runMsg'), errorText({ error: 'not_configured' }));
  }
  if (!st.unlocked) {
    $('unlockForm').classList.remove('hidden');
    if (st.lockedUntil) showMsg($('runMsg'), errorText({ error: 'locked_out', lockedUntil: st.lockedUntil }));
    $('pin').focus();
    return;
  }
  run();
}

async function run() {
  $('retryBtn').classList.add('hidden');
  setBadge('run');
  showMsg($('runMsg'), '시작합니다…', 'pending');
  const res = await send('runFlow', { flowId });
  if (!res.ok) {
    setBadge('error');
    showMsg($('runMsg'), res.text || errorText(res));
    $('retryBtn').classList.remove('hidden');
    return;
  }
  showMsg($('runMsg'), res.text, 'good');
  // 결과는 업무포털·나이스 화면에서 이어 보면 되므로 이 탭은 닫는다
  setTimeout(async () => {
    const me = await chrome.tabs.getCurrent();
    if (me) chrome.tabs.remove(me.id);
  }, 2500);
}

// 실행 중 단계 안내 (백그라운드가 storage.session에 적는다)
chrome.storage.onChanged.addListener((changes, area) => {
  const st = area === 'session' && changes.flowStatus?.newValue;
  if (st && st.id === flowId && st.state === 'run') showMsg($('runMsg'), st.text, 'pending');
});

$('unlockForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const pin = $('pin').value;
  $('pin').value = '';
  showMsg($('runMsg'), '');
  const res = await busy($('unlockBtn'), () => send('unlock', { pin, skipAutoLogin: true }));
  if (!res.ok) return showMsg($('runMsg'), errorText(res));
  $('unlockForm').classList.add('hidden');
  run();
});

$('retryBtn').addEventListener('click', run);
for (const b of document.querySelectorAll('[data-open-options]')) {
  b.addEventListener('click', () => chrome.runtime.openOptionsPage());
}

start();
