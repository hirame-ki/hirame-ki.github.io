// 엑셀 양식 알아보기: 시트마다 어느 열이 학년·반·번호·이름·내용인지 추정해 학생 목록을 만든다.
// 1) 머리글 글자로 찾고 2) 머리글이 없거나 모르는 글자면 값의 모양으로 추정한다.
// 학년·반·과목이 열에 없으면 시트 위쪽 제목 줄("1학년 3반 국어 …")과 시트 이름("3-2", "1반", "국어")에서 읽는다.
// 사람이 확인 화면에서 열 역할을 고치면 buildRecords를 다시 부른다. 외부로 아무것도 보내지 않는다.

export const ROLES = {
  ignore: '사용 안 함',
  grade: '학년',
  class: '반',
  number: '번호',
  studentId: '학번 (10305)',
  combo: '반/번호 (2/17, 1-3-05)',
  name: '이름',
  content: '내용',
  room: '강의실',
  subject: '과목',
};

// 나이스 바이트 계산: 한글 등 3, 영문·숫자·공백 1, 줄바꿈 2
export function neisBytes(s) {
  let n = 0;
  for (const ch of s) n += ch === '\n' ? 2 : ch.codePointAt(0) < 128 ? 1 : 3;
  return n;
}
export const NEIS_MAX_BYTES = 1500;
const UNSUPPORTED = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]/u; // 이모지 등 나이스가 못 받는 글자

// ── 머리글 ──

const HEADER_RULES = [
  ['ignore', /(비고|확인|바이트|byte|글자수|자수|성별|초안|메모|점수|등급|생년월일)/i],
  ['studentId', /^학번$/],
  ['combo', /^(반\/번호|반번호|학년반번호|학년-반-번호|구분)$/],
  ['grade', /^학년$/],
  ['class', /^(반|학급)$/],
  ['number', /^(번호|번|출석번호|출번)$/],
  ['name', /^(이름|성명|학생명|학생이름|성함)$/],
  ['room', /^(강의실|이동반|분반)$/],
  ['subject', /^(과목|과목명|교과목)$/],
  ['content', /(내용|세특|특기사항|세부능력|^\d학기$)/],
];

function headerRole(text) {
  const t = String(text || '').replace(/[\s*]/g, '');
  if (!t || t.length > 20) return null;
  for (const [role, re] of HEADER_RULES) if (re.test(t)) return role;
  return null;
}

// ── 값 모양 ──

const RE = {
  studentId: /^[1-6]\d{4}$/,
  combo: /^\d{1,2}\s*[-/]\s*\d{1,2}(\s*[-/]\s*\d{1,2})?$/,
  name: /^[가-힣]{2,5}$/,
  int: /^\d{1,2}$/,
};

function share(values, re) {
  const v = values.filter((x) => x !== '');
  return v.length ? v.filter((x) => re.test(x)).length / v.length : 0;
}

function guessByValues(values) {
  const v = values.map((x) => x.trim()).filter(Boolean);
  if (!v.length) return null;
  if (share(v, RE.studentId) >= 0.8) return 'studentId';
  if (share(v, RE.combo) >= 0.8) return 'combo';
  if (share(v, RE.name) >= 0.8) return 'name';
  const avg = v.reduce((a, x) => a + x.length, 0) / v.length;
  if (avg >= 25) return 'content';
  if (share(v, RE.int) >= 0.9) return 'int';
  if (share(v, /^\d[A-Z]$/i) >= 0.8) return 'room';
  return null;
}

// ── 제목 줄·시트 이름에서 학년·반·과목·강의실 ──

const GENERIC = /(과목별\s*세부\s*능력\s*및\s*특기\s*사항|세부\s*능력\s*및\s*특기\s*사항|과목별|과세특|세특|특기사항|세부능력)/g;

export function parseTitle(text) {
  const out = {};
  let t = String(text || '');
  const room = /\(\s*(\d[A-Z])\s*\)/i.exec(t);
  if (room) out.room = room[1].toUpperCase();
  t = t.replace(/\([^)]*\)/g, ' ').replace(/\d+\s*~\s*\d+\s*반/g, ' ');
  const g = /(\d)\s*학년(?!도)/.exec(t);
  if (g) out.grade = Number(g[1]);
  const c = /(\d{1,2})\s*반/.exec(t);
  if (c) out.class = Number(c[1]);
  const subject = t.replace(/\d{4}\s*학년도/g, ' ').replace(/\d\s*학년/g, ' ').replace(/\d\s*학기/g, ' ')
    .replace(/\d{1,2}\s*반/g, ' ').replace(GENERIC, ' ').replace(/\s+/g, ' ').trim();
  if (subject && subject.length <= 20) out.subject = subject;
  return out;
}

export function parseSheetName(name, isCsv) {
  if (isCsv) return {};
  const n = String(name || '').trim();
  let m = /^(\d)\s*-\s*(\d{1,2})(?:\s+(.+))?$/.exec(n);
  if (m) return { grade: Number(m[1]), class: Number(m[2]), ...(m[3] ? { subject: m[3].trim() } : {}) };
  m = /^(\d{1,2})\s*반$/.exec(n);
  if (m) return { class: Number(m[1]) };
  if (/^\d[A-Z]$/i.test(n)) return { room: n.toUpperCase() };
  if (/^(sheet|시트)\s*\d*$/i.test(n)) return {};
  return { subject: n };
}

// ── 시트 분석 ──

function fillMerges(rows, merges) {
  const out = rows.map((r) => r.slice());
  for (const m of merges) {
    const v = out[m.r1]?.[m.c1] ?? '';
    for (let r = m.r1; r <= m.r2; r++) for (let c = m.c1; c <= m.c2; c++) if (out[r]) out[r][c] = v;
  }
  return out;
}

function findHeaderRow(rows, hidden) {
  let best = -1, bestScore = 1;
  for (let r = 0; r < Math.min(15, rows.length); r++) {
    const roles = new Set();
    rows[r].forEach((cell, c) => {
      const role = !hidden.has(c) && headerRole(cell);
      if (role && role !== 'ignore') roles.add(role);
    });
    if (roles.size > bestScore) { best = r; bestScore = roles.size; }
  }
  return best;
}

// 시트를 분석해 열 역할과 문맥(학년·반·과목)을 추정한다
export function analyzeSheet(sheet) {
  const rows = fillMerges(sheet.rows, sheet.merges || []);
  const hidden = sheet.hiddenCols || new Set();
  const width = Math.max(0, ...rows.map((r) => r.length));
  const headerRow = findHeaderRow(rows, hidden);

  // 머리글이 없으면 첫 '자료 같은' 행부터 (제목 줄은 건너뜀)
  let dataStart = headerRow + 1;
  if (headerRow < 0) {
    dataStart = rows.findIndex((r) => r.filter((x) => String(x).trim()).length >= 2);
    if (dataStart < 0) dataStart = rows.length;
  }
  const data = rows.slice(dataStart);

  const columns = [];
  for (let c = 0; c < width; c++) {
    const header = headerRow >= 0 ? String(rows[headerRow][c] || '').trim() : '';
    const values = data.map((r) => String(r[c] ?? ''));
    let role = hidden.has(c) ? 'ignore' : headerRole(header);
    const byValue = guessByValues(values);
    // 머리글이 '구분'처럼 애매하면 값으로 확인
    if ((role === 'combo' || role === 'studentId') && byValue !== role) role = null;
    if (!role && !hidden.has(c)) role = byValue === 'int' ? 'int' : byValue;
    columns.push({ index: c, header, role: role || 'ignore', hidden: hidden.has(c), sample: values.find((v) => v.trim()) || '' });
  }

  // 숫자 열(int)을 학년·반·번호로 나눈다
  const ints = columns.filter((col) => col.role === 'int');
  const has = (role) => columns.some((col) => col.role === role);
  const valuesOf = (col) => data.map((r) => String(r[col.index] ?? '').trim()).filter(Boolean).map(Number);
  for (const col of ints) col.role = 'ignore';
  if (ints.length) {
    const scored = ints.map((col) => ({ col, v: valuesOf(col) }));
    // 번호: 서로 다른 값이 가장 많은 열
    if (!has('number') && !has('studentId') && !has('combo')) {
      scored.sort((a, b) => new Set(b.v).size - new Set(a.v).size);
      const top = scored.shift();
      if (top) top.col.role = 'number';
    }
    for (const { col, v } of scored) {
      const max = Math.max(...v);
      if (!has('grade') && max <= 3) col.role = 'grade';
      else if (!has('class') && max <= 20) col.role = 'class';
    }
  }

  // 제목 줄(머리글 위, 또는 자료 위의 행들)과 시트 이름에서 문맥
  const titleText = rows.slice(0, headerRow >= 0 ? headerRow : dataStart).map((r) => [...new Set(r.filter(Boolean))].join(' ')).join(' ');
  const context = { ...parseSheetName(sheet.name, sheet.csv), ...stripEmpty(parseTitle(titleText)) };
  // 시트 이름의 과목보다 제목의 과목을, 둘 다 없으면 시트 이름
  const fromName = parseSheetName(sheet.name, sheet.csv);
  if (!parseTitle(titleText).subject && fromName.subject) context.subject = fromName.subject;

  const roles = Object.fromEntries(columns.map((col) => [col.index, col.role]));
  return { name: sheet.name, headerRow, dataStart, rows, columns, roles, context, titleText };
}

function stripEmpty(o) {
  return Object.fromEntries(Object.entries(o).filter(([, v]) => v !== undefined && v !== ''));
}

// 열 역할(roles)로 학생 목록을 만든다. 사람이 역할을 고친 뒤에도 이것만 다시 부르면 된다.
export function buildRecords(analysis, roles = analysis.roles) {
  const { rows, dataStart, context } = analysis;
  const cols = (role) => Object.entries(roles).filter(([, r]) => r === role).map(([c]) => Number(c));
  const one = (row, role) => { const c = cols(role)[0]; return c === undefined ? '' : String(row[c] ?? '').trim(); };
  const contentCols = cols('content');

  const records = [];
  let carry = {}; // 빈 칸이면 위 학생 값을 이어 씀 (학년·반·강의실·과목)
  for (let r = dataStart; r < rows.length; r++) {
    const row = rows[r];
    const name = one(row, 'name');
    const id = one(row, 'studentId'), combo = one(row, 'combo');
    const numberText = one(row, 'number');
    const content = contentCols.map((c) => String(row[c] ?? '').trim()).filter(Boolean).join(' ');

    const rec = {
      grade: one(row, 'grade') || carry.grade || context.grade || '',
      class: one(row, 'class') || carry.class || context.class || '',
      number: numberText,
      name,
      content,
      room: one(row, 'room') || carry.room || context.room || '',
      subject: one(row, 'subject') || carry.subject || context.subject || '',
      row: r + 1,
    };
    if (RE.studentId.test(id)) {
      rec.grade = id[0]; rec.class = id.slice(1, 3); rec.number = id.slice(3);
    } else if (RE.combo.test(combo)) {
      const parts = combo.split(/\s*[-/]\s*/);
      if (parts.length === 3) [rec.grade, rec.class, rec.number] = parts;
      else [rec.class, rec.number] = parts;
    }

    const hasIdentity = rec.name || rec.number;
    if (!hasIdentity) {
      // 번호·이름이 빈 행에 내용만 있으면 위 학생 내용이 이어지는 것
      if (content && records.length) records[records.length - 1].content += ' ' + content;
      continue;
    }
    carry = { grade: rec.grade, class: rec.class, room: rec.room, subject: rec.subject };
    for (const k of ['grade', 'class', 'number']) rec[k] = rec[k] === '' ? '' : Number(rec[k]);
    records.push(rec);
  }
  for (const rec of records) rec.issues = checkRecord(rec);
  return records;
}

export function checkRecord(rec) {
  const issues = [];
  if (!rec.name) issues.push({ level: 'error', code: 'no_name', text: '이름 없음' });
  if (!rec.class || !rec.number) issues.push({ level: 'error', code: 'no_number', text: '반·번호 없음' });
  if (!rec.content) issues.push({ level: 'warn', code: 'empty', text: '내용 없음' });
  const bytes = neisBytes(rec.content);
  if (bytes > NEIS_MAX_BYTES) issues.push({ level: 'error', code: 'over', text: `${bytes}바이트 (1500 초과)` });
  if (UNSUPPORTED.test(rec.content)) issues.push({ level: 'error', code: 'char', text: '나이스가 받지 못하는 글자(이모지 등)' });
  return issues;
}

export function analyzeWorkbook(wb) {
  return wb.sheets.map((sheet) => {
    const a = analyzeSheet(sheet);
    return { ...a, records: buildRecords(a) };
  }).filter((a) => a.records.length);
}
