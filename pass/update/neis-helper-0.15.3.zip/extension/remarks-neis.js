// 과세특 — 나이스 페이지 안(MAIN world)에서 실행되는 함수들. executeScript의 func로 넘기므로 바깥 변수를 쓰면 안 된다(인자만).
// cfg = NEIS_SUBJECT_REMARKS (sites.js)
//
// 확인된 것 (10-15, [진단 정보 복사])
//   dsGridMain 한 행 = 학생 한 명. clsNm=반, stdntCn=번호, classNo="반/번호", stuFlnm=이름
//   genDetaAbtSpablMteCn = 일반 세특, genDetaAbtSpablMteCnLength = 그 바이트
//   othSemInputLen01 = 일반 칸의 남은(입력 가능) 바이트 — 화면 "0 / 177 Byte"의 177
//   enableYn = 입력 가능 여부
// 값 넣기는 화면 안에서만 일어나고(서버 통신 없음), [저장]을 눌러야 나이스에 기록된다.

// 나이스 메뉴로 과세특 화면을 연다 (cfg.menu.path = 교과담임 › 성적처리 › 과목별세부능력및특기사항).
// 메뉴가 상단 메뉴(10-16 사용자 확인)든 왼쪽 메뉴든 상관없이 "화면에 보이는 글자"로 찾는다:
//   매번 경로에서 가장 깊이 보이는 단계를 찾아 마우스를 올리고 누른다 → 다음 단계가 보이기를 기다린다 → 마지막 단계를 누르면 끝.
//   (펼친 메뉴에 마지막 단계가 이미 보이면 바로 누른다)
// 메뉴를 누르면 나이스가 2차 인증(OTP)을 묻는다. OTP는 사용자가 직접 넣는다 — 그 창이 뜨는 것까지만 보고 아무것도 입력하지 않는다.
// stage: 'open'(과세특 화면이 열려 있음) | 'otp'(새 창이 뜸 = 2차 인증) | 'clicked'(메뉴는 눌렀지만 결과를 확인 못 함)
// C = NEIS_COMMON
export async function openRemarksMenuInPage(C, cfg) {
  const P = window.cpr?.core?.Platform?.INSTANCE;
  if (!P) return { ok: false, error: 'not_exbuilder' };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const vis = (e) => !!e && !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
  const running = () => P.getAllRunningAppInstances();
  const waitFor = async (fn, ms) => {
    const end = Date.now() + ms;
    for (;;) {
      let v = null;
      try { v = fn(); } catch { /* 화면이 아직 준비 안 됨 */ }
      if (v != null && v !== false) return v;
      if (Date.now() > end) return null;
      await sleep(150);
    }
  };
  // 마우스를 올렸다가 누른 것처럼 (상단 메뉴는 올리기만 해도 펼쳐지는 경우가 있다)
  const fire = (el) => {
    for (let e = el, k = 0; e && k < 4; e = e.parentElement, k++) {
      e.dispatchEvent(new MouseEvent('mouseenter', { bubbles: false, view: window }));
    }
    for (const t of ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
      el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
    }
  };
  const isOpen = () => running().some((a) => a.app.id === cfg.app);
  if (isOpen()) return { ok: true, stage: 'open' };

  // 글자 비교: 화면낭독용 " N단계 메뉴항목", 띄어쓰기, '및'·'·'은 빼고 ("과목별세부능력특기사항"도 같은 메뉴)
  const suffix = new RegExp(C.menuLabelSuffix);
  const norm = (s) => s.replace(suffix, '').replace(/[\s·및]/g, '');
  const SEL = `${C.menuItem}, a, button, [role=menuitem], [role=tab], [role=treeitem], li, span, div, p, td`;
  // 그 글자를 가진 가장 안쪽의 보이는 요소. 왼쪽 메뉴 항목이면 그 항목 자체
  const find = (label) => {
    const want = norm(label);
    const hits = [...document.querySelectorAll(SEL)].filter((e) => vis(e) && norm(e.textContent) === want);
    const inner = hits.filter((e) => !hits.some((o) => o !== e && e.contains(o)));
    const el = inner[0];
    return el ? (el.closest(C.menuItem) || el) : null;
  };
  const dialogs = () => [...document.querySelectorAll('.cl-dialog')].filter(vis).length;
  const appsBefore = new Set(running().map((a) => a.app.id));
  const dialogsBefore = dialogs();

  const path = cfg.menu.path;
  const last = path.length - 1;
  // 경로에서 지금 보이는 가장 깊은 단계 (-1 = 하나도 안 보임)
  const deepest = () => { for (let j = last; j >= 0; j--) if (find(path[j])) return j; return -1; };
  let level = await waitFor(() => (deepest() >= 0 ? deepest() : null), 4000);
  if (level == null) return { ok: false, error: 'menu_not_found', detail: path[0] };
  for (let round = 0; ; round++) {
    const el = find(path[level]);
    if (!el) return { ok: false, error: 'menu_not_found', detail: path[level] };
    if (level === last) { fire(el); break; }
    // 왼쪽 메뉴에서 이미 펼쳐진 단계는 누르면 접힌다 → 마우스만 올린다
    if (el.matches(C.menuItem) && !el.classList.contains(C.collapsedClass)) {
      el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, view: window }));
    } else fire(el);
    const next = await waitFor(() => { const d = deepest(); return d > level ? d : null; }, 4000);
    if (next == null || round > path.length + 1) return { ok: false, error: 'menu_not_found', detail: path[level + 1] };
    level = next;
    await sleep(200);
  }

  // 새 창(2차 인증)이 뜨거나 과세특 화면이 열릴 때까지. 둘 다 보이면 인증 창이 먼저
  const otp = () => dialogs() > dialogsBefore
    || running().some((a) => !appsBefore.has(a.app.id) && a.app.id !== cfg.app && !/^(app\/com\/main\/Index|udc\/)/.test(a.app.id));
  const seen = await waitFor(() => otp() || isOpen(), 15000);
  if (!seen) return { ok: true, stage: 'clicked' };
  await sleep(800);
  return { ok: true, stage: otp() ? 'otp' : 'open' };
}

// 지금 조회된 명단과 2차 인증 남은 시간
export function readRosterInPage(cfg) {
  const P = window.cpr?.core?.Platform?.INSTANCE;
  if (!P) return { ok: false, error: 'not_exbuilder' };
  const app = P.getAllRunningAppInstances().find((a) => a.app.id === cfg.app);
  if (!app) return { ok: false, error: 'no_remarks_screen' };
  const ds = app.lookup(cfg.grid)?.dataSet;
  if (!ds) return { ok: false, error: 'no_remarks_screen' };

  // 머리글의 "(2차인증:29분 52초)"
  let authSeconds = null;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while (walker.nextNode()) {
    const m = /2차\s*인증\s*:\s*(?:(\d+)\s*분)?\s*(\d+)\s*초/.exec(walker.currentNode.textContent);
    if (m) { authSeconds = Number(m[1] || 0) * 60 + Number(m[2]); break; }
  }

  const c = cfg.cols;
  const RS = window.cpr?.data?.tabledata?.RowState;
  const rows = [];
  for (let i = 0; i < ds.getRowCount(); i++) {
    const v = (k) => ds.getValue(i, k);
    rows.push({
      i,
      cls: Number(v(c.classOnly)),
      no: Number(v(c.numberOnly)),
      classNo: String(v(c.classNo) ?? ''),
      name: String(v(c.name) ?? '').trim(),
      current: String(v(c.general) ?? ''),
      curLen: Number(v(c.generalLen) || 0),
      limit: Number(v(c.remain)),
      enable: String(v(c.enable)) !== 'false',
      changed: RS && ds.getRowState ? ds.getRowState(i) !== RS.UNCHANGED : null,
    });
  }
  return {
    ok: true,
    subject: String(ds.getRowCount() ? ds.getValue(0, c.subject) ?? '' : ''),
    grade: ds.getRowCount() ? Number(ds.getValue(0, c.grade)) : null,
    authSeconds,
    rows,
  };
}

// items: [{ i, classNo, name, text }] — 행 번호뿐 아니라 반/번호·이름이 그대로인지 확인한 뒤에만 넣는다
export function writeRowsInPage(cfg, items) {
  const P = window.cpr?.core?.Platform?.INSTANCE;
  const app = P && P.getAllRunningAppInstances().find((a) => a.app.id === cfg.app);
  const ds = app && app.lookup(cfg.grid)?.dataSet;
  if (!ds) return { ok: false, error: 'no_remarks_screen' };
  const c = cfg.cols;
  const results = [];
  for (const it of items) {
    const same = it.i < ds.getRowCount()
      && String(ds.getValue(it.i, c.classNo)) === it.classNo
      && String(ds.getValue(it.i, c.name) ?? '').trim() === it.name;
    if (!same) { results.push({ i: it.i, ok: false, error: 'row_changed' }); continue; }
    if (String(ds.getValue(it.i, c.enable)) === 'false') { results.push({ i: it.i, ok: false, error: 'disabled' }); continue; }
    ds.setValue(it.i, c.general, it.text); // 데이터셋 update 이벤트 → 화면·바이트 표시는 나이스가 갱신
    const back = String(ds.getValue(it.i, c.general) ?? '');
    results.push({ i: it.i, ok: back === it.text, error: back === it.text ? null : 'verify_failed', len: Number(ds.getValue(it.i, c.generalLen) || 0) });
  }
  return { ok: true, results };
}
