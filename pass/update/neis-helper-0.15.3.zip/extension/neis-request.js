// 복무 신청(시간외근무 · 조퇴 등 근무상황) — 나이스 페이지 안(MAIN world)에서 실행된다.
// chrome.scripting.executeScript({ func })로 넘기므로 이 함수는 바깥 변수를 쓰면 안 된다(인자만 사용).
// 비밀번호는 다루지 않는다. 화면 구조는 sites.js 참고.
//
// 흐름: (메뉴) 목록 화면 → [신청] → 값 입력·검증 → [승인요청] → [개인결재선] → 결재선 선택 → [지정]
//       → 기본: 여기서 멈추고 사용자가 내용 확인 후 직접 [상신]
//       → 사용자가 설정에서 동의하고 켠 경우에만 [상신]까지 누른다
// 무언가 예상과 다르면 그 자리에서 멈추고, 열린 창은 그대로 둔다(사용자가 이어서 하거나 취소).
//
// C = NEIS_COMMON, D = NEIS_DRAFT, S = NEIS_OVERTIME | NEIS_LEAVE, job.kind = 'overtime' | 'leave'

export async function requestInPage(C, D, S, job) {
  const P = window.cpr?.core?.Platform?.INSTANCE;
  let step = '준비';
  const fail = (error, detail = '') => ({ ok: false, step, error, detail: String(detail) });
  if (!P) return fail('not_exbuilder');

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const vis = (e) => !!e && !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
  const running = () => P.getAllRunningAppInstances();
  const app = (id) => running().find((a) => a.app.id === id) || null;
  const waitFor = async (fn, ms = 10000) => {
    const end = Date.now() + ms;
    for (;;) {
      let v = null;
      try { v = fn(); } catch { /* 화면이 아직 준비 안 됨 */ }
      if (v) return v;
      if (Date.now() > end) return null;
      await sleep(150);
    }
  };
  const fire = (el) => {
    for (const t of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
      el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
    }
  };
  // 검증 오류 등으로 뜬 맨 위 메시지 창의 글자
  const dialogText = () => {
    const ds = [...document.querySelectorAll('.cl-dialog')].filter(vis);
    return ds.length ? ds[ds.length - 1].innerText.trim().replace(/\s+/g, ' ').slice(0, 200) : '';
  };
  const suffix = new RegExp(C.menuLabelSuffix);
  const menuItem = (t) => [...document.querySelectorAll(C.menuItem)]
    .find((a) => a.textContent.replace(suffix, '').trim() === t && vis(a));
  const setCheck = (c, on) => { if ('checked' in c) c.checked = on; else c.value = on ? 'Y' : 'N'; };
  // 사용자가 입력한 것처럼 값 바꾸기 (이벤트 발생). 지원하지 않으면 값만 대입
  const put = (c, v) => { if (typeof c.putValue === 'function') c.putValue(v); else c.value = v; };

  // 사용자가 작성 중인 창이 있으면 건드리지 않는다
  if (app(S.formApp) || app(D.app) || app(D.lineApp)) return fail('busy');

  // 1. 메뉴 → 목록 화면
  step = '메뉴 열기';
  let list = app(S.listApp);
  if (!list) {
    const [top, leaf] = S.menu.path;
    const t = await waitFor(() => menuItem(top), 5000);
    if (!t) return fail('menu_not_found', top);
    if (t.classList.contains(C.collapsedClass)) fire(t);
    const l = await waitFor(() => menuItem(leaf), 3000);
    if (!l) return fail('menu_not_found', leaf);
    fire(l);
    list = await waitFor(() => app(S.listApp));
    if (!list) return fail('timeout');
    await sleep(1500); // 목록 첫 조회가 끝날 시간
  }

  // 2. [신청] → 신청 창 (오늘 날짜 행 1개가 기본으로 생김)
  step = '신청 창 열기';
  list.lookup(S.list.apply).click();
  const form = await waitFor(() => app(S.formApp));
  if (!form) return fail('timeout', dialogText());
  const F = (k) => form.lookup(S.form[k]);
  const rows = () => F('grid').dataSet.getRowCount();
  if (!(await waitFor(() => rows() > 0, 5000))) return fail('timeout');
  await sleep(500);
  if (rows() !== 1) return fail('unexpected_rows', rows());

  // 3. 값 입력 + 되읽기 검증
  step = '값 입력';
  const [sh, sm] = job.start.split(':');
  const [eh, em] = job.end.split(':');
  let got;

  if (job.kind === 'overtime') {
    // 날짜를 먼저 바꾸면 나이스가 기본 시각을 다시 채울 수 있어 날짜 → 나머지 순서
    if (F('date').value !== job.date) { put(F('date'), job.date); await sleep(800); }
    F('type').value = job.type;
    setCheck(F('holiday'), job.holiday);
    await sleep(300);
    F('startH').value = sh; F('startM').value = sm;
    F('endH').value = eh; F('endM').value = em;
    F('reason').value = job.reason;
    await sleep(500);
    got = {
      date: F('date').value,
      start: `${F('startH').value}:${F('startM').value}`,
      end: `${F('endH').value}:${F('endM').value}`,
      sum: `${F('sumH').value}:${F('sumM').value}`,
      reason: F('reason').value,
    };
    if (got.date !== job.date || got.start !== job.start || got.end !== job.end || got.reason !== job.reason) {
      return fail('verify_failed', `${got.date} ${got.start}~${got.end}`);
    }
  } else {
    // 근무상황: 콤보는 selectItemByValue(값, true)로 바꿔야 시간 계산 등 화면 로직이 돈다
    const sel = async (k, v) => {
      const c = F(k);
      if (!c.getItemByValue(v)) throw new Error(`no_item:${k}=${v}`);
      c.selectItemByValue(v, true);
      await sleep(400);
    };
    try {
      await sel('lclf', job.lclf);
      await sel('sclf', job.sclf);
      if (job.lclf === 'W01' && F('avKind').visible !== false) await sel('avKind', job.avKind);
      if (F('dateFrom').value !== job.date) { put(F('dateFrom'), job.date); await sleep(600); }
      if (F('dateTo').value !== job.date) { put(F('dateTo'), job.date); await sleep(600); }
      await sel('startH', sh); await sel('startM', sm);
      await sel('endH', eh); await sel('endM', em);
    } catch (e) {
      return fail('verify_failed', String(e.message || e));
    }
    put(F('reason'), job.reason);
    if (job.contact) put(F('contact'), job.contact);
    setCheck(F('hidePeriod'), job.hidePeriod);
    setCheck(F('hideReason'), job.hideReason);
    await sleep(800);
    const days = Number(F('days').value || 0);
    const mins = Number(F('hours').value || 0) * 60 + Number(F('minutes').value || 0);
    got = {
      date: F('dateFrom').value,
      start: `${F('startH').value}:${F('startM').value}`,
      end: `${F('endH').value}:${F('endM').value}`,
      sum: `${Math.floor(mins / 60)}:${String(mins % 60).padStart(2, '0')}`,
      reason: F('reason').value,
    };
    const planned = (Number(eh) * 60 + Number(em)) - (Number(sh) * 60 + Number(sm));
    // 조퇴·외출이 '1일' 연가로 잘못 잡히는 사고를 막는다: 일수 0, 시간은 0보다 크고 계획한 시간 이하
    if (got.date !== job.date || F('dateTo').value !== job.date || got.start !== job.start || got.end !== job.end
        || F('sclf').value !== job.sclf || got.reason !== job.reason || days !== 0 || mins <= 0 || mins > planned) {
      return fail('verify_failed', `${got.date} ${got.start}~${got.end} · ${days}일 ${got.sum}`);
    }
  }

  // 4. [승인요청] → 임시저장 + 기안문서상신 창
  step = '승인요청';
  const before = new Set(running().map((a) => a.app.id));
  F('submit').click();
  const draft = await waitFor(() => app(D.app), 15000);
  if (!draft) {
    // 다른 창이 떴다면 그 화면 id를 남긴다 (구조가 다를 때 진단용)
    const fresh = running().map((a) => a.app.id).filter((id) => !before.has(id) && !id.startsWith('udc/'));
    return fail('no_draft', [dialogText(), fresh.join(', ')].filter(Boolean).join(' / '));
  }
  const approvers = () => draft.lookup(D.approvers).dataSet.getRowCount();
  await waitFor(() => approvers() > 0, 5000);
  await sleep(500);

  // 5. [개인결재선] → 설정에 적은 이름의 결재선 선택 → [지정]
  step = '결재선 불러오기';
  draft.lookup(D.myLine).click();
  const lp = await waitFor(() => app(D.lineApp));
  if (!lp) return fail('timeout', dialogText());
  const lines = lp.lookup(D.lineList);
  await waitFor(() => lines.dataSet.getRowCount() > 0, 5000);
  const names = [];
  for (let i = 0; i < lines.dataSet.getRowCount(); i++) names.push(String(lines.dataSet.getValue(i, D.lineNameCol) || '').trim());
  // 이름을 비워두면 결재선이 하나뿐일 때만 그걸 쓴다
  const idx = job.lineName ? names.indexOf(job.lineName.trim()) : (names.length === 1 ? 0 : -1);
  if (idx < 0) return fail(names.length ? 'line_not_found' : 'no_lines', names.join(', '));

  const members = lp.lookup(D.lineMembers);
  const gridEl = document.getElementById(C.domIdPrefix + lines.uuid);
  const cell = gridEl && [...gridEl.querySelectorAll('.cl-grid-cell')].find((c) => c.innerText.trim() === names[idx] && vis(c));
  if (cell) fire(cell); else lines.selectRows([idx]);
  if (!(await waitFor(() => members.dataSet.getRowCount() > 0, 5000))) {
    lines.selectRows([idx]);
    if (!(await waitFor(() => members.dataSet.getRowCount() > 0, 5000))) return fail('line_empty', names[idx]);
  }
  lp.lookup(D.lineApply).click();
  if (!(await waitFor(() => !app(D.lineApp), 5000))) return fail('timeout', dialogText());
  await sleep(500);
  if (approvers() < 2) return fail('line_not_applied');
  const info = { ...got, line: names[idx], approvers: approvers() - 1 };

  // 6. 기본은 여기서 멈춤 — 사용자가 확인 후 직접 [상신]
  if (!job.autoSubmit) return { ok: true, stage: 'ready', info };
  step = '상신';
  draft.lookup(D.submit).click();
  const closed = await waitFor(() => !app(D.app), 10000);
  return { ok: true, stage: closed ? 'submitted' : 'submit_clicked', info, detail: closed ? '' : dialogText() };
}

// 결과 안내를 나이스 화면 오른쪽 위에 잠깐 띄운다
export function toastInPage(text, isError) {
  const id = 'neis-helper-toast';
  document.getElementById(id)?.remove();
  const box = document.createElement('div');
  box.id = id;
  box.textContent = text;
  Object.assign(box.style, {
    position: 'fixed', top: '16px', right: '16px', zIndex: '2147483647', maxWidth: '420px',
    padding: '12px 16px', borderRadius: '10px', font: '14px/1.5 "Malgun Gothic", sans-serif',
    whiteSpace: 'pre-wrap', color: '#fff', background: isError ? '#c0392b' : '#1f7a4d',
    boxShadow: '0 6px 20px rgba(0,0,0,.25)', cursor: 'pointer',
  });
  box.addEventListener('click', () => box.remove());
  document.body.appendChild(box);
  setTimeout(() => box.remove(), isError ? 20000 : 10000);
}
