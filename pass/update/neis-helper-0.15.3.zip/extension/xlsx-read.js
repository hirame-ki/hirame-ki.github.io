// 엑셀(.xlsx)·CSV 읽기 — 외부 라이브러리 없이 브라우저(와 Node 18+)에 들어 있는 기능만 쓴다.
// .xlsx는 zip 안의 XML이다. zip은 직접 풀고(DecompressionStream 'deflate-raw'), XML은 필요한 부분만 정규식으로 읽는다.
// 파일은 이 화면(메모리) 안에서만 읽고 어디에도 저장·전송하지 않는다.
//
// 결과: { sheets: [{ name, rows: string[][], merges: [{r1,c1,r2,c2}], hiddenCols: Set<number> }] }
//   rows[r][c] = 셀의 글자 (빈 칸은 ''). 수식 칸은 엑셀이 저장해 둔 계산 결과(없으면 '').

export class XlsxError extends Error {
  constructor(code, detail) { super(detail || code); this.code = code; }
}

export async function readSpreadsheet(name, buffer) {
  const ext = (name.match(/\.([^.]+)$/)?.[1] || '').toLowerCase();
  const bytes = new Uint8Array(buffer);
  if (ext === 'csv' || ext === 'txt') return { sheets: [readCsv(name, bytes)] };
  if (ext === 'xls') throw new XlsxError('xls_unsupported');
  if (bytes[0] !== 0x50 || bytes[1] !== 0x4b) {
    // 암호가 걸린 xlsx는 zip이 아니라 OLE 문서(D0 CF 11 E0)로 저장된다
    if (bytes[0] === 0xd0 && bytes[1] === 0xcf) throw new XlsxError(ext === 'xlsx' ? 'xlsx_encrypted' : 'xls_unsupported');
    throw new XlsxError('not_spreadsheet');
  }
  return readXlsx(bytes);
}

// ── CSV ──

function decodeText(bytes) {
  if (bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) return new TextDecoder('utf-8').decode(bytes.subarray(3));
  // 엑셀 "유니코드 텍스트(*.txt)" = UTF-16, 탭으로 구분
  if (bytes[0] === 0xff && bytes[1] === 0xfe) return new TextDecoder('utf-16le').decode(bytes.subarray(2));
  if (bytes[0] === 0xfe && bytes[1] === 0xff) return new TextDecoder('utf-16be').decode(bytes.subarray(2));
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  } catch {
    return new TextDecoder('euc-kr').decode(bytes); // 엑셀 "CSV(쉼표로 분리)" 기본 저장 = CP949
  }
}

function readCsv(name, bytes) {
  const text = decodeText(bytes);
  const firstLine = text.slice(0, text.indexOf('\n') + 1 || undefined);
  const sep = (firstLine.match(/\t/g) || []).length > (firstLine.match(/,/g) || []).length ? '\t' : ',';
  const rows = [];
  let row = [], cell = '', quoted = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') { cell += '"'; i++; }
      else if (ch === '"') quoted = false;
      else cell += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === sep) { row.push(cell); cell = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++;
      row.push(cell); rows.push(row); row = []; cell = '';
    } else cell += ch;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return { name: name.replace(/\.[^.]+$/, ''), csv: true, rows: rows.map((r) => r.map((c) => c.replace(/\r\n/g, '\n'))), merges: [], hiddenCols: new Set() };
}

// ── zip ──

async function inflateRaw(data) {
  const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

async function unzip(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  // 끝에서 중앙 디렉터리 끝 표시(0x06054b50)를 찾는다
  let eocd = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
    if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new XlsxError('not_spreadsheet');
  const count = dv.getUint16(eocd + 10, true);
  let p = dv.getUint32(eocd + 16, true);
  const files = new Map();
  const utf8 = new TextDecoder('utf-8');
  for (let n = 0; n < count; n++) {
    if (dv.getUint32(p, true) !== 0x02014b50) throw new XlsxError('not_spreadsheet');
    const method = dv.getUint16(p + 10, true);
    const csize = dv.getUint32(p + 20, true);
    const nameLen = dv.getUint16(p + 28, true), extraLen = dv.getUint16(p + 30, true), commentLen = dv.getUint16(p + 32, true);
    const local = dv.getUint32(p + 42, true);
    const fname = utf8.decode(bytes.subarray(p + 46, p + 46 + nameLen));
    files.set(zipKey(fname), { method, csize, local });
    p += 46 + nameLen + extraLen + commentLen;
  }
  const get = async (fname) => {
    const f = files.get(zipKey(fname));
    if (!f) return null;
    const start = f.local + 30 + dv.getUint16(f.local + 26, true) + dv.getUint16(f.local + 28, true);
    const data = bytes.subarray(start, start + f.csize);
    const raw = f.method === 0 ? data : f.method === 8 ? await inflateRaw(data) : null;
    if (!raw) throw new XlsxError('not_spreadsheet', `zip method ${f.method}`);
    // 프로그램에 따라 요소 이름에 접두어를 붙인다(<x:c>). 접두어를 떼어 같은 모양으로 맞춘다.
    return utf8.decode(raw).replace(/<(\/?)[A-Za-z][\w.-]*:(?=[A-Za-z])/g, '<$1');
  };
  get.names = () => [...files.keys()];
  return get;
}

// zip 안 경로: 대소문자·역슬래시·앞의 / 차이를 무시
function zipKey(name) {
  return name.replace(/\\/g, '/').replace(/^\/+/, '').toLowerCase();
}

// rels 파일 기준 상대 경로를 zip 경로로 (../ 처리)
function resolvePath(base, target) {
  if (target.startsWith('/')) return target.slice(1);
  const parts = base.split('/').slice(0, -1);
  for (const seg of target.replace(/\\/g, '/').split('/')) {
    if (seg === '..') parts.pop();
    else if (seg && seg !== '.') parts.push(seg);
  }
  return parts.join('/');
}

// ── XML 조각 읽기 ──

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
function unescapeXml(s) {
  return s.replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos);/gi, (_, e) => {
    if (e[0] === '#') return String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10));
    return ENT[e.toLowerCase()];
  }).replace(/_x([0-9A-F]{4})_/g, (_, h) => String.fromCharCode(parseInt(h, 16))).replace(/\r\n?/g, '\n');
}

function attr(tag, name) {
  const m = new RegExp(`\\s${name}="([^"]*)"`).exec(tag);
  return m ? unescapeXml(m[1]) : null;
}

// <si> 안의 모든 <t> 글자를 잇는다 (서식이 섞인 글자는 <r><t>…</t></r> 여러 개로 나뉨, 윗주 <rPh>는 뺀다)
function textOf(xml) {
  const noPhonetic = xml.replace(/<rPh\b[\s\S]*?<\/rPh>/g, '');
  let out = '';
  for (const m of noPhonetic.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>|<t(?:\s[^>]*)?\/>/g)) out += m[1] ? unescapeXml(m[1]) : '';
  return out;
}

function colIndex(ref) {
  let n = 0;
  for (const ch of ref.replace(/\d+$/, '')) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

function parseRef(ref) {
  const m = /^([A-Z]+)(\d+)$/.exec(ref);
  return m ? { r: Number(m[2]) - 1, c: colIndex(m[1]) } : null;
}

async function readXlsx(bytes) {
  const get = await unzip(bytes);
  // 통합 문서 위치는 _rels/.rels가 알려 준다 (보통 xl/workbook.xml)
  const rootRels = (await get('_rels/.rels')) || '';
  const wbRel = [...rootRels.matchAll(/<Relationship\b[^>]*>/g)].find((m) => /officeDocument$/.test(attr(m[0], 'Type') || ''));
  const wbPath = wbRel ? resolvePath('', attr(wbRel[0], 'Target')) : 'xl/workbook.xml';
  const workbook = (await get(wbPath)) || (await get('xl/workbook.xml'));
  if (!workbook) throw new XlsxError('not_spreadsheet');
  const relsPath = resolvePath(wbPath, `_rels/${wbPath.split('/').pop()}.rels`);
  const rels = (await get(relsPath)) || '';
  const relTarget = new Map(), relType = new Map();
  for (const m of rels.matchAll(/<Relationship\b[^>]*>/g)) {
    relTarget.set(attr(m[0], 'Id'), resolvePath(wbPath, attr(m[0], 'Target') || ''));
    relType.set(attr(m[0], 'Id'), attr(m[0], 'Type') || '');
  }

  // 공유 문자열: rels에서 찾고, 없으면 흔한 이름으로
  const sharedId = [...relType].find(([, t]) => /sharedStrings$/i.test(t))?.[0];
  const sharedXml = (sharedId && await get(relTarget.get(sharedId))) || (await get('xl/sharedStrings.xml')) || '';
  const shared = [...sharedXml.matchAll(/<si(?:\s[^>]*)?>([\s\S]*?)<\/si>/g)].map((m) => textOf(m[1]));

  const sheets = [];
  const skipped = [];
  for (const m of workbook.matchAll(/<sheet\b[^>]*>/g)) {
    const name = attr(m[0], 'name');
    const state = attr(m[0], 'state');
    if (state === 'hidden' || state === 'veryHidden') { skipped.push(`${name}(숨김)`); continue; } // 숨긴 시트는 읽지 않는다
    // 관계 id 속성의 접두어는 프로그램마다 다르다 (r:id, ns1:id …)
    const rid = /\s[\w.-]+:id="([^"]*)"/.exec(m[0])?.[1];
    const xml = rid && await get(relTarget.get(rid) || '');
    if (xml) sheets.push(readSheet(name, xml, shared));
    else skipped.push(`${name}(못 찾음)`);
  }
  return { sheets, parts: get.names(), skipped };
}

function readSheet(name, xml, shared) {
  const rows = [];
  const data = /<sheetData(?:\s[^>]*)?>([\s\S]*?)<\/sheetData>/.exec(xml)?.[1] || '';
  // 보통은 칸마다 주소(r="B3")가 있지만, 주소를 생략하는 프로그램도 있어 행·칸 순서로 이어 센다
  let rowIdx = -1;
  for (const rm of data.matchAll(/<row\b([^>]*?)(?:\/>|>([\s\S]*?)<\/row>)/g)) {
    const rAttr = Number(attr(`<row ${rm[1]}`, 'r'));
    rowIdx = rAttr > 0 ? rAttr - 1 : rowIdx + 1;
    let colIdx = -1;
    for (const cm of (rm[2] || '').matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
      const ref = parseRef(attr(`<c ${cm[1]}`, 'r') || '');
      const pos = ref || { r: rowIdx, c: colIdx + 1 };
      colIdx = pos.c;
      const type = attr(`<c ${cm[1]}`, 't');
      const body = cm[2] || '';
      let v = '';
      if (type === 'inlineStr') v = textOf(body);
      else {
        const vm = /<v>([\s\S]*?)<\/v>/.exec(body);
        if (vm) {
          const raw = unescapeXml(vm[1]);
          if (type === 's') v = shared[Number(raw)] ?? '';
          else if (type === 'b') v = raw === '1' ? 'TRUE' : 'FALSE';
          else if (type === 'str' || type === 'e') v = raw;
          else v = normalizeNumber(raw);
        }
      }
      (rows[pos.r] ||= [])[pos.c] = v;
    }
  }
  const width = Math.max(0, ...rows.filter(Boolean).map((r) => r.length));
  const grid = Array.from({ length: rows.length }, (_, r) => Array.from({ length: width }, (_, c) => rows[r]?.[c] ?? ''));

  const merges = [...xml.matchAll(/<mergeCell\b[^>]*ref="([A-Z]+\d+):([A-Z]+\d+)"/g)].map((m) => {
    const a = parseRef(m[1]), b = parseRef(m[2]);
    return { r1: a.r, c1: a.c, r2: b.r, c2: b.c };
  });
  const hiddenCols = new Set();
  for (const m of xml.matchAll(/<col\b[^>]*>/g)) {
    if (attr(m[0], 'hidden') === '1' || attr(m[0], 'hidden') === 'true') {
      for (let c = Number(attr(m[0], 'min')) - 1; c <= Number(attr(m[0], 'max')) - 1; c++) hiddenCols.add(c);
    }
  }
  return { name, rows: grid, merges, hiddenCols };
}

// 1.0 → "1", 30701 → "30701" (엑셀은 정수도 실수로 저장할 때가 있다)
function normalizeNumber(raw) {
  const n = Number(raw);
  if (!Number.isFinite(n)) return raw;
  if (Number.isInteger(n)) return String(n);
  return String(Math.round(n * 1e9) / 1e9);
}
