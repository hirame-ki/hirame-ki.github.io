// 인증서 비밀번호 금고 (0.15.0부터 확장 안에 둔다. 그 전에는 도우미 프로그램 NeisHelper.exe가 맡았음)
//
// PIN(숫자 6~12자리) → PBKDF2-SHA256 → AES-256-GCM으로 비밀번호를 암호화해 chrome.storage.local에 둔다.
// PIN이 틀리면 GCM 검사에서 걸러진다. 5번 틀리면 5분, 그 뒤로 한 번 틀릴 때마다 10·20·40·60분 잠근다.
// 도우미 시절의 '윈도우 계정 암호화(DPAPI)' 한 겹은 없다: 브라우저 프로필 폴더가 통째로 복사되면
// PIN을 하나씩 대입해 볼 수 있다 (사용자가 알고 6자리로 정함, 10-15).

const KEY = 'vault';
const VERSION = 2;
const ITERATIONS = 600000;
const MAX_FAILS = 5;
const MAX_PASSWORD_CHARS = 256;
const PIN_PATTERN = /^[0-9]{6,12}$/;

const enc = new TextEncoder();
const b64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const fail = (error, extra = {}) => ({ ok: false, error, ...extra });

async function load() {
  const { [KEY]: v } = await chrome.storage.local.get(KEY);
  return v && v.v === VERSION ? v : null;
}

async function deriveKey(pin, salt, iterations) {
  const base = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}

async function seal(password, pin, prev = {}) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(pin, salt, ITERATIONS);
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(password));
  const v = { v: VERSION, salt: b64(salt), iter: ITERATIONS, iv: b64(iv), ct: b64(ct), fails: 0, lockUntil: 0, createdAt: prev.createdAt || Date.now() };
  await chrome.storage.local.set({ [KEY]: v });
}

async function tryOpen(v, pin) {
  try {
    const key = await deriveKey(pin, unb64(v.salt), v.iter);
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(v.iv) }, key, unb64(v.ct));
    return new TextDecoder().decode(pt);
  } catch {
    return null;
  }
}

const activeLock = (v) => (v.lockUntil > Date.now() ? v.lockUntil : 0);

// PIN을 확인하고 틀린 횟수·잠금을 갱신한다. 맞으면 { v, password }, 아니면 { res: 실패 응답 }
async function openWithPin(pin) {
  const v = await load();
  if (!v) return { res: fail('not_configured') };
  const lockedUntil = activeLock(v);
  if (lockedUntil) return { res: fail('locked_out', { lockedUntil }) };
  const password = typeof pin === 'string' && PIN_PATTERN.test(pin) ? await tryOpen(v, pin) : null;
  if (password === null) {
    v.fails += 1;
    if (v.fails >= MAX_FAILS) v.lockUntil = Date.now() + Math.min(5 * 2 ** Math.min(v.fails - MAX_FAILS, 4), 60) * 60000;
    await chrome.storage.local.set({ [KEY]: v });
    return { res: fail('wrong_pin', { remaining: Math.max(0, MAX_FAILS - v.fails), lockedUntil: activeLock(v) }) };
  }
  if (v.fails || v.lockUntil) {
    v.fails = 0;
    v.lockUntil = 0;
    await chrome.storage.local.set({ [KEY]: v });
  }
  return { v, password };
}

function validPassword(p) {
  return typeof p === 'string' && p.length > 0 && p.length <= MAX_PASSWORD_CHARS;
}

export async function status() {
  const v = await load();
  return { ok: true, configured: !!v, fails: v ? v.fails : 0, lockedUntil: v ? activeLock(v) : 0 };
}

export async function setup(password, pin) {
  if (await load()) return fail('already_configured');
  if (!validPassword(password)) return fail('invalid_password');
  if (typeof pin !== 'string' || !PIN_PATTERN.test(pin)) return fail('invalid_pin');
  await seal(password, pin);
  return { ok: true };
}

export async function unlock(pin) {
  const { res, password } = await openWithPin(pin);
  return res || { ok: true, password };
}

export async function changePin(pin, newPin) {
  if (typeof newPin !== 'string' || !PIN_PATTERN.test(newPin)) return fail('invalid_new_pin');
  const { res, v, password } = await openWithPin(pin);
  if (res) return res;
  await seal(password, newPin, v);
  return { ok: true };
}

export async function updatePassword(pin, password) {
  if (!validPassword(password)) return fail('invalid_password');
  const { res, v } = await openWithPin(pin);
  if (res) return res;
  await seal(password, pin, v);
  return { ok: true };
}

export async function reset() {
  await chrome.storage.local.remove(KEY);
  return { ok: true };
}
