import { send, errorText, showMsg, busy, flowSteps, $ } from './common.js';

const LOCK_REASONS = {
  idle: '자리 비움으로 자동 잠금',
  locked: 'PC 화면 잠금으로 자동 잠금',
  max: '최대 유지 시간이 지나 자동 잠금',
  manual: '직접 잠금',
  password_changed: '비밀번호 변경 후 잠금',
};

const PILLS = { locked: ['', '잠김'], unlocked: ['on', '열림'] };

function show(id) {
  for (const s of ['loading', 'notConfigured', 'locked', 'unlocked']) $(s).classList.toggle('hidden', s !== id);
  $('lockBtn').classList.toggle('hidden', id !== 'unlocked');
  const pill = PILLS[id];
  $('headPill').classList.toggle('hidden', !pill);
  if (pill) {
    $('headPill').className = `pill ${pill[0]}`;
    $('headPill').firstElementChild.className = `dot ${pill[0]}`;
    $('headPillText').textContent = pill[1];
  }
}

async function render() {
  const st = await send('getState');
  if (st.error === 'reloading') return; // 새 버전 파일로 다시 시작하는 중 (팝업이 곧 닫힘)
  renderUpdate(st);
  if (!st.configured) {
    $('vaultMoved').classList.toggle('hidden', !st.vaultMoved);
    return show('notConfigured');
  }
  if (!st.unlocked) {
    show('locked');
    const reason = st.lastLock && LOCK_REASONS[st.lastLock.reason];
    $('lastLock').textContent = reason ? `최근: ${reason}` : '';
    if (st.lockedUntil) showMsg($('lockedMsg'), errorText({ error: 'locked_out', lockedUntil: st.lockedUntil }));
    $('pin').focus();
    return;
  }
  show('unlocked');
  const left = Math.max(0, Math.round((st.unlockedAt + st.settings.maxUnlockMinutes * 60000 - Date.now()) / 60000));
  // 루틴이 있으면 맨 위 구역 제목 옆에, 없으면 로그인 제목 옆에 남은 시간을 보인다
  const hasFlows = st.flows.length > 0;
  const timer = hasFlows ? $('timer') : $('timerAlt');
  (hasFlows ? $('timerAlt') : $('timer')).textContent = '';
  if (st.settings.lockMode === 'session') {
    timer.textContent = 'Win+L 하면 잠김';
    timer.title = 'PC 화면을 잠그거나 로그아웃·브라우저를 닫으면 잠깁니다.';
  } else {
    timer.textContent = `${left}분 뒤 자동 잠금`;
    timer.title = `미사용 ${st.settings.idleMinutes}분 또는 ${left}분 뒤 자동으로 잠깁니다.`;
  }
  renderFlows(st);
  renderRoutes(st);
}

// 새 버전 알림, 방금 업데이트했으면 한 번 알려 줌.
// [받기]는 설치 안내 페이지를 연다. 새 설치 파일을 실행하면 쌤패스가 알아서 새 버전으로 다시 시작한다.
function renderUpdate(st) {
  const u = st.update;
  const show = !!(u && u.available);
  $('updateBanner').classList.toggle('hidden', !show);
  if (show) {
    $('updateTitle').textContent = `새 버전 ${u.version}이 나왔어요`;
    $('updateNote').textContent = u.notes || '새 설치 파일을 받아 실행하면 바로 바뀌어요.';
  }
  if (st.justUpdated && Date.now() - st.justUpdated.at < 86400000) {
    showMsg($('unlockedMsg'), `${st.justUpdated.to} 버전으로 업데이트했어요.`, 'good');
    send('clearJustUpdated');
  }
}

$('updateBtn').addEventListener('click', async () => {
  await send('openUpdatePage');
  window.close();
});

function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// 루틴: 로그인부터 이어서 실행. 복무 신청이 들어 있어도 [상신] 앞에서 멈춘다.
function renderFlows(st) {
  $('flowsSect').classList.toggle('hidden', st.flows.length === 0);
  $('flowBtns').replaceChildren(...st.flows.map((f) => {
    const b = document.createElement('button');
    const steps = flowSteps(f, st.routes);
    const sub = document.createElement('small');
    sub.textContent = steps.slice(1).filter((t) => !t.startsWith('[')).join(' → ') || '로그인';
    b.append(f.name, sub);
    b.title = steps.join(' → ');
    b.addEventListener('click', async () => {
      showMsg($('unlockedMsg'), `${f.name}: 시작합니다…`, 'pending');
      const res = await busy(b, () => send('runFlow', { flowId: f.id }));
      // 탭이 바뀌면 팝업이 닫혀 이 아래는 대개 실행되지 않는다 (진행·결과는 업무포털·나이스 화면 안내로)
      showMsg($('unlockedMsg'), res.text || errorText(res), res.ok ? 'good' : 'error');
    });
    return b;
  }));
}

function renderRoutes(st) {
  const has = st.routes.length > 0;
  $('routesEmpty').classList.toggle('hidden', has);
  $('routesBox').classList.toggle('hidden', !has);
  if (!$('runDate').value) $('runDate').value = today();
  renderWhen();
  $('routeBtns').replaceChildren(...st.routes.map((r) => {
    const b = document.createElement('button');
    const sub = document.createElement('small');
    sub.textContent = `${r.kind === 'leave' ? '근무상황' : '시간외'} ${r.start}~${r.end}`;
    b.append(r.name, sub);
    b.title = `${r.kind === 'leave' ? '근무상황' : '시간외근무'} ${r.start}~${r.end} · ${r.reason}${r.lineName ? ` · 결재선 ${r.lineName}` : ''}`;
    b.addEventListener('click', async () => {
      showMsg($('unlockedMsg'), '나이스에서 진행 중… 결과는 나이스 화면 오른쪽 위에 표시됩니다.', 'pending');
      const res = await busy(b, () => send('runRoute', { routeId: r.id, date: $('runDate').value, start: $('runStart').value, end: $('runEnd').value }));
      // 나이스 탭으로 넘어가면 팝업이 닫혀 이 아래는 대개 실행되지 않는다
      showMsg($('unlockedMsg'), res.text || errorText(res), res.ok ? 'good' : 'error');
    });
    return b;
  }));
  $('autoNote').textContent = st.autoSubmit
    ? '자동 상신 켜짐: [상신]까지 누릅니다.'
    : '결재선까지 넣고 멈춥니다. [상신]은 직접 누르세요.';
  $('autoNote').classList.toggle('warn', st.autoSubmit === true);
  $('lastRun').textContent = st.lastRun ? `최근 실행: ${st.lastRun.text}` : '';
}

// 접힌 "날짜·시각 바꾸기" 줄에 지금 고른 값을 요약해 보여 준다
function renderWhen() {
  const d = $('runDate').value;
  let day = '날짜 없음';
  if (d === today()) day = '오늘';
  else if (d) {
    const t = new Date(`${d}T00:00`);
    day = `${t.getMonth() + 1}월 ${t.getDate()}일 (${'일월화수목금토'[t.getDay()]})`;
  }
  const s = $('runStart').value, e = $('runEnd').value;
  const time = s || e ? `${s || '기본'}~${e || '기본'}` : '기본 시각';
  $('whenText').textContent = `${day} · ${time}`;
}
for (const id of ['runDate', 'runStart', 'runEnd']) $(id).addEventListener('input', renderWhen);

// 결과 알림: 내용이 있으면 아래 여백을 늘리고, 누르면 닫는다
const toasts = document.querySelector('.toasts');
new MutationObserver(() => {
  document.body.classList.toggle('has-toast', [...toasts.children].some((m) => m.textContent));
}).observe(toasts, { subtree: true, childList: true, characterData: true });
for (const m of toasts.children) m.addEventListener('click', () => showMsg(m, ''));

$('unlockForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const pin = $('pin').value;
  $('pin').value = '';
  showMsg($('lockedMsg'), '');
  const res = await busy($('unlockBtn'), () => send('unlock', { pin }));
  if (!res.ok) return showMsg($('lockedMsg'), errorText(res));
  showMsg($('lockedMsg'), '');
  render();
});

$('lockBtn').addEventListener('click', async () => {
  await send('lock');
  render();
});

$('loginBtn').addEventListener('click', async () => {
  showMsg($('unlockedMsg'), '인증서 창을 여는 중…', 'pending');
  const res = await busy($('loginBtn'), () => send('portalLogin'));
  showMsg($('unlockedMsg'), res.ok ? '로그인을 진행했습니다.' : errorText(res), res.ok ? 'good' : 'error');
});

// K-에듀파인·나이스: 업무포털 접속 → 로그인 → 해당 화면까지 (이미 된 단계는 건너뜀)
for (const [id, target] of [['edufineBtn', 'edufine'], ['neisBtn', 'neis']]) {
  $(id).addEventListener('click', async () => {
    showMsg($('unlockedMsg'), '여는 중…', 'pending');
    const res = await busy($(id), () => send('openTarget', { target }));
    // 탭이 바뀌면 팝업이 닫혀 이 아래는 대개 실행되지 않는다 (실패하면 열린 화면에도 안내가 뜸)
    showMsg($('unlockedMsg'), res.text || errorText(res), res.ok ? 'good' : 'error');
  });
}

// 과세특 입력: 입력 화면을 열고, 나이스 과세특 화면(OTP 창)까지 자동으로 간다
$('remarksBtn').addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('remarks.html?go=1') }));

// 잠금과 무관 (비밀 정보 없음): 열린 나이스 화면의 구조만 복사 (화면 이름: 진단 정보 복사)
$('dumpBtn').addEventListener('click', async () => {
  const res = await busy($('dumpBtn'), () => send('dumpStructure'));
  if (!res.ok) return showMsg($('dumpMsg'), errorText(res));
  await navigator.clipboard.writeText(res.text);
  const lines = res.text.split('\n').length;
  showMsg($('dumpMsg'), `복사했습니다 (${lines}줄). 대화창에 붙여넣어 주세요.`, 'good');
});

for (const b of document.querySelectorAll('[data-open-options]')) {
  b.addEventListener('click', () => chrome.runtime.openOptionsPage());
}

render();
