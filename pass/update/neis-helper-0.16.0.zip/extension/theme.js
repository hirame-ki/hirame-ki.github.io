// 화면 테마: 모든 확장 화면(팝업·설정·과세특·루틴)의 <head>에서 가장 먼저 읽는다.
// 1) localStorage에 적어 둔 테마를 바로 입혀 깜빡임을 막고
// 2) chrome.storage.local의 'theme'(설정 › 화면에서 고른 값)과 맞추며
// 3) 다른 창에서 바꾸면 열린 화면도 바로 따라 바뀐다.
// 모듈이 아닌 일반 스크립트 (CSP: 인라인 금지라 파일로 둔다)
(function () {
  var THEMES = ['sky', 'beige', 'lime', 'mint', 'lavender', 'peach'];
  var CACHE = 'ssampass-theme';

  function apply(t) {
    if (THEMES.indexOf(t) < 0) t = 'sky';
    document.documentElement.setAttribute('data-theme', t);
    return t;
  }
  function remember(t) {
    try { localStorage.setItem(CACHE, t); } catch (e) { /* 저장 못 해도 화면은 그대로 */ }
  }

  var cached = null;
  try { cached = localStorage.getItem(CACHE); } catch (e) { /* 무시 */ }
  apply(cached);

  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return;
  chrome.storage.local.get('theme').then(function (r) {
    if (r && r.theme) remember(apply(r.theme));
  }, function () { /* 읽기 실패: 캐시 값 유지 */ });
  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area === 'local' && changes.theme) remember(apply(changes.theme.newValue));
  });
})();
