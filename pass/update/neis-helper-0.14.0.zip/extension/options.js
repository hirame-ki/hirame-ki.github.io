import { send, errorText, showMsg, busy, flowSteps, FLOW_TARGET_LABELS, $ } from './common.js';
import { LEAVE_TYPES, AV_KINDS } from './sites.js';

const PIN_RE = /^[0-9]{6,12}$/;

function clear(...ids) { for (const id of ids) $(id).value = ''; }

// ── 왼쪽 메뉴: 주소의 #이름으로 패널 하나만 보인다 ──

const PANELS = [...document.querySelectorAll('[data-panel]')].map((el) => el.dataset.panel);

function showPanel() {
  const name = PANELS.includes(location.hash.slice(1)) ? location.hash.slice(1) : PANELS[0];
  for (const el of document.querySelectorAll('[data-panel]')) el.classList.toggle('hidden', el.dataset.panel !== name);
  for (const a of document.querySelectorAll('#nav a')) a.classList.toggle('active', a.getAttribute('href') === `#${name}`);
}
window.addEventListener('hashchange', showPanel);
showPanel();
$('versionText').textContent = chrome.runtime.getManifest().version;

async function render() {
  const st = await send('getState');
  const dot = $('stateDot');
  if (!st.hostOk) {
    dot.className = 'dot off';
    $('stateText').textContent = errorText({ error: st.hostError || 'host_unavailable' });
  } else if (!st.configured) {
    dot.className = 'dot';
    $('stateText').textContent = '아직 설정하지 않았습니다';
  } else {
    dot.className = st.unlocked ? 'dot on' : 'dot';
    $('stateText').textContent = st.unlocked ? '설정됨 · 열림' : '설정됨 · 잠김';
  }
  $('setupCard').classList.toggle('hidden', !st.hostOk || st.configured);
  $('manageCard').classList.toggle('hidden', !st.hostOk || !st.configured);
  renderLockMode(st.settings.lockMode);
  $('idle').value = st.settings.idleMinutes;
  $('max').value = st.settings.maxUnlockMinutes;
  if (!routesLoaded) { renderRoutes(st.routes); routesLoaded = true; }
  savedRoutes = st.routes;
  if (!flowsLoaded) { renderFlows(st.flows); flowsLoaded = true; } else refreshFlowRouteOptions();
  if (!$('portalUrl').value) $('portalUrl').value = st.portalUrl;
  renderAuto(st);
  $('autoLoginChk').checked = st.autoLogin === true;
  if (st.autoLogin && st.autoLoginBlocked) {
    showMsg($('autoLoginMsg'), '지난 자동 로그인이 실패한 것 같아 멈춰 있습니다. 비밀번호를 확인한 뒤 체크를 껐다 다시 켜세요.');
  }
  renderShortcuts();
  renderUpdate(st);
}

// ── 업데이트 ──

function renderUpdate(st) {
  const u = st.update;
  $('autoUpdateChk').checked = st.autoUpdate !== false;
  let text = `지금 버전 ${st.version}`;
  if (!u) text += ' · 아직 확인하지 않았습니다.';
  else if (!u.ok) text += ` · ${errorText({ error: u.error })}`;
  else if (u.available && u.installed) text += ` · 새 버전 ${u.version}이 있습니다.`;
  else if (u.available) text += ` · 새 버전 ${u.version}이 있지만 개발용 설치라 자동으로 바꾸지 않습니다.`;
  else text += ' · 최신 버전입니다.';
  if (u && u.checkedAt) text += ` (확인: ${new Date(u.checkedAt).toLocaleString('ko-KR')})`;
  $('updateState').textContent = text;
  $('updateNotes').classList.toggle('hidden', !(u && u.available && u.notes));
  $('updateNotes').textContent = u && u.notes ? `바뀐 점: ${u.notes}` : '';
  $('applyUpdateBtn').classList.toggle('hidden', !(u && u.available && u.installed));
  if (u && u.available) $('applyUpdateBtn').textContent = `${u.version}으로 업데이트`;
}

$('checkUpdateBtn').addEventListener('click', async () => {
  const res = await busy($('checkUpdateBtn'), () => send('checkUpdate'));
  showMsg($('updateMsg'), res.ok ? (res.available ? `새 버전 ${res.version}이 있습니다.` : '최신 버전입니다.') : errorText(res), res.ok ? 'good' : 'error');
  render();
});

$('applyUpdateBtn').addEventListener('click', async () => {
  showMsg($('updateMsg'), '새 버전을 받아 설치하는 중… 끝나면 확장이 다시 시작되고 잠깁니다.', 'pending');
  const res = await busy($('applyUpdateBtn'), () => send('applyUpdate'));
  if (!res.ok) showMsg($('updateMsg'), errorText(res));
});

$('autoUpdateChk').addEventListener('change', async () => {
  const res = await send('setAutoUpdate', { enabled: $('autoUpdateChk').checked });
  showMsg($('updateMsg'), res.ok ? ($('autoUpdateChk').checked ? '자동 설치를 켰습니다.' : '자동 설치를 껐습니다. 새 버전이 있으면 알려만 줍니다.') : errorText(res), res.ok ? 'good' : 'error');
});

// ── 로그인 자동 실행 ──

$('autoLoginChk').addEventListener('change', async () => {
  const res = await send('setAutoLogin', { enabled: $('autoLoginChk').checked });
  showMsg($('autoLoginMsg'), res.ok ? ($('autoLoginChk').checked ? '켰습니다.' : '껐습니다.') : errorText(res), res.ok ? 'good' : 'error');
});

// ── 잠금 방식: 시간이 지나면(기본) / PC 화면을 잠글 때만(동의 필요) ──

let lockMode = 'timer';

function renderLockMode(mode) {
  lockMode = mode;
  for (const r of document.querySelectorAll('input[name=lockMode]')) r.checked = r.value === mode;
  $('timerCard').classList.toggle('hidden', mode === 'session');
}

for (const r of document.querySelectorAll('input[name=lockMode]')) {
  r.addEventListener('change', async () => {
    if (r.value === 'session') {
      // 동의하기 전까지는 바뀌지 않는다
      $('lockConsentChk').checked = false;
      $('lockConsentOkBtn').disabled = true;
      $('lockConsentBox').classList.remove('hidden');
      return;
    }
    $('lockConsentBox').classList.add('hidden');
    const res = await send('setLockMode', { mode: 'timer' });
    if (res.ok) renderLockMode('timer');
    showMsg($('lockModeMsg'), res.ok ? '시간이 지나면 잠그도록 바꿨습니다.' : errorText(res), res.ok ? 'good' : 'error');
  });
}
$('lockConsentChk').addEventListener('change', () => { $('lockConsentOkBtn').disabled = !$('lockConsentChk').checked; });
$('lockConsentCancelBtn').addEventListener('click', () => {
  $('lockConsentBox').classList.add('hidden');
  renderLockMode(lockMode);
});
$('lockConsentOkBtn').addEventListener('click', async () => {
  const res = await busy($('lockConsentOkBtn'), () => send('setLockMode', { mode: 'session', agreed: $('lockConsentChk').checked }));
  if (res.ok) {
    $('lockConsentBox').classList.add('hidden');
    renderLockMode('session');
  }
  showMsg($('lockModeMsg'), res.ok ? 'PC 화면을 잠글 때만 잠그도록 바꿨습니다. 자리를 비울 때 Win+L을 잊지 마세요.' : errorText(res), res.ok ? 'good' : 'error');
});

// ── 업무포털 주소 ──

$('portalForm').addEventListener('submit', (e) => {
  e.preventDefault();
  run(e.target, $('portalMsg'), async () => {
    const res = await send('setPortalUrl', { url: $('portalUrl').value });
    if (res.ok) $('portalUrl').value = res.url;
    showMsg($('portalMsg'), res.ok ? '저장했습니다.' : errorText(res), res.ok ? 'good' : 'error');
  });
});

// ── 루틴 편집 ──
// 복무 신청 단계는 "저장된" 복무 신청 버튼 중에서 고른다 (편집 중인 것은 저장 후에 나타남)

let flowsLoaded = false;
let savedRoutes = [];

function routeOptions(selected) {
  const pairs = savedRoutes.map((r) => [r.id, r.name]);
  // 고른 버튼이 지워졌으면 다른 버튼으로 슬쩍 바뀌지 않게 빈 값으로 두고 다시 고르게 한다
  if (selected && !pairs.some(([v]) => v === selected)) pairs.unshift(['', '(지워진 버튼 — 다시 고르세요)']);
  else if (!pairs.length) pairs.push(['', '(복무 신청 버튼을 먼저 저장하세요)']);
  if (selected && !pairs.some(([v]) => v === selected)) selected = '';
  return pairs.map(([v, t]) => new Option(t, v, false, v === selected));
}

function refreshFlowRouteOptions() {
  for (const sel of document.querySelectorAll('#flowList [data-k=routeId]')) {
    const cur = sel.value;
    sel.replaceChildren(...routeOptions(cur));
  }
  for (const card of $('flowList').children) card.sync?.();
}

function flowCard(f) {
  const card = document.createElement('div');
  card.className = 'flow';
  card.dataset.id = f.id;

  const name = tag(input('text', f.name, { maxLength: 20, placeholder: '예: 출근, 조퇴 올리기' }), 'name');
  const target = tag(select(Object.entries(FLOW_TARGET_LABELS), f.target || 'login'), 'target');
  const route = tag(document.createElement('select'), 'routeId');
  route.append(...routeOptions(f.routeId));
  const routeField = field('복무 신청 버튼', route);

  const steps = document.createElement('ol');
  steps.className = 'steps left';

  const msg = document.createElement('div');
  msg.className = 'msg';

  const shortcut = document.createElement('button');
  shortcut.type = 'button';
  shortcut.className = 'soft';
  shortcut.textContent = '바탕화면에 바로가기 만들기';
  shortcut.addEventListener('click', async () => {
    // 편집 중인 내용을 먼저 저장해야 바로가기가 맞는 버튼을 가리킨다
    const saved = await saveFlows();
    if (!saved.ok) return showMsg(msg, errorText(saved));
    const res = await busy(shortcut, () => send('createShortcut', { flowId: card.dataset.id }));
    showMsg(msg, res.ok ? '바탕화면에 만들었습니다. 아이콘을 더블클릭해 보세요.' : errorText(res), res.ok ? 'good' : 'error');
  });

  const del = document.createElement('button');
  del.type = 'button';
  del.className = 'danger';
  del.textContent = '삭제';
  del.addEventListener('click', () => card.remove());

  const actions = document.createElement('div');
  actions.className = 'flow-actions';
  actions.append(shortcut, del);

  card.append(row(field('버튼 이름', name), field('순서', target)), routeField, steps, actions, msg);

  card.sync = () => {
    routeField.classList.toggle('hidden', target.value !== 'route');
    steps.replaceChildren(...flowSteps({ target: target.value, routeId: route.value }, savedRoutes).map((t) => {
      const li = document.createElement('li');
      li.textContent = t;
      return li;
    }));
  };
  target.addEventListener('change', card.sync);
  route.addEventListener('change', card.sync);
  card.sync();
  return card;
}

function renderFlows(flows) {
  $('flowList').replaceChildren(...flows.map(flowCard));
}

function readFlows() {
  return [...$('flowList').children].map((card) => {
    const v = (k) => card.querySelector(`[data-k=${k}]`);
    const f = { id: card.dataset.id, name: v('name').value.trim(), target: v('target').value };
    return f.target === 'route' ? { ...f, routeId: v('routeId').value } : f;
  });
}

async function saveFlows() {
  const flows = readFlows();
  const bad = flows.find((f) => !f.name || (f.target === 'route' && !f.routeId));
  if (bad) return { ok: false, error: 'invalid_flows' };
  return send('saveFlows', { flows });
}

$('addFlowBtn').addEventListener('click', () => {
  if ($('flowList').children.length >= 6) return showMsg($('flowsMsg'), '루틴은 6개까지 만들 수 있습니다.');
  $('flowList').append(flowCard({ id: crypto.randomUUID(), name: '', target: 'login' }));
});

$('saveFlowsBtn').addEventListener('click', async () => {
  const res = await busy($('saveFlowsBtn'), saveFlows);
  showMsg($('flowsMsg'), res.ok ? '저장했습니다. 툴바 아이콘의 팝업 맨 위에 나타납니다.' : errorText(res), res.ok ? 'good' : 'error');
});

// ── 단축키 ──

async function renderShortcuts() {
  const cmds = await chrome.commands.getAll();
  $('shortcutList').replaceChildren(...cmds.map((c) => {
    const row = document.createElement('div');
    const key = document.createElement('kbd');
    key.textContent = c.shortcut || '지정 안 됨';
    if (!c.shortcut) key.className = 'none';
    row.append(c.name === '_execute_action' ? '팝업 열기' : c.description, key);
    return row;
  }));
}

$('shortcutBtn').addEventListener('click', () => chrome.tabs.create({ url: 'chrome://extensions/shortcuts' }));

// ── 복무 신청 버튼 편집 ──
// 버튼 종류: 시간외근무(overtime) / 조퇴·외출 등 근무상황(leave). 종류에 맞는 칸만 보인다.

const TYPES = [['1', '시간외 근무'], ['2', '야간 근무'], ['3', '휴일 근무']];
let routesLoaded = false;

function field(labelText, input, k) {
  const wrap = document.createElement('div');
  const label = document.createElement('label');
  label.textContent = labelText;
  wrap.append(label, input);
  if (k) wrap.dataset.only = k; // 이 종류일 때만 보임
  return wrap;
}

function input(type, value, attrs = {}) {
  const el = document.createElement('input');
  el.type = type;
  el.value = value ?? '';
  Object.assign(el, attrs);
  return el;
}

function select(pairs, value) {
  const el = document.createElement('select');
  for (const [v, t] of pairs) el.append(new Option(t, v, false, v === value));
  return el;
}

function check(text, on, k) {
  const box = input('checkbox', '', { checked: !!on });
  box.dataset.k = k;
  const label = document.createElement('label');
  label.className = 'check';
  label.append(box, text);
  return label;
}

function row(...kids) {
  const r = document.createElement('div');
  r.className = 'row';
  r.append(...kids);
  return r;
}

function tag(el, k) { el.dataset.k = k; return el; }

function routeCard(r) {
  const card = document.createElement('div');
  card.className = 'route';
  card.dataset.id = r.id;

  const kind = tag(select([['overtime', '시간외근무'], ['leave', '조퇴·외출 등 (근무상황)']], r.kind || 'overtime'), 'kind');
  const name = tag(input('text', r.name, { maxLength: 20, placeholder: '예: 시간외(평일), 조퇴' }), 'name');

  // 시간외근무 전용
  const type = tag(select(TYPES, r.type || '1'), 'type');
  const holiday = check('휴일', r.holiday, 'holiday');
  holiday.dataset.only = 'overtime';

  // 근무상황 전용
  const sclf = tag(select(Object.entries(LEAVE_TYPES), r.sclf || 'W0104'), 'sclf');
  const avKind = tag(select(Object.entries(AV_KINDS), r.avKind || '1'), 'avKind');
  const contact = tag(input('tel', r.contact, { maxLength: 11, placeholder: '숫자만, 비워도 됨' }), 'contact');
  const hide = row(check('기간 비공개', r.hidePeriod, 'hidePeriod'), check('사유 비공개', r.hideReason, 'hideReason'));
  hide.dataset.only = 'leave';

  const start = tag(input('time', r.start, { step: 300 }), 'start');
  const end = tag(input('time', r.end, { step: 300 }), 'end');
  const reason = tag(input('text', r.reason, { maxLength: 400 }), 'reason');
  const line = tag(input('text', r.lineName, { maxLength: 50, placeholder: '비우면 결재선이 하나뿐일 때 자동 선택' }), 'lineName');

  const del = document.createElement('button');
  del.type = 'button';
  del.className = 'danger';
  del.textContent = '이 버튼 삭제';
  del.addEventListener('click', () => card.remove());

  const timeHint = document.createElement('p');
  timeHint.className = 'muted';
  timeHint.dataset.only = 'leave';
  timeHint.textContent = '조퇴는 시작 = 나가는 시각, 종료 = 퇴근 시각. 5분 단위. 팝업에서 그날만 시각을 바꿀 수 있습니다.';

  card.append(
    row(field('종류', kind), field('버튼 이름', name)),
    row(field('종별', type, 'overtime'), holiday, field('근무상황', sclf, 'leave'), field('연가종류', avKind, 'leave')),
    row(field('시작', start), field('종료', end)),
    timeHint,
    field('', reason),
    field('연락처', contact, 'leave'),
    hide,
    field('나이스 개인결재선 이름', line),
    del,
  );

  const sync = () => {
    const k = kind.value;
    for (const el of card.querySelectorAll('[data-only]')) el.classList.toggle('hidden', el.dataset.only !== k);
    reason.previousSibling.textContent = k === 'leave' ? '사유' : '하여야 할 일';
    reason.placeholder = k === 'leave' ? '예: 병원 진료' : '예: 학생 상담 및 수업 준비';
    // 연가종류는 연가(W01…)일 때만
    avKind.parentElement.classList.toggle('hidden', k !== 'leave' || !sclf.value.startsWith('W01'));
  };
  kind.addEventListener('change', sync);
  sclf.addEventListener('change', sync);
  sync();
  return card;
}

function renderRoutes(routes) {
  $('routeList').replaceChildren(...routes.map(routeCard));
}

function readRoutes() {
  return [...$('routeList').children].map((card) => {
    const v = (k) => card.querySelector(`[data-k=${k}]`);
    const kind = v('kind').value;
    const base = {
      id: card.dataset.id, kind,
      name: v('name').value.trim(), start: v('start').value, end: v('end').value,
      reason: v('reason').value.trim(), lineName: v('lineName').value.trim(),
    };
    return kind === 'leave'
      ? { ...base, sclf: v('sclf').value, avKind: v('avKind').value, contact: v('contact').value.replace(/\D/g, ''),
          hidePeriod: v('hidePeriod').checked, hideReason: v('hideReason').checked }
      : { ...base, type: v('type').value, holiday: v('holiday').checked };
  });
}

$('addRouteBtn').addEventListener('click', () => {
  if ($('routeList').children.length >= 6) return showMsg($('routesMsg'), '버튼은 6개까지 만들 수 있습니다.');
  $('routeList').append(routeCard({ id: crypto.randomUUID(), kind: 'overtime', name: '', start: '', end: '', reason: '', lineName: '' }));
});

$('saveRoutesBtn').addEventListener('click', async () => {
  const routes = readRoutes();
  const bad = routes.find((r) => !r.name || !r.start || !r.end || !r.reason || r.start >= r.end
    || (r.kind === 'leave' && (Number(r.start.slice(3)) % 5 || Number(r.end.slice(3)) % 5)));
  if (bad) {
    return showMsg($('routesMsg'), `"${bad.name || '이름 없음'}" 버튼: 이름·시작·종료·사유(하여야 할 일)를 채우고, 시작이 종료보다 빨라야 합니다.${bad.kind === 'leave' ? ' 조퇴 등은 5분 단위입니다.' : ''}`);
  }
  const res = await busy($('saveRoutesBtn'), () => send('saveRoutes', { routes }));
  if (res.ok) { savedRoutes = routes; refreshFlowRouteOptions(); }
  showMsg($('routesMsg'), res.ok ? '저장했습니다. 툴바 아이콘이나 단축키로 실행합니다.' : errorText(res), res.ok ? 'good' : 'error');
});

// ── [상신] 자동 클릭 (기본 꺼짐, 경고 동의 후에만 켬) ──

function renderAuto(st) {
  const on = st.autoSubmit === true;
  $('autoDot').className = on ? 'dot off' : 'dot on';
  $('autoText').textContent = on
    ? `켜짐 — 확인 없이 상신됩니다 (동의: ${new Date(st.autoSubmitAgreedAt).toLocaleString('ko-KR')})`
    : '꺼짐 — 결재선까지 넣고 멈춥니다';
  $('autoOnBtn').classList.toggle('hidden', on);
  $('autoOffBtn').classList.toggle('hidden', !on);
  if (on) $('consentBox').classList.add('hidden');
}

$('autoOnBtn').addEventListener('click', () => {
  $('consentChk').checked = false;
  $('consentOkBtn').disabled = true;
  $('consentBox').classList.remove('hidden');
});
$('consentChk').addEventListener('change', () => { $('consentOkBtn').disabled = !$('consentChk').checked; });
$('consentCancelBtn').addEventListener('click', () => $('consentBox').classList.add('hidden'));
$('consentOkBtn').addEventListener('click', async () => {
  const res = await send('setAutoSubmit', { enabled: true, agreed: $('consentChk').checked });
  showMsg($('autoMsg'), res.ok ? '자동 상신을 켰습니다.' : errorText(res), res.ok ? 'good' : 'error');
  render();
});
$('autoOffBtn').addEventListener('click', async () => {
  const res = await send('setAutoSubmit', { enabled: false });
  showMsg($('autoMsg'), res.ok ? '자동 상신을 껐습니다.' : errorText(res), res.ok ? 'good' : 'error');
  render();
});

// 서버 응답을 기다리는 동안 폼 버튼을 막는다 (PIN 확인에 1~2초 걸림)
async function run(form, msgEl, task) {
  showMsg(msgEl, '처리 중…', 'pending');
  return busy(form.querySelector('button[type=submit]'), task);
}

$('setupForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const pw = $('pw1').value, pin = $('pin1').value;
  if (!pw) return showMsg($('setupMsg'), errorText({ error: 'invalid_password' }));
  if (pw !== $('pw2').value) return showMsg($('setupMsg'), '비밀번호 확인이 다릅니다.');
  if (!PIN_RE.test(pin)) return showMsg($('setupMsg'), errorText({ error: 'invalid_pin' }));
  if (pin !== $('pin2').value) return showMsg($('setupMsg'), 'PIN 확인이 다릅니다.');
  run(e.target, $('setupMsg'), async () => {
    const res = await send('setup', { password: pw, pin });
    clear('pw1', 'pw2', 'pin1', 'pin2');
    showMsg($('setupMsg'), res.ok ? '저장했습니다. 툴바의 확장 아이콘에서 PIN으로 잠금을 푸세요.' : errorText(res), res.ok ? 'good' : 'error');
    render();
  });
});

$('settingsForm').addEventListener('submit', (e) => {
  e.preventDefault();
  run(e.target, $('settingsMsg'), async () => {
    const res = await send('saveSettings', { idleMinutes: $('idle').value, maxUnlockMinutes: $('max').value });
    showMsg($('settingsMsg'), res.ok ? '저장했습니다. 최대 유지 시간은 다음 잠금 해제부터 적용됩니다.' : errorText(res), res.ok ? 'good' : 'error');
  });
});

$('pinForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const pin = $('oldPin').value, newPin = $('newPin1').value;
  if (!PIN_RE.test(newPin)) return showMsg($('pinMsg'), errorText({ error: 'invalid_new_pin' }));
  if (newPin !== $('newPin2').value) return showMsg($('pinMsg'), '새 PIN 확인이 다릅니다.');
  run(e.target, $('pinMsg'), async () => {
    const res = await send('changePin', { pin, newPin });
    clear('oldPin', 'newPin1', 'newPin2');
    showMsg($('pinMsg'), res.ok ? 'PIN을 바꿨습니다.' : errorText(res), res.ok ? 'good' : 'error');
  });
});

$('pwForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const pin = $('pwPin').value, pw = $('newPw1').value;
  if (!pw) return showMsg($('pwMsg'), errorText({ error: 'invalid_password' }));
  if (pw !== $('newPw2').value) return showMsg($('pwMsg'), '새 비밀번호 확인이 다릅니다.');
  run(e.target, $('pwMsg'), async () => {
    const res = await send('updatePassword', { pin, password: pw });
    clear('pwPin', 'newPw1', 'newPw2');
    showMsg($('pwMsg'), res.ok ? '비밀번호를 바꿨습니다. 보안을 위해 잠겼습니다.' : errorText(res), res.ok ? 'good' : 'error');
    render();
  });
});

$('resetBtn').addEventListener('click', async () => {
  if (!confirm('저장된 인증서 비밀번호를 지울까요? 되돌릴 수 없습니다.')) return;
  const res = await send('reset');
  showMsg($('resetMsg'), res.ok ? '지웠습니다. 처음 설정부터 다시 하세요.' : errorText(res), res.ok ? 'good' : 'error');
  render();
});

render();
