// 과세특 — 나이스 페이지 안(MAIN world)에서 실행되는 함수들. executeScript의 func로 넘기므로 바깥 변수를 쓰면 안 된다(인자만).
// cfg = NEIS_SUBJECT_REMARKS (sites.js)
//
// 확인된 것 (10-15, [진단 정보 복사])
//   dsGridMain 한 행 = 학생 한 명. clsNm=반, stdntCn=번호, classNo="반/번호", stuFlnm=이름
//   genDetaAbtSpablMteCn = 일반 세특, genDetaAbtSpablMteCnLength = 그 바이트
//   othSemInputLen01 = 일반 칸의 남은(입력 가능) 바이트 — 화면 "0 / 177 Byte"의 177
//   enableYn = 입력 가능 여부
// 값 넣기는 화면 안에서만 일어나고(서버 통신 없음), [저장]을 눌러야 나이스에 기록된다.

// 지금 조회된 명단과 2차 인증 남은 시간
export function readRosterInPage(cfg) {
  const P = window.cpr?.core?.Platform?.INSTANCE;
  if (!P) return { ok: false, error: 'not_exbuilder' };
  const app = P.getAllRunningAppInstances().find((a) => a.app.id === cfg.app);
  if (!app) return { ok: false, error: 'no_remarks_screen' };
  const ds = app.lookup(cfg.grid)?.dataSet;
  if (!ds) return { ok: false, error: 'no_remarks_screen' };

  // 머리글의 "(2차인증:29분 52초)"
  let authSeconds = null;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while (walker.nextNode()) {
    const m = /2차\s*인증\s*:\s*(?:(\d+)\s*분)?\s*(\d+)\s*초/.exec(walker.currentNode.textContent);
    if (m) { authSeconds = Number(m[1] || 0) * 60 + Number(m[2]); break; }
  }

  const c = cfg.cols;
  const RS = window.cpr?.data?.tabledata?.RowState;
  const rows = [];
  for (let i = 0; i < ds.getRowCount(); i++) {
    const v = (k) => ds.getValue(i, k);
    rows.push({
      i,
      cls: Number(v(c.classOnly)),
      no: Number(v(c.numberOnly)),
      classNo: String(v(c.classNo) ?? ''),
      name: String(v(c.name) ?? '').trim(),
      current: String(v(c.general) ?? ''),
      curLen: Number(v(c.generalLen) || 0),
      limit: Number(v(c.remain)),
      enable: String(v(c.enable)) !== 'false',
      changed: RS && ds.getRowState ? ds.getRowState(i) !== RS.UNCHANGED : null,
    });
  }
  return {
    ok: true,
    subject: String(ds.getRowCount() ? ds.getValue(0, c.subject) ?? '' : ''),
    grade: ds.getRowCount() ? Number(ds.getValue(0, c.grade)) : null,
    authSeconds,
    rows,
  };
}

// items: [{ i, classNo, name, text }] — 행 번호뿐 아니라 반/번호·이름이 그대로인지 확인한 뒤에만 넣는다
export function writeRowsInPage(cfg, items) {
  const P = window.cpr?.core?.Platform?.INSTANCE;
  const app = P && P.getAllRunningAppInstances().find((a) => a.app.id === cfg.app);
  const ds = app && app.lookup(cfg.grid)?.dataSet;
  if (!ds) return { ok: false, error: 'no_remarks_screen' };
  const c = cfg.cols;
  const results = [];
  for (const it of items) {
    const same = it.i < ds.getRowCount()
      && String(ds.getValue(it.i, c.classNo)) === it.classNo
      && String(ds.getValue(it.i, c.name) ?? '').trim() === it.name;
    if (!same) { results.push({ i: it.i, ok: false, error: 'row_changed' }); continue; }
    if (String(ds.getValue(it.i, c.enable)) === 'false') { results.push({ i: it.i, ok: false, error: 'disabled' }); continue; }
    ds.setValue(it.i, c.general, it.text); // 데이터셋 update 이벤트 → 화면·바이트 표시는 나이스가 갱신
    const back = String(ds.getValue(it.i, c.general) ?? '');
    results.push({ i: it.i, ok: back === it.text, error: back === it.text ? null : 'verify_failed', len: Number(ds.getValue(it.i, c.generalLen) || 0) });
  }
  return { ok: true, results };
}
