// 팝업·설정 화면 공용

export function send(cmd, data = {}) {
  return chrome.runtime.sendMessage({ cmd, ...data });
}

const ERRORS = {
  host_unavailable: '도우미 프로그램이 연결되지 않았습니다. host\\install.ps1을 실행했는지 확인하세요.',
  not_configured: '아직 설정하지 않았습니다.',
  already_configured: '이미 설정되어 있습니다.',
  invalid_pin: 'PIN은 숫자 6~12자리입니다.',
  invalid_new_pin: '새 PIN은 숫자 6~12자리입니다.',
  invalid_password: '비밀번호를 입력하세요.',
  invalid_settings: '설정값이 범위를 벗어났습니다.',
  locked: '잠겨 있습니다. PIN으로 먼저 잠금을 푸세요.',
  not_neis: '업무포털(eduptl.kr)이나 나이스 화면이 열려 있지 않습니다.',
  no_focused_password: '비밀번호 입력칸을 먼저 클릭한 뒤 다시 누르세요.',
  forbidden: '허용되지 않은 요청입니다.',
  no_portal_tab: '업무포털 로그인 화면을 찾지 못했습니다. 설정 > 로그인에서 업무포털 주소를 확인하세요.',
  no_login_button: '로그인 화면이 아닙니다. 이미 로그인되어 있거나 다른 화면입니다.',
  no_cert_list: '인증서 목록이 나타나지 않았습니다. 인증서 프로그램(KSign)이 설치·실행 중인지 확인하세요.',
  submit_failed: '인증서 창의 비밀번호 칸이나 확인 버튼을 찾지 못했습니다. 화면 구조가 바뀌었을 수 있습니다.',
  script_failed: '페이지에서 실행하지 못했습니다.',
  no_neis_tab: '나이스 탭이 열려 있지 않습니다.',
  not_exbuilder: '나이스 화면 정보를 읽지 못했습니다. 화면이 다 열린 뒤 다시 누르세요.',
  no_neis_main: '나이스가 열려 있지 않습니다. 업무포털에서 나이스를 먼저 여세요.',
  no_portal_main: '로그인된 업무포털 화면이 없습니다. 먼저 업무포털에 로그인하세요.',
  running: '이미 실행 중입니다.',
  no_route: '설정에서 복무 신청 버튼을 먼저 저장하세요.',
  invalid_date: '날짜를 확인하세요.',
  invalid_times: '시각을 확인하세요. (시작이 종료보다 빨라야 하고, 조퇴·외출 등은 5분 단위)',
  invalid_routes: '복무 신청 설정값을 확인하세요. (이름, 시각, 하여야 할 일은 필수)',
  consent_required: '안내 내용에 동의해야 켤 수 있습니다.',
  busy: '나이스에 신청·상신 창이 이미 열려 있습니다. 닫은 뒤 다시 실행하세요.',
  timeout: '나이스 화면이 제때 열리지 않았습니다.',
  unexpected_rows: '신청 창의 기본 행 수가 예상과 다릅니다.',
  verify_failed: '값이 제대로 들어가지 않았습니다. 승인요청 전에 멈췄습니다.',
  no_draft: '[승인요청] 뒤 상신 창이 뜨지 않았습니다. 나이스 화면의 안내 메시지를 확인하세요.',
  no_lines: '나이스에 저장된 개인결재선이 없습니다. ⚙개인설정 > 업무승인자관리 > 개인결재선관리에서 먼저 만드세요.',
  line_empty: '선택한 개인결재선에 결재자가 없습니다.',
  line_not_applied: '결재선이 상신 창에 들어가지 않았습니다.',
  no_flow: '이 루틴이 설정에 없습니다. 설정에서 다시 만드세요.',
  invalid_flows: '루틴 설정값을 확인하세요. (이름은 필수, 복무 신청을 고른 경우 그 버튼이 저장되어 있어야 함)',
  invalid_portal_url: '업무포털 주소는 https://○○.eduptl.kr 형태여야 합니다.',
  portal_not_loaded: '업무포털 화면이 열리지 않았습니다. 학교 안 망에서만 접속되는지 확인하세요.',
  tab_closed: '업무포털 탭이 닫혔습니다.',
  login_timeout: '로그인 뒤 업무포털 메인 화면이 나오지 않았습니다. 인증서 창의 안내를 확인하세요.',
  login_unconfirmed: '지난 자동 로그인이 끝났는지 확인하지 못해 다시 시도하지 않았습니다. (인증서 잠김 방지)\n인증서 비밀번호가 맞는지 확인한 뒤, 열린 로그인 화면에서 [업무포털 로그인]을 다시 누르세요.',
  already_logged_in: '이미 업무포털에 로그인되어 있습니다.',
  neis_timeout: '나이스 화면이 제때 열리지 않았습니다.',
  browser_not_found: '브라우저 실행 파일을 찾지 못했습니다.',
  bad_origin: '도우미 프로그램이 확장 정보를 받지 못했습니다.',
  invalid_shortcut: '바로가기 정보가 올바르지 않습니다.',
  no_remarks_screen: '나이스에 과목별세부능력및특기사항 화면이 열려 있지 않습니다. 교과담임 > 성적처리 > 과목별세부능력및특기사항을 여세요.',
  invalid_items: '입력할 내용이 올바르지 않습니다.',
  no_update_key: '서명 열쇠가 없는 개발용 프로그램이라 업데이트를 확인하지 않습니다.',
  no_update_config: '개발용 설치라 업데이트 주소가 없습니다. (설치 파일로 설치한 PC에서만 업데이트)',
  not_installed_copy: '개발용 설치(프로젝트 폴더)에서는 자동 업데이트를 하지 않습니다.',
  bad_update_url: '업데이트 주소가 올바르지 않습니다.',
  download_failed: '업데이트 정보를 받지 못했습니다. 인터넷 연결을 확인하세요.',
  bad_update_info: '업데이트 정보 파일이 올바르지 않습니다.',
  bad_signature: '업데이트 파일의 서명이 맞지 않아 설치하지 않았습니다.',
  hash_mismatch: '받은 업데이트 파일이 손상되었거나 바뀌어 설치하지 않았습니다.',
  bad_package: '업데이트 묶음의 구성이 올바르지 않아 설치하지 않았습니다.',
  replace_failed: '파일을 바꾸지 못해 원래대로 되돌렸습니다. 브라우저를 다시 켠 뒤 시도하세요.',
  no_update: '이미 최신 버전입니다.',
  bad_version: '현재 버전 정보를 읽지 못했습니다.',
};

// 루틴이 하는 일을 단계 목록으로 (설정·팝업·실행 화면 공용)
export const FLOW_TARGET_LABELS = {
  login: '로그인만',
  edufine: '로그인 → K-에듀파인',
  neis: '로그인 → 나이스',
  route: '로그인 → 나이스 → 복무 신청',
};

export function flowSteps(flow, routes = []) {
  const steps = ['업무포털 로그인'];
  if (flow.target === 'edufine') steps.push('K-에듀파인 열기');
  if (flow.target === 'neis' || flow.target === 'route') steps.push('나이스 열기');
  if (flow.target === 'route') {
    const r = routes.find((x) => x.id === flow.routeId);
    steps.push(`${r ? r.name : '(지워진 버튼)'} 입력`, '[상신]은 직접');
  }
  return steps;
}

export function errorText(res) {
  if (res.error === 'no_focused_password') {
    return ERRORS.no_focused_password + (res.detail ? `\n\n진단:\n${res.detail}` : '');
  }
  if (res.error === 'choose_cert') {
    return `인증서가 ${res.count}개입니다. 인증서 창에서 사용할 인증서를 클릭한 뒤 다시 누르세요. (다음부터는 자동 선택)`;
  }
  if (res.error === 'menu_not_found') return `나이스 메뉴에서 "${res.detail}"을(를) 찾지 못했습니다. 메뉴 권한이나 화면 구조를 확인하세요.`;
  if (res.error === 'menu_link_not_found') return `업무포털 상단 메뉴에서 "${res.detail}"을(를) 찾지 못했습니다.`;
  if (res.error === 'line_not_found') return `설정의 개인결재선 이름이 나이스와 다릅니다.\n나이스에 있는 결재선: ${res.detail}`;
  if (['timeout', 'no_draft'].includes(res.error) && res.detail) return `${ERRORS[res.error]}\n나이스 안내: ${res.detail}`;
  if (res.error === 'wrong_pin') {
    if (res.lockedUntil) return `PIN이 틀렸습니다. ${untilText(res.lockedUntil)}`;
    return `PIN이 틀렸습니다. (남은 시도 ${res.remaining}회)`;
  }
  if (res.error === 'locked_out') return `PIN 입력이 차단되었습니다. ${untilText(res.lockedUntil)}`;
  return ERRORS[res.error] || `오류: ${res.error}${res.detail ? ` (${res.detail})` : ''}`;
}

export function untilText(ms) {
  const t = new Date(ms);
  return `${t.getHours()}:${String(t.getMinutes()).padStart(2, '0')}까지 기다려 주세요.`;
}

// kind: 'error' | 'good' | 'pending'(진행 중, 도는 표시)
export function showMsg(el, text, kind = 'error') {
  el.textContent = text || '';
  el.className = `msg ${text ? (kind === 'pending' ? 'good pending' : kind) : ''}`;
}

// 버튼에 진행 표시를 붙인 채로 task를 기다린다
export async function busy(btn, task) {
  btn.disabled = true;
  btn.classList.add('busy');
  try { return await task(); } finally { btn.disabled = false; btn.classList.remove('busy'); }
}

export const $ = (id) => document.getElementById(id);
